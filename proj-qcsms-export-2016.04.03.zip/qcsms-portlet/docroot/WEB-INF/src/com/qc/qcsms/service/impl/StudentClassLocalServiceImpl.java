/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.impl;

import java.util.Date;
import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.qc.qcsms.ClassCodeException;
import com.qc.qcsms.ClassCodeLengthException;
import com.qc.qcsms.FormClassException;
import com.qc.qcsms.model.StudentClass;
import com.qc.qcsms.service.StudentClassLocalServiceUtil;
import com.qc.qcsms.service.base.StudentClassLocalServiceBaseImpl;

/**
 * The implementation of the student class local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.qc.qcsms.service.StudentClassLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author teddyku
 * @see com.qc.qcsms.service.base.StudentClassLocalServiceBaseImpl
 * @see com.qc.qcsms.service.StudentClassLocalServiceUtil
 */
public class StudentClassLocalServiceImpl
	extends StudentClassLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.qc.qcsms.service.StudentClassLocalServiceUtil} to access the student class local service.
	 */

	public List<StudentClass> getStudentClasses(long groupId) throws SystemException {
	    return studentClassPersistence.findByGroupId(groupId);
	}

	public List<StudentClass> getStudentClasses(long groupId, int start, int end)
	   throws SystemException {
	    return studentClassPersistence.findByGroupId(groupId, start, end);
	}
	
	protected void validate (long studentClassId, String classCode) throws PortalException, SystemException {
	    if (Validator.isNull(classCode)) {
	    	throw new ClassCodeException();
	    }
	    if (classCode.length() > 3) {
	    	throw new ClassCodeLengthException();
	    }
    	List<StudentClass> studentClasses = studentClassPersistence.findByClassCode(classCode);
	    if (studentClasses.size() > 0) {
	    	for(StudentClass studentClass : studentClasses) {
	    		if (studentClass.getClassId() != studentClassId) throw new FormClassException();
	    	}
	    }
	}
	
	public StudentClass addStudentClass(long userId, String classCode, 
		    ServiceContext serviceContext) throws SystemException, PortalException {
		long groupId = serviceContext.getScopeGroupId();
		User user = userPersistence.findByPrimaryKey(userId);
		Date now = new Date();
		validate(0, classCode);

		long studentClassId = counterLocalService.increment();
		StudentClass studentClass = studentClassPersistence.create(studentClassId);

		studentClass.setUuid(serviceContext.getUuid());
		studentClass.setUserId(userId);
		studentClass.setGroupId(groupId);
		studentClass.setCompanyId(user.getCompanyId());
		studentClass.setUserName(user.getFullName());
		studentClass.setCreateDate(serviceContext.getCreateDate(now));
		studentClass.setModifiedDate(serviceContext.getModifiedDate(now));
		studentClass.setClassCode(classCode);
		studentClass.setExpandoBridgeAttributes(serviceContext);
		studentClassPersistence.update(studentClass);

		resourceLocalService.addResources(user.getCompanyId(), groupId, userId,
			       StudentClass.class.getName(), studentClassId, false, true, true);
		return studentClass;
	}

	public StudentClass updateStudentClass(long userId, long studentClassId,
		String classCode, ServiceContext serviceContext) throws PortalException, SystemException {
		Date now = new Date();
		validate(studentClassId, classCode);
		StudentClass studentClass = getStudentClass(studentClassId);
		
		User user = UserLocalServiceUtil.getUser(userId);
		studentClass.setUserId(userId);
		studentClass.setUserName(user.getFullName());
		studentClass.setModifiedDate(serviceContext.getModifiedDate(now));
		studentClass.setClassCode(classCode);
		studentClass.setExpandoBridgeAttributes(serviceContext);
		studentClassPersistence.update(studentClass);
		resourceLocalService.updateResources(serviceContext.getCompanyId(),
		                serviceContext.getScopeGroupId(), StudentClass.class.getName(), studentClassId,
		                serviceContext.getGroupPermissions(),
		                serviceContext.getGuestPermissions());
		return studentClass;
	}
	
	public StudentClass deleteStudentClass(long studentClassId,
            ServiceContext serviceContext) throws PortalException, SystemException {
	    StudentClass studentClass = getStudentClass(studentClassId);
	    resourceLocalService.deleteResource(serviceContext.getCompanyId(),
	                    StudentClass.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
	                    studentClassId);
	    studentClass = deleteStudentClass(studentClass);
	    return studentClass;
	}
	
	public int getStudentClassCount(long groupId) throws SystemException {
        return studentClassPersistence.countByGroupId(groupId);
	}

	public List getSearchStudentClasses(String classCode, boolean andSearch, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		DynamicQuery dynamicQuery = buildStudentClassDynamicQuery(classCode, andSearch);
		return StudentClassLocalServiceUtil.dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	public int getSearchStudentClassesCount(String classCode, boolean andSearch) 
		throws SystemException {
		DynamicQuery dynamicQuery = buildStudentClassDynamicQuery(classCode, andSearch);
		return (int)StudentClassLocalServiceUtil.dynamicQueryCount(dynamicQuery);
	}

	protected DynamicQuery buildStudentClassDynamicQuery(String classCode, boolean andSearch) {
		Junction junction = null;
		if(andSearch) {
			junction = RestrictionsFactoryUtil.conjunction();
		} else {
			junction = RestrictionsFactoryUtil.disjunction();
		}
		if(Validator.isNotNull(classCode)) {
			Property property = PropertyFactoryUtil.forName("classCode");
			String value = (new StringBuilder("%")).append(classCode).append("%").toString();
			junction.add(property.like(value));
		}
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(StudentClass.class, getClassLoader());
		return dynamicQuery.add(junction);
	}
}