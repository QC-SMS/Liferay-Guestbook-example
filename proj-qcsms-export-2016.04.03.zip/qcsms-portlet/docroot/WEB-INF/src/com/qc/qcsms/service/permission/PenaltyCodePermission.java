package com.qc.qcsms.service.permission;

import com.qc.qcsms.model.PenaltyCode;
import com.qc.qcsms.service.PenaltyCodeLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.security.permission.PermissionChecker;

public class PenaltyCodePermission {
    public static void check(PermissionChecker permissionChecker,
            long penaltyCodeId, String actionId) throws PortalException,
            SystemException {

        if (!contains(permissionChecker, penaltyCodeId, actionId)) {
            throw new PrincipalException();
        }
    }

    public static boolean contains(PermissionChecker permissionChecker,
            long penaltyCodeId, String actionId) throws PortalException,
            SystemException {
        PenaltyCode penaltyCode = PenaltyCodeLocalServiceUtil
                .getPenaltyCode(penaltyCodeId);
        return permissionChecker
                .hasPermission(penaltyCode.getGroupId(),
                        PenaltyCode.class.getName(), penaltyCode.getPenaltyCodeId(),
                        actionId);
    }
}
