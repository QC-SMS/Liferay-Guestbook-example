/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.CalendarUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.security.permission.InlineSQLHelperUtil;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.qc.qcsms.NoSuchPenaltyEventException;
import com.qc.qcsms.model.PenaltyEvent;
import com.qc.qcsms.model.impl.PenaltyEventImpl;
import com.qc.qcsms.model.impl.PenaltyEventModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the penalty event service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see PenaltyEventPersistence
 * @see PenaltyEventUtil
 * @generated
 */
public class PenaltyEventPersistenceImpl extends BasePersistenceImpl<PenaltyEvent>
	implements PenaltyEventPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link PenaltyEventUtil} to access the penalty event persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = PenaltyEventImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
			new String[] { String.class.getName() },
			PenaltyEventModelImpl.UUID_COLUMN_BITMASK |
			PenaltyEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
			new String[] { String.class.getName() });

	/**
	 * Returns all the penalty events where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByUuid(String uuid) throws SystemException {
		return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty events where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @return the range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByUuid(String uuid, int start, int end)
		throws SystemException {
		return findByUuid(uuid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty events where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByUuid(String uuid, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid, start, end, orderByComparator };
		}

		List<PenaltyEvent> list = (List<PenaltyEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PenaltyEvent penaltyEvent : list) {
				if (!Validator.equals(uuid, penaltyEvent.getUuid())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				if (!pagination) {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyEvent>(list);
				}
				else {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first penalty event in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByUuid_First(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByUuid_First(uuid, orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the first penalty event in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByUuid_First(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		List<PenaltyEvent> list = findByUuid(uuid, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last penalty event in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByUuid_Last(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByUuid_Last(uuid, orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the last penalty event in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByUuid_Last(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid(uuid);

		if (count == 0) {
			return null;
		}

		List<PenaltyEvent> list = findByUuid(uuid, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the penalty events before and after the current penalty event in the ordered set where uuid = &#63;.
	 *
	 * @param penaltyEventId the primary key of the current penalty event
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent[] findByUuid_PrevAndNext(long penaltyEventId,
		String uuid, OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = findByPrimaryKey(penaltyEventId);

		Session session = null;

		try {
			session = openSession();

			PenaltyEvent[] array = new PenaltyEventImpl[3];

			array[0] = getByUuid_PrevAndNext(session, penaltyEvent, uuid,
					orderByComparator, true);

			array[1] = penaltyEvent;

			array[2] = getByUuid_PrevAndNext(session, penaltyEvent, uuid,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyEvent getByUuid_PrevAndNext(Session session,
		PenaltyEvent penaltyEvent, String uuid,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_UUID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the penalty events where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid(String uuid) throws SystemException {
		for (PenaltyEvent penaltyEvent : findByUuid(uuid, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(penaltyEvent);
		}
	}

	/**
	 * Returns the number of penalty events where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid(String uuid) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

		Object[] finderArgs = new Object[] { uuid };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PENALTYEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_UUID_1 = "penaltyEvent.uuid IS NULL";
	private static final String _FINDER_COLUMN_UUID_UUID_2 = "penaltyEvent.uuid = ?";
	private static final String _FINDER_COLUMN_UUID_UUID_3 = "(penaltyEvent.uuid IS NULL OR penaltyEvent.uuid = '')";
	public static final FinderPath FINDER_PATH_FETCH_BY_UUID_G = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByUUID_G",
			new String[] { String.class.getName(), Long.class.getName() },
			PenaltyEventModelImpl.UUID_COLUMN_BITMASK |
			PenaltyEventModelImpl.GROUPID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID_G = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUUID_G",
			new String[] { String.class.getName(), Long.class.getName() });

	/**
	 * Returns the penalty event where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchPenaltyEventException} if it could not be found.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByUUID_G(String uuid, long groupId)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByUUID_G(uuid, groupId);

		if (penaltyEvent == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("uuid=");
			msg.append(uuid);

			msg.append(", groupId=");
			msg.append(groupId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchPenaltyEventException(msg.toString());
		}

		return penaltyEvent;
	}

	/**
	 * Returns the penalty event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByUUID_G(String uuid, long groupId)
		throws SystemException {
		return fetchByUUID_G(uuid, groupId, true);
	}

	/**
	 * Returns the penalty event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByUUID_G(String uuid, long groupId,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { uuid, groupId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_UUID_G,
					finderArgs, this);
		}

		if (result instanceof PenaltyEvent) {
			PenaltyEvent penaltyEvent = (PenaltyEvent)result;

			if (!Validator.equals(uuid, penaltyEvent.getUuid()) ||
					(groupId != penaltyEvent.getGroupId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_G_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(groupId);

				List<PenaltyEvent> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
						finderArgs, list);
				}
				else {
					PenaltyEvent penaltyEvent = list.get(0);

					result = penaltyEvent;

					cacheResult(penaltyEvent);

					if ((penaltyEvent.getUuid() == null) ||
							!penaltyEvent.getUuid().equals(uuid) ||
							(penaltyEvent.getGroupId() != groupId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
							finderArgs, penaltyEvent);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (PenaltyEvent)result;
		}
	}

	/**
	 * Removes the penalty event where uuid = &#63; and groupId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the penalty event that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent removeByUUID_G(String uuid, long groupId)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = findByUUID_G(uuid, groupId);

		return remove(penaltyEvent);
	}

	/**
	 * Returns the number of penalty events where uuid = &#63; and groupId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the number of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUUID_G(String uuid, long groupId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_G;

		Object[] finderArgs = new Object[] { uuid, groupId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_PENALTYEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_G_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(groupId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_G_UUID_1 = "penaltyEvent.uuid IS NULL AND ";
	private static final String _FINDER_COLUMN_UUID_G_UUID_2 = "penaltyEvent.uuid = ? AND ";
	private static final String _FINDER_COLUMN_UUID_G_UUID_3 = "(penaltyEvent.uuid IS NULL OR penaltyEvent.uuid = '') AND ";
	private static final String _FINDER_COLUMN_UUID_G_GROUPID_2 = "penaltyEvent.groupId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C =
		new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid_C",
			new String[] { String.class.getName(), Long.class.getName() },
			PenaltyEventModelImpl.UUID_COLUMN_BITMASK |
			PenaltyEventModelImpl.COMPANYID_COLUMN_BITMASK |
			PenaltyEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID_C = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid_C",
			new String[] { String.class.getName(), Long.class.getName() });

	/**
	 * Returns all the penalty events where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByUuid_C(String uuid, long companyId)
		throws SystemException {
		return findByUuid_C(uuid, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty events where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @return the range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByUuid_C(String uuid, long companyId,
		int start, int end) throws SystemException {
		return findByUuid_C(uuid, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty events where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByUuid_C(String uuid, long companyId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C;
			finderArgs = new Object[] { uuid, companyId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C;
			finderArgs = new Object[] {
					uuid, companyId,
					
					start, end, orderByComparator
				};
		}

		List<PenaltyEvent> list = (List<PenaltyEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PenaltyEvent penaltyEvent : list) {
				if (!Validator.equals(uuid, penaltyEvent.getUuid()) ||
						(companyId != penaltyEvent.getCompanyId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_C_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyEvent>(list);
				}
				else {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByUuid_C_First(String uuid, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByUuid_C_First(uuid, companyId,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the first penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByUuid_C_First(String uuid, long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		List<PenaltyEvent> list = findByUuid_C(uuid, companyId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByUuid_C_Last(String uuid, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByUuid_C_Last(uuid, companyId,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the last penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByUuid_C_Last(String uuid, long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid_C(uuid, companyId);

		if (count == 0) {
			return null;
		}

		List<PenaltyEvent> list = findByUuid_C(uuid, companyId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the penalty events before and after the current penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param penaltyEventId the primary key of the current penalty event
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent[] findByUuid_C_PrevAndNext(long penaltyEventId,
		String uuid, long companyId, OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = findByPrimaryKey(penaltyEventId);

		Session session = null;

		try {
			session = openSession();

			PenaltyEvent[] array = new PenaltyEventImpl[3];

			array[0] = getByUuid_C_PrevAndNext(session, penaltyEvent, uuid,
					companyId, orderByComparator, true);

			array[1] = penaltyEvent;

			array[2] = getByUuid_C_PrevAndNext(session, penaltyEvent, uuid,
					companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyEvent getByUuid_C_PrevAndNext(Session session,
		PenaltyEvent penaltyEvent, String uuid, long companyId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_C_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_C_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_C_UUID_2);
		}

		query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the penalty events where uuid = &#63; and companyId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid_C(String uuid, long companyId)
		throws SystemException {
		for (PenaltyEvent penaltyEvent : findByUuid_C(uuid, companyId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(penaltyEvent);
		}
	}

	/**
	 * Returns the number of penalty events where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the number of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid_C(String uuid, long companyId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_C;

		Object[] finderArgs = new Object[] { uuid, companyId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_PENALTYEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_C_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_C_UUID_1 = "penaltyEvent.uuid IS NULL AND ";
	private static final String _FINDER_COLUMN_UUID_C_UUID_2 = "penaltyEvent.uuid = ? AND ";
	private static final String _FINDER_COLUMN_UUID_C_UUID_3 = "(penaltyEvent.uuid IS NULL OR penaltyEvent.uuid = '') AND ";
	private static final String _FINDER_COLUMN_UUID_C_COMPANYID_2 = "penaltyEvent.companyId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_GROUPID = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByGroupId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID =
		new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByGroupId",
			new String[] { Long.class.getName() },
			PenaltyEventModelImpl.GROUPID_COLUMN_BITMASK |
			PenaltyEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_GROUPID = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByGroupId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the penalty events where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByGroupId(long groupId)
		throws SystemException {
		return findByGroupId(groupId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty events where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @return the range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByGroupId(long groupId, int start, int end)
		throws SystemException {
		return findByGroupId(groupId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty events where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByGroupId(long groupId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID;
			finderArgs = new Object[] { groupId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_GROUPID;
			finderArgs = new Object[] { groupId, start, end, orderByComparator };
		}

		List<PenaltyEvent> list = (List<PenaltyEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PenaltyEvent penaltyEvent : list) {
				if ((groupId != penaltyEvent.getGroupId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

			query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				if (!pagination) {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyEvent>(list);
				}
				else {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first penalty event in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByGroupId_First(long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByGroupId_First(groupId,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the first penalty event in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByGroupId_First(long groupId,
		OrderByComparator orderByComparator) throws SystemException {
		List<PenaltyEvent> list = findByGroupId(groupId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last penalty event in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByGroupId_Last(long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByGroupId_Last(groupId,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the last penalty event in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByGroupId_Last(long groupId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByGroupId(groupId);

		if (count == 0) {
			return null;
		}

		List<PenaltyEvent> list = findByGroupId(groupId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the penalty events before and after the current penalty event in the ordered set where groupId = &#63;.
	 *
	 * @param penaltyEventId the primary key of the current penalty event
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent[] findByGroupId_PrevAndNext(long penaltyEventId,
		long groupId, OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = findByPrimaryKey(penaltyEventId);

		Session session = null;

		try {
			session = openSession();

			PenaltyEvent[] array = new PenaltyEventImpl[3];

			array[0] = getByGroupId_PrevAndNext(session, penaltyEvent, groupId,
					orderByComparator, true);

			array[1] = penaltyEvent;

			array[2] = getByGroupId_PrevAndNext(session, penaltyEvent, groupId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyEvent getByGroupId_PrevAndNext(Session session,
		PenaltyEvent penaltyEvent, long groupId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(groupId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Returns all the penalty events that the user has permission to view where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the matching penalty events that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> filterFindByGroupId(long groupId)
		throws SystemException {
		return filterFindByGroupId(groupId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty events that the user has permission to view where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @return the range of matching penalty events that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> filterFindByGroupId(long groupId, int start,
		int end) throws SystemException {
		return filterFindByGroupId(groupId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty events that the user has permissions to view where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty events that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> filterFindByGroupId(long groupId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return findByGroupId(groupId, start, end, orderByComparator);
		}

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(3 +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		if (getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_PENALTYEVENT_WHERE);
		}
		else {
			query.append(_FILTER_SQL_SELECT_PENALTYEVENT_NO_INLINE_DISTINCT_WHERE_1);
		}

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (!getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_PENALTYEVENT_NO_INLINE_DISTINCT_WHERE_2);
		}

		if (orderByComparator != null) {
			if (getDB().isSupportsInlineDistinct()) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator, true);
			}
			else {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_TABLE,
					orderByComparator, true);
			}
		}
		else {
			if (getDB().isSupportsInlineDistinct()) {
				query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
			}
			else {
				query.append(PenaltyEventModelImpl.ORDER_BY_SQL);
			}
		}

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				PenaltyEvent.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		Session session = null;

		try {
			session = openSession();

			SQLQuery q = session.createSQLQuery(sql);

			if (getDB().isSupportsInlineDistinct()) {
				q.addEntity(_FILTER_ENTITY_ALIAS, PenaltyEventImpl.class);
			}
			else {
				q.addEntity(_FILTER_ENTITY_TABLE, PenaltyEventImpl.class);
			}

			QueryPos qPos = QueryPos.getInstance(q);

			qPos.add(groupId);

			return (List<PenaltyEvent>)QueryUtil.list(q, getDialect(), start,
				end);
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	/**
	 * Returns the penalty events before and after the current penalty event in the ordered set of penalty events that the user has permission to view where groupId = &#63;.
	 *
	 * @param penaltyEventId the primary key of the current penalty event
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent[] filterFindByGroupId_PrevAndNext(long penaltyEventId,
		long groupId, OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return findByGroupId_PrevAndNext(penaltyEventId, groupId,
				orderByComparator);
		}

		PenaltyEvent penaltyEvent = findByPrimaryKey(penaltyEventId);

		Session session = null;

		try {
			session = openSession();

			PenaltyEvent[] array = new PenaltyEventImpl[3];

			array[0] = filterGetByGroupId_PrevAndNext(session, penaltyEvent,
					groupId, orderByComparator, true);

			array[1] = penaltyEvent;

			array[2] = filterGetByGroupId_PrevAndNext(session, penaltyEvent,
					groupId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyEvent filterGetByGroupId_PrevAndNext(Session session,
		PenaltyEvent penaltyEvent, long groupId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		if (getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_PENALTYEVENT_WHERE);
		}
		else {
			query.append(_FILTER_SQL_SELECT_PENALTYEVENT_NO_INLINE_DISTINCT_WHERE_1);
		}

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (!getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_PENALTYEVENT_NO_INLINE_DISTINCT_WHERE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				if (getDB().isSupportsInlineDistinct()) {
					query.append(_ORDER_BY_ENTITY_ALIAS);
				}
				else {
					query.append(_ORDER_BY_ENTITY_TABLE);
				}

				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				if (getDB().isSupportsInlineDistinct()) {
					query.append(_ORDER_BY_ENTITY_ALIAS);
				}
				else {
					query.append(_ORDER_BY_ENTITY_TABLE);
				}

				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			if (getDB().isSupportsInlineDistinct()) {
				query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
			}
			else {
				query.append(PenaltyEventModelImpl.ORDER_BY_SQL);
			}
		}

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				PenaltyEvent.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		SQLQuery q = session.createSQLQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		if (getDB().isSupportsInlineDistinct()) {
			q.addEntity(_FILTER_ENTITY_ALIAS, PenaltyEventImpl.class);
		}
		else {
			q.addEntity(_FILTER_ENTITY_TABLE, PenaltyEventImpl.class);
		}

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(groupId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the penalty events where groupId = &#63; from the database.
	 *
	 * @param groupId the group ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByGroupId(long groupId) throws SystemException {
		for (PenaltyEvent penaltyEvent : findByGroupId(groupId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(penaltyEvent);
		}
	}

	/**
	 * Returns the number of penalty events where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the number of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByGroupId(long groupId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_GROUPID;

		Object[] finderArgs = new Object[] { groupId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PENALTYEVENT_WHERE);

			query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of penalty events that the user has permission to view where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the number of matching penalty events that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int filterCountByGroupId(long groupId) throws SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return countByGroupId(groupId);
		}

		StringBundler query = new StringBundler(2);

		query.append(_FILTER_SQL_COUNT_PENALTYEVENT_WHERE);

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				PenaltyEvent.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		Session session = null;

		try {
			session = openSession();

			SQLQuery q = session.createSQLQuery(sql);

			q.addScalar(COUNT_COLUMN_NAME,
				com.liferay.portal.kernel.dao.orm.Type.LONG);

			QueryPos qPos = QueryPos.getInstance(q);

			qPos.add(groupId);

			Long count = (Long)q.uniqueResult();

			return count.intValue();
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	private static final String _FINDER_COLUMN_GROUPID_GROUPID_2 = "penaltyEvent.groupId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_STUDENTID =
		new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByStudentId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STUDENTID =
		new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByStudentId",
			new String[] { Long.class.getName() },
			PenaltyEventModelImpl.STUDENTID_COLUMN_BITMASK |
			PenaltyEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_STUDENTID = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByStudentId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the penalty events where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @return the matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByStudentId(long studentId)
		throws SystemException {
		return findByStudentId(studentId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the penalty events where studentId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param studentId the student ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @return the range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByStudentId(long studentId, int start, int end)
		throws SystemException {
		return findByStudentId(studentId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty events where studentId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param studentId the student ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByStudentId(long studentId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STUDENTID;
			finderArgs = new Object[] { studentId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_STUDENTID;
			finderArgs = new Object[] { studentId, start, end, orderByComparator };
		}

		List<PenaltyEvent> list = (List<PenaltyEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PenaltyEvent penaltyEvent : list) {
				if ((studentId != penaltyEvent.getStudentId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

			query.append(_FINDER_COLUMN_STUDENTID_STUDENTID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(studentId);

				if (!pagination) {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyEvent>(list);
				}
				else {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first penalty event in the ordered set where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByStudentId_First(long studentId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByStudentId_First(studentId,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("studentId=");
		msg.append(studentId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the first penalty event in the ordered set where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByStudentId_First(long studentId,
		OrderByComparator orderByComparator) throws SystemException {
		List<PenaltyEvent> list = findByStudentId(studentId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last penalty event in the ordered set where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByStudentId_Last(long studentId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByStudentId_Last(studentId,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("studentId=");
		msg.append(studentId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the last penalty event in the ordered set where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByStudentId_Last(long studentId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByStudentId(studentId);

		if (count == 0) {
			return null;
		}

		List<PenaltyEvent> list = findByStudentId(studentId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the penalty events before and after the current penalty event in the ordered set where studentId = &#63;.
	 *
	 * @param penaltyEventId the primary key of the current penalty event
	 * @param studentId the student ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent[] findByStudentId_PrevAndNext(long penaltyEventId,
		long studentId, OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = findByPrimaryKey(penaltyEventId);

		Session session = null;

		try {
			session = openSession();

			PenaltyEvent[] array = new PenaltyEventImpl[3];

			array[0] = getByStudentId_PrevAndNext(session, penaltyEvent,
					studentId, orderByComparator, true);

			array[1] = penaltyEvent;

			array[2] = getByStudentId_PrevAndNext(session, penaltyEvent,
					studentId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyEvent getByStudentId_PrevAndNext(Session session,
		PenaltyEvent penaltyEvent, long studentId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

		query.append(_FINDER_COLUMN_STUDENTID_STUDENTID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(studentId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the penalty events where studentId = &#63; from the database.
	 *
	 * @param studentId the student ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByStudentId(long studentId) throws SystemException {
		for (PenaltyEvent penaltyEvent : findByStudentId(studentId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(penaltyEvent);
		}
	}

	/**
	 * Returns the number of penalty events where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @return the number of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByStudentId(long studentId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_STUDENTID;

		Object[] finderArgs = new Object[] { studentId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PENALTYEVENT_WHERE);

			query.append(_FINDER_COLUMN_STUDENTID_STUDENTID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(studentId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STUDENTID_STUDENTID_2 = "penaltyEvent.studentId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_PENALTYCODEID =
		new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByPenaltyCodeId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PENALTYCODEID =
		new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByPenaltyCodeId",
			new String[] { Long.class.getName() },
			PenaltyEventModelImpl.PENALTYCODEID_COLUMN_BITMASK |
			PenaltyEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_PENALTYCODEID = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByPenaltyCodeId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the penalty events where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @return the matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByPenaltyCodeId(long penaltyCodeId)
		throws SystemException {
		return findByPenaltyCodeId(penaltyCodeId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty events where penaltyCodeId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @return the range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByPenaltyCodeId(long penaltyCodeId,
		int start, int end) throws SystemException {
		return findByPenaltyCodeId(penaltyCodeId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty events where penaltyCodeId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByPenaltyCodeId(long penaltyCodeId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PENALTYCODEID;
			finderArgs = new Object[] { penaltyCodeId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_PENALTYCODEID;
			finderArgs = new Object[] {
					penaltyCodeId,
					
					start, end, orderByComparator
				};
		}

		List<PenaltyEvent> list = (List<PenaltyEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PenaltyEvent penaltyEvent : list) {
				if ((penaltyCodeId != penaltyEvent.getPenaltyCodeId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

			query.append(_FINDER_COLUMN_PENALTYCODEID_PENALTYCODEID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(penaltyCodeId);

				if (!pagination) {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyEvent>(list);
				}
				else {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first penalty event in the ordered set where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByPenaltyCodeId_First(long penaltyCodeId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByPenaltyCodeId_First(penaltyCodeId,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("penaltyCodeId=");
		msg.append(penaltyCodeId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the first penalty event in the ordered set where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByPenaltyCodeId_First(long penaltyCodeId,
		OrderByComparator orderByComparator) throws SystemException {
		List<PenaltyEvent> list = findByPenaltyCodeId(penaltyCodeId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last penalty event in the ordered set where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByPenaltyCodeId_Last(long penaltyCodeId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByPenaltyCodeId_Last(penaltyCodeId,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("penaltyCodeId=");
		msg.append(penaltyCodeId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the last penalty event in the ordered set where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByPenaltyCodeId_Last(long penaltyCodeId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByPenaltyCodeId(penaltyCodeId);

		if (count == 0) {
			return null;
		}

		List<PenaltyEvent> list = findByPenaltyCodeId(penaltyCodeId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the penalty events before and after the current penalty event in the ordered set where penaltyCodeId = &#63;.
	 *
	 * @param penaltyEventId the primary key of the current penalty event
	 * @param penaltyCodeId the penalty code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent[] findByPenaltyCodeId_PrevAndNext(long penaltyEventId,
		long penaltyCodeId, OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = findByPrimaryKey(penaltyEventId);

		Session session = null;

		try {
			session = openSession();

			PenaltyEvent[] array = new PenaltyEventImpl[3];

			array[0] = getByPenaltyCodeId_PrevAndNext(session, penaltyEvent,
					penaltyCodeId, orderByComparator, true);

			array[1] = penaltyEvent;

			array[2] = getByPenaltyCodeId_PrevAndNext(session, penaltyEvent,
					penaltyCodeId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyEvent getByPenaltyCodeId_PrevAndNext(Session session,
		PenaltyEvent penaltyEvent, long penaltyCodeId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

		query.append(_FINDER_COLUMN_PENALTYCODEID_PENALTYCODEID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(penaltyCodeId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the penalty events where penaltyCodeId = &#63; from the database.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByPenaltyCodeId(long penaltyCodeId)
		throws SystemException {
		for (PenaltyEvent penaltyEvent : findByPenaltyCodeId(penaltyCodeId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(penaltyEvent);
		}
	}

	/**
	 * Returns the number of penalty events where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @return the number of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByPenaltyCodeId(long penaltyCodeId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_PENALTYCODEID;

		Object[] finderArgs = new Object[] { penaltyCodeId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PENALTYEVENT_WHERE);

			query.append(_FINDER_COLUMN_PENALTYCODEID_PENALTYCODEID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(penaltyCodeId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_PENALTYCODEID_PENALTYCODEID_2 = "penaltyEvent.penaltyCodeId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_DISCIPLINEEVENTID =
		new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByDisciplineEventId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCIPLINEEVENTID =
		new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"findByDisciplineEventId", new String[] { Long.class.getName() },
			PenaltyEventModelImpl.DISCIPLINEEVENTID_COLUMN_BITMASK |
			PenaltyEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_DISCIPLINEEVENTID = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION,
			"countByDisciplineEventId", new String[] { Long.class.getName() });

	/**
	 * Returns all the penalty events where disciplineEventId = &#63;.
	 *
	 * @param disciplineEventId the discipline event ID
	 * @return the matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByDisciplineEventId(long disciplineEventId)
		throws SystemException {
		return findByDisciplineEventId(disciplineEventId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty events where disciplineEventId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param disciplineEventId the discipline event ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @return the range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByDisciplineEventId(long disciplineEventId,
		int start, int end) throws SystemException {
		return findByDisciplineEventId(disciplineEventId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty events where disciplineEventId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param disciplineEventId the discipline event ID
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByDisciplineEventId(long disciplineEventId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCIPLINEEVENTID;
			finderArgs = new Object[] { disciplineEventId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_DISCIPLINEEVENTID;
			finderArgs = new Object[] {
					disciplineEventId,
					
					start, end, orderByComparator
				};
		}

		List<PenaltyEvent> list = (List<PenaltyEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PenaltyEvent penaltyEvent : list) {
				if ((disciplineEventId != penaltyEvent.getDisciplineEventId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

			query.append(_FINDER_COLUMN_DISCIPLINEEVENTID_DISCIPLINEEVENTID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(disciplineEventId);

				if (!pagination) {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyEvent>(list);
				}
				else {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first penalty event in the ordered set where disciplineEventId = &#63;.
	 *
	 * @param disciplineEventId the discipline event ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByDisciplineEventId_First(long disciplineEventId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByDisciplineEventId_First(disciplineEventId,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("disciplineEventId=");
		msg.append(disciplineEventId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the first penalty event in the ordered set where disciplineEventId = &#63;.
	 *
	 * @param disciplineEventId the discipline event ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByDisciplineEventId_First(long disciplineEventId,
		OrderByComparator orderByComparator) throws SystemException {
		List<PenaltyEvent> list = findByDisciplineEventId(disciplineEventId, 0,
				1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last penalty event in the ordered set where disciplineEventId = &#63;.
	 *
	 * @param disciplineEventId the discipline event ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByDisciplineEventId_Last(long disciplineEventId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByDisciplineEventId_Last(disciplineEventId,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("disciplineEventId=");
		msg.append(disciplineEventId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the last penalty event in the ordered set where disciplineEventId = &#63;.
	 *
	 * @param disciplineEventId the discipline event ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByDisciplineEventId_Last(long disciplineEventId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByDisciplineEventId(disciplineEventId);

		if (count == 0) {
			return null;
		}

		List<PenaltyEvent> list = findByDisciplineEventId(disciplineEventId,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the penalty events before and after the current penalty event in the ordered set where disciplineEventId = &#63;.
	 *
	 * @param penaltyEventId the primary key of the current penalty event
	 * @param disciplineEventId the discipline event ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent[] findByDisciplineEventId_PrevAndNext(
		long penaltyEventId, long disciplineEventId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = findByPrimaryKey(penaltyEventId);

		Session session = null;

		try {
			session = openSession();

			PenaltyEvent[] array = new PenaltyEventImpl[3];

			array[0] = getByDisciplineEventId_PrevAndNext(session,
					penaltyEvent, disciplineEventId, orderByComparator, true);

			array[1] = penaltyEvent;

			array[2] = getByDisciplineEventId_PrevAndNext(session,
					penaltyEvent, disciplineEventId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyEvent getByDisciplineEventId_PrevAndNext(Session session,
		PenaltyEvent penaltyEvent, long disciplineEventId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

		query.append(_FINDER_COLUMN_DISCIPLINEEVENTID_DISCIPLINEEVENTID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(disciplineEventId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the penalty events where disciplineEventId = &#63; from the database.
	 *
	 * @param disciplineEventId the discipline event ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByDisciplineEventId(long disciplineEventId)
		throws SystemException {
		for (PenaltyEvent penaltyEvent : findByDisciplineEventId(
				disciplineEventId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(penaltyEvent);
		}
	}

	/**
	 * Returns the number of penalty events where disciplineEventId = &#63;.
	 *
	 * @param disciplineEventId the discipline event ID
	 * @return the number of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByDisciplineEventId(long disciplineEventId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_DISCIPLINEEVENTID;

		Object[] finderArgs = new Object[] { disciplineEventId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PENALTYEVENT_WHERE);

			query.append(_FINDER_COLUMN_DISCIPLINEEVENTID_DISCIPLINEEVENTID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(disciplineEventId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_DISCIPLINEEVENTID_DISCIPLINEEVENTID_2 =
		"penaltyEvent.disciplineEventId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_EVENTDATE =
		new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByEventDate",
			new String[] {
				Date.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EVENTDATE =
		new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, PenaltyEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByEventDate",
			new String[] { Date.class.getName() },
			PenaltyEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_EVENTDATE = new FinderPath(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByEventDate",
			new String[] { Date.class.getName() });

	/**
	 * Returns all the penalty events where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @return the matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByEventDate(Date eventDate)
		throws SystemException {
		return findByEventDate(eventDate, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the penalty events where eventDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param eventDate the event date
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @return the range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByEventDate(Date eventDate, int start, int end)
		throws SystemException {
		return findByEventDate(eventDate, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty events where eventDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param eventDate the event date
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findByEventDate(Date eventDate, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EVENTDATE;
			finderArgs = new Object[] { eventDate };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_EVENTDATE;
			finderArgs = new Object[] { eventDate, start, end, orderByComparator };
		}

		List<PenaltyEvent> list = (List<PenaltyEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PenaltyEvent penaltyEvent : list) {
				if (!Validator.equals(eventDate, penaltyEvent.getEventDate())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

			boolean bindEventDate = false;

			if (eventDate == null) {
				query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_1);
			}
			else {
				bindEventDate = true;

				query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEventDate) {
					qPos.add(CalendarUtil.getTimestamp(eventDate));
				}

				if (!pagination) {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyEvent>(list);
				}
				else {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first penalty event in the ordered set where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByEventDate_First(Date eventDate,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByEventDate_First(eventDate,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("eventDate=");
		msg.append(eventDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the first penalty event in the ordered set where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByEventDate_First(Date eventDate,
		OrderByComparator orderByComparator) throws SystemException {
		List<PenaltyEvent> list = findByEventDate(eventDate, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last penalty event in the ordered set where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByEventDate_Last(Date eventDate,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByEventDate_Last(eventDate,
				orderByComparator);

		if (penaltyEvent != null) {
			return penaltyEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("eventDate=");
		msg.append(eventDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyEventException(msg.toString());
	}

	/**
	 * Returns the last penalty event in the ordered set where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByEventDate_Last(Date eventDate,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByEventDate(eventDate);

		if (count == 0) {
			return null;
		}

		List<PenaltyEvent> list = findByEventDate(eventDate, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the penalty events before and after the current penalty event in the ordered set where eventDate = &#63;.
	 *
	 * @param penaltyEventId the primary key of the current penalty event
	 * @param eventDate the event date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent[] findByEventDate_PrevAndNext(long penaltyEventId,
		Date eventDate, OrderByComparator orderByComparator)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = findByPrimaryKey(penaltyEventId);

		Session session = null;

		try {
			session = openSession();

			PenaltyEvent[] array = new PenaltyEventImpl[3];

			array[0] = getByEventDate_PrevAndNext(session, penaltyEvent,
					eventDate, orderByComparator, true);

			array[1] = penaltyEvent;

			array[2] = getByEventDate_PrevAndNext(session, penaltyEvent,
					eventDate, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyEvent getByEventDate_PrevAndNext(Session session,
		PenaltyEvent penaltyEvent, Date eventDate,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PENALTYEVENT_WHERE);

		boolean bindEventDate = false;

		if (eventDate == null) {
			query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_1);
		}
		else {
			bindEventDate = true;

			query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PenaltyEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindEventDate) {
			qPos.add(CalendarUtil.getTimestamp(eventDate));
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the penalty events where eventDate = &#63; from the database.
	 *
	 * @param eventDate the event date
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByEventDate(Date eventDate) throws SystemException {
		for (PenaltyEvent penaltyEvent : findByEventDate(eventDate,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(penaltyEvent);
		}
	}

	/**
	 * Returns the number of penalty events where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @return the number of matching penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByEventDate(Date eventDate) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_EVENTDATE;

		Object[] finderArgs = new Object[] { eventDate };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PENALTYEVENT_WHERE);

			boolean bindEventDate = false;

			if (eventDate == null) {
				query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_1);
			}
			else {
				bindEventDate = true;

				query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEventDate) {
					qPos.add(CalendarUtil.getTimestamp(eventDate));
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_EVENTDATE_EVENTDATE_1 = "penaltyEvent.eventDate IS NULL";
	private static final String _FINDER_COLUMN_EVENTDATE_EVENTDATE_2 = "penaltyEvent.eventDate = ?";

	public PenaltyEventPersistenceImpl() {
		setModelClass(PenaltyEvent.class);
	}

	/**
	 * Caches the penalty event in the entity cache if it is enabled.
	 *
	 * @param penaltyEvent the penalty event
	 */
	@Override
	public void cacheResult(PenaltyEvent penaltyEvent) {
		EntityCacheUtil.putResult(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventImpl.class, penaltyEvent.getPrimaryKey(), penaltyEvent);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
			new Object[] { penaltyEvent.getUuid(), penaltyEvent.getGroupId() },
			penaltyEvent);

		penaltyEvent.resetOriginalValues();
	}

	/**
	 * Caches the penalty events in the entity cache if it is enabled.
	 *
	 * @param penaltyEvents the penalty events
	 */
	@Override
	public void cacheResult(List<PenaltyEvent> penaltyEvents) {
		for (PenaltyEvent penaltyEvent : penaltyEvents) {
			if (EntityCacheUtil.getResult(
						PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
						PenaltyEventImpl.class, penaltyEvent.getPrimaryKey()) == null) {
				cacheResult(penaltyEvent);
			}
			else {
				penaltyEvent.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all penalty events.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(PenaltyEventImpl.class.getName());
		}

		EntityCacheUtil.clearCache(PenaltyEventImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the penalty event.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(PenaltyEvent penaltyEvent) {
		EntityCacheUtil.removeResult(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventImpl.class, penaltyEvent.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(penaltyEvent);
	}

	@Override
	public void clearCache(List<PenaltyEvent> penaltyEvents) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (PenaltyEvent penaltyEvent : penaltyEvents) {
			EntityCacheUtil.removeResult(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
				PenaltyEventImpl.class, penaltyEvent.getPrimaryKey());

			clearUniqueFindersCache(penaltyEvent);
		}
	}

	protected void cacheUniqueFindersCache(PenaltyEvent penaltyEvent) {
		if (penaltyEvent.isNew()) {
			Object[] args = new Object[] {
					penaltyEvent.getUuid(), penaltyEvent.getGroupId()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
				penaltyEvent);
		}
		else {
			PenaltyEventModelImpl penaltyEventModelImpl = (PenaltyEventModelImpl)penaltyEvent;

			if ((penaltyEventModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyEvent.getUuid(), penaltyEvent.getGroupId()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
					Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
					penaltyEvent);
			}
		}
	}

	protected void clearUniqueFindersCache(PenaltyEvent penaltyEvent) {
		PenaltyEventModelImpl penaltyEventModelImpl = (PenaltyEventModelImpl)penaltyEvent;

		Object[] args = new Object[] {
				penaltyEvent.getUuid(), penaltyEvent.getGroupId()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);

		if ((penaltyEventModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
			args = new Object[] {
					penaltyEventModelImpl.getOriginalUuid(),
					penaltyEventModelImpl.getOriginalGroupId()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);
		}
	}

	/**
	 * Creates a new penalty event with the primary key. Does not add the penalty event to the database.
	 *
	 * @param penaltyEventId the primary key for the new penalty event
	 * @return the new penalty event
	 */
	@Override
	public PenaltyEvent create(long penaltyEventId) {
		PenaltyEvent penaltyEvent = new PenaltyEventImpl();

		penaltyEvent.setNew(true);
		penaltyEvent.setPrimaryKey(penaltyEventId);

		String uuid = PortalUUIDUtil.generate();

		penaltyEvent.setUuid(uuid);

		return penaltyEvent;
	}

	/**
	 * Removes the penalty event with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param penaltyEventId the primary key of the penalty event
	 * @return the penalty event that was removed
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent remove(long penaltyEventId)
		throws NoSuchPenaltyEventException, SystemException {
		return remove((Serializable)penaltyEventId);
	}

	/**
	 * Removes the penalty event with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the penalty event
	 * @return the penalty event that was removed
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent remove(Serializable primaryKey)
		throws NoSuchPenaltyEventException, SystemException {
		Session session = null;

		try {
			session = openSession();

			PenaltyEvent penaltyEvent = (PenaltyEvent)session.get(PenaltyEventImpl.class,
					primaryKey);

			if (penaltyEvent == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchPenaltyEventException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(penaltyEvent);
		}
		catch (NoSuchPenaltyEventException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected PenaltyEvent removeImpl(PenaltyEvent penaltyEvent)
		throws SystemException {
		penaltyEvent = toUnwrappedModel(penaltyEvent);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(penaltyEvent)) {
				penaltyEvent = (PenaltyEvent)session.get(PenaltyEventImpl.class,
						penaltyEvent.getPrimaryKeyObj());
			}

			if (penaltyEvent != null) {
				session.delete(penaltyEvent);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (penaltyEvent != null) {
			clearCache(penaltyEvent);
		}

		return penaltyEvent;
	}

	@Override
	public PenaltyEvent updateImpl(com.qc.qcsms.model.PenaltyEvent penaltyEvent)
		throws SystemException {
		penaltyEvent = toUnwrappedModel(penaltyEvent);

		boolean isNew = penaltyEvent.isNew();

		PenaltyEventModelImpl penaltyEventModelImpl = (PenaltyEventModelImpl)penaltyEvent;

		if (Validator.isNull(penaltyEvent.getUuid())) {
			String uuid = PortalUUIDUtil.generate();

			penaltyEvent.setUuid(uuid);
		}

		Session session = null;

		try {
			session = openSession();

			if (penaltyEvent.isNew()) {
				session.save(penaltyEvent);

				penaltyEvent.setNew(false);
			}
			else {
				session.merge(penaltyEvent);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !PenaltyEventModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((penaltyEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyEventModelImpl.getOriginalUuid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);

				args = new Object[] { penaltyEventModelImpl.getUuid() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);
			}

			if ((penaltyEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyEventModelImpl.getOriginalUuid(),
						penaltyEventModelImpl.getOriginalCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
					args);

				args = new Object[] {
						penaltyEventModelImpl.getUuid(),
						penaltyEventModelImpl.getCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
					args);
			}

			if ((penaltyEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyEventModelImpl.getOriginalGroupId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_GROUPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID,
					args);

				args = new Object[] { penaltyEventModelImpl.getGroupId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_GROUPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID,
					args);
			}

			if ((penaltyEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STUDENTID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyEventModelImpl.getOriginalStudentId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STUDENTID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STUDENTID,
					args);

				args = new Object[] { penaltyEventModelImpl.getStudentId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STUDENTID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STUDENTID,
					args);
			}

			if ((penaltyEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PENALTYCODEID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyEventModelImpl.getOriginalPenaltyCodeId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PENALTYCODEID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PENALTYCODEID,
					args);

				args = new Object[] { penaltyEventModelImpl.getPenaltyCodeId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PENALTYCODEID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PENALTYCODEID,
					args);
			}

			if ((penaltyEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCIPLINEEVENTID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyEventModelImpl.getOriginalDisciplineEventId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DISCIPLINEEVENTID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCIPLINEEVENTID,
					args);

				args = new Object[] { penaltyEventModelImpl.getDisciplineEventId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DISCIPLINEEVENTID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCIPLINEEVENTID,
					args);
			}

			if ((penaltyEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EVENTDATE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyEventModelImpl.getOriginalEventDate()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_EVENTDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EVENTDATE,
					args);

				args = new Object[] { penaltyEventModelImpl.getEventDate() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_EVENTDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EVENTDATE,
					args);
			}
		}

		EntityCacheUtil.putResult(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyEventImpl.class, penaltyEvent.getPrimaryKey(), penaltyEvent);

		clearUniqueFindersCache(penaltyEvent);
		cacheUniqueFindersCache(penaltyEvent);

		return penaltyEvent;
	}

	protected PenaltyEvent toUnwrappedModel(PenaltyEvent penaltyEvent) {
		if (penaltyEvent instanceof PenaltyEventImpl) {
			return penaltyEvent;
		}

		PenaltyEventImpl penaltyEventImpl = new PenaltyEventImpl();

		penaltyEventImpl.setNew(penaltyEvent.isNew());
		penaltyEventImpl.setPrimaryKey(penaltyEvent.getPrimaryKey());

		penaltyEventImpl.setUuid(penaltyEvent.getUuid());
		penaltyEventImpl.setPenaltyEventId(penaltyEvent.getPenaltyEventId());
		penaltyEventImpl.setGroupId(penaltyEvent.getGroupId());
		penaltyEventImpl.setCompanyId(penaltyEvent.getCompanyId());
		penaltyEventImpl.setUserId(penaltyEvent.getUserId());
		penaltyEventImpl.setUserName(penaltyEvent.getUserName());
		penaltyEventImpl.setCreateDate(penaltyEvent.getCreateDate());
		penaltyEventImpl.setModifiedDate(penaltyEvent.getModifiedDate());
		penaltyEventImpl.setStudentId(penaltyEvent.getStudentId());
		penaltyEventImpl.setDisciplineEventId(penaltyEvent.getDisciplineEventId());
		penaltyEventImpl.setPenaltyCodeId(penaltyEvent.getPenaltyCodeId());
		penaltyEventImpl.setEventDescription(penaltyEvent.getEventDescription());
		penaltyEventImpl.setRemarks(penaltyEvent.getRemarks());
		penaltyEventImpl.setStudentLearningLogInd(penaltyEvent.getStudentLearningLogInd());
		penaltyEventImpl.setWebSAMSInd(penaltyEvent.getWebSAMSInd());
		penaltyEventImpl.setBrightFutureCompletedInd(penaltyEvent.getBrightFutureCompletedInd());
		penaltyEventImpl.setCopyReturnedInd(penaltyEvent.getCopyReturnedInd());
		penaltyEventImpl.setEventDate(penaltyEvent.getEventDate());

		return penaltyEventImpl;
	}

	/**
	 * Returns the penalty event with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the penalty event
	 * @return the penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByPrimaryKey(Serializable primaryKey)
		throws NoSuchPenaltyEventException, SystemException {
		PenaltyEvent penaltyEvent = fetchByPrimaryKey(primaryKey);

		if (penaltyEvent == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchPenaltyEventException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return penaltyEvent;
	}

	/**
	 * Returns the penalty event with the primary key or throws a {@link com.qc.qcsms.NoSuchPenaltyEventException} if it could not be found.
	 *
	 * @param penaltyEventId the primary key of the penalty event
	 * @return the penalty event
	 * @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent findByPrimaryKey(long penaltyEventId)
		throws NoSuchPenaltyEventException, SystemException {
		return findByPrimaryKey((Serializable)penaltyEventId);
	}

	/**
	 * Returns the penalty event with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the penalty event
	 * @return the penalty event, or <code>null</code> if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		PenaltyEvent penaltyEvent = (PenaltyEvent)EntityCacheUtil.getResult(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
				PenaltyEventImpl.class, primaryKey);

		if (penaltyEvent == _nullPenaltyEvent) {
			return null;
		}

		if (penaltyEvent == null) {
			Session session = null;

			try {
				session = openSession();

				penaltyEvent = (PenaltyEvent)session.get(PenaltyEventImpl.class,
						primaryKey);

				if (penaltyEvent != null) {
					cacheResult(penaltyEvent);
				}
				else {
					EntityCacheUtil.putResult(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
						PenaltyEventImpl.class, primaryKey, _nullPenaltyEvent);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(PenaltyEventModelImpl.ENTITY_CACHE_ENABLED,
					PenaltyEventImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return penaltyEvent;
	}

	/**
	 * Returns the penalty event with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param penaltyEventId the primary key of the penalty event
	 * @return the penalty event, or <code>null</code> if a penalty event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyEvent fetchByPrimaryKey(long penaltyEventId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)penaltyEventId);
	}

	/**
	 * Returns all the penalty events.
	 *
	 * @return the penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty events.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @return the range of penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty events.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of penalty events
	 * @param end the upper bound of the range of penalty events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyEvent> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<PenaltyEvent> list = (List<PenaltyEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_PENALTYEVENT);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_PENALTYEVENT;

				if (pagination) {
					sql = sql.concat(PenaltyEventModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyEvent>(list);
				}
				else {
					list = (List<PenaltyEvent>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the penalty events from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (PenaltyEvent penaltyEvent : findAll()) {
			remove(penaltyEvent);
		}
	}

	/**
	 * Returns the number of penalty events.
	 *
	 * @return the number of penalty events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_PENALTYEVENT);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the penalty event persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.qc.qcsms.model.PenaltyEvent")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<PenaltyEvent>> listenersList = new ArrayList<ModelListener<PenaltyEvent>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<PenaltyEvent>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(PenaltyEventImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_PENALTYEVENT = "SELECT penaltyEvent FROM PenaltyEvent penaltyEvent";
	private static final String _SQL_SELECT_PENALTYEVENT_WHERE = "SELECT penaltyEvent FROM PenaltyEvent penaltyEvent WHERE ";
	private static final String _SQL_COUNT_PENALTYEVENT = "SELECT COUNT(penaltyEvent) FROM PenaltyEvent penaltyEvent";
	private static final String _SQL_COUNT_PENALTYEVENT_WHERE = "SELECT COUNT(penaltyEvent) FROM PenaltyEvent penaltyEvent WHERE ";
	private static final String _FILTER_ENTITY_TABLE_FILTER_PK_COLUMN = "penaltyEvent.penaltyEventId";
	private static final String _FILTER_SQL_SELECT_PENALTYEVENT_WHERE = "SELECT DISTINCT {penaltyEvent.*} FROM QC_PenaltyEvent penaltyEvent WHERE ";
	private static final String _FILTER_SQL_SELECT_PENALTYEVENT_NO_INLINE_DISTINCT_WHERE_1 =
		"SELECT {QC_PenaltyEvent.*} FROM (SELECT DISTINCT penaltyEvent.penaltyEventId FROM QC_PenaltyEvent penaltyEvent WHERE ";
	private static final String _FILTER_SQL_SELECT_PENALTYEVENT_NO_INLINE_DISTINCT_WHERE_2 =
		") TEMP_TABLE INNER JOIN QC_PenaltyEvent ON TEMP_TABLE.penaltyEventId = QC_PenaltyEvent.penaltyEventId";
	private static final String _FILTER_SQL_COUNT_PENALTYEVENT_WHERE = "SELECT COUNT(DISTINCT penaltyEvent.penaltyEventId) AS COUNT_VALUE FROM QC_PenaltyEvent penaltyEvent WHERE ";
	private static final String _FILTER_ENTITY_ALIAS = "penaltyEvent";
	private static final String _FILTER_ENTITY_TABLE = "QC_PenaltyEvent";
	private static final String _ORDER_BY_ENTITY_ALIAS = "penaltyEvent.";
	private static final String _ORDER_BY_ENTITY_TABLE = "QC_PenaltyEvent.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No PenaltyEvent exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No PenaltyEvent exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(PenaltyEventPersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"uuid"
			});
	private static PenaltyEvent _nullPenaltyEvent = new PenaltyEventImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<PenaltyEvent> toCacheModel() {
				return _nullPenaltyEventCacheModel;
			}
		};

	private static CacheModel<PenaltyEvent> _nullPenaltyEventCacheModel = new CacheModel<PenaltyEvent>() {
			@Override
			public PenaltyEvent toEntityModel() {
				return _nullPenaltyEvent;
			}
		};
}