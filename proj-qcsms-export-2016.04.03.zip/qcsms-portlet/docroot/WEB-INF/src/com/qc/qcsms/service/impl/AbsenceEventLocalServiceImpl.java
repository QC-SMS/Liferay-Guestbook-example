/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.qc.qcsms.AbsenceEventDateException;
import com.qc.qcsms.AbsenceEventDescriptionLengthException;
import com.qc.qcsms.AbsenceEventWholeDayIndException;
import com.qc.qcsms.model.AbsenceCode;
import com.qc.qcsms.model.AbsenceEvent;
import com.qc.qcsms.model.Student;
import com.qc.qcsms.service.AbsenceCodeLocalServiceUtil;
import com.qc.qcsms.service.AbsenceEventLocalServiceUtil;
import com.qc.qcsms.service.StudentLocalServiceUtil;
import com.qc.qcsms.service.base.AbsenceEventLocalServiceBaseImpl;

/**
 * The implementation of the absence event local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.qc.qcsms.service.AbsenceEventLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author teddyku
 * @see com.qc.qcsms.service.base.AbsenceEventLocalServiceBaseImpl
 * @see com.qc.qcsms.service.AbsenceEventLocalServiceUtil
 */
public class AbsenceEventLocalServiceImpl
	extends AbsenceEventLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.qc.qcsms.service.AbsenceEventLocalServiceUtil} to access the absence event local service.
	 */
	public List<AbsenceEvent> getAbsenceEvents(long groupId) throws SystemException {
	    return absenceEventPersistence.findByGroupId(groupId);
	}

	public List<AbsenceEvent> getAbsenceEvents(long groupId, int start, int end)
	   throws SystemException {
	    return absenceEventPersistence.findByGroupId(groupId, start, end);
	}
	
	protected void validate (long absenceCodeId, long studentId, Date absenceDate, String absenceDescription, String wholeDayInd)
			 throws PortalException, SystemException {
		AbsenceCode absenceCode = AbsenceCodeLocalServiceUtil.getAbsenceCode(absenceCodeId);
		Student student = StudentLocalServiceUtil.getStudent(studentId);

 	    if (Validator.isNull(absenceDate)) {
 	    	throw new AbsenceEventDateException();
 	    }
	    if (Validator.isNotNull(absenceDescription) && absenceDescription.length() > 255) {
	    	throw new AbsenceEventDescriptionLengthException();
	    }
	    if (Validator.isNull(wholeDayInd) || !"W".equals(wholeDayInd) && !"H".equals(wholeDayInd)) {
	    	throw new AbsenceEventWholeDayIndException();
	    }
	}
	
	public AbsenceEvent addAbsenceEvent(long userId, long absenceCodeId, long studentId, Date absenceDate, String absenceDescription, String wholeDayInd,
		    ServiceContext serviceContext) throws SystemException, PortalException {
		long groupId = serviceContext.getScopeGroupId();
		User user = userPersistence.findByPrimaryKey(userId);
		Date now = new Date();
		validate(absenceCodeId, studentId, absenceDate, absenceDescription, wholeDayInd);

		long absenceEventId = counterLocalService.increment();
		AbsenceEvent absenceEvent = absenceEventPersistence.create(absenceEventId);

		absenceEvent.setUuid(serviceContext.getUuid());
		absenceEvent.setUserId(userId);
		absenceEvent.setGroupId(groupId);
		absenceEvent.setCompanyId(user.getCompanyId());
		absenceEvent.setUserName(user.getFullName());
		absenceEvent.setCreateDate(serviceContext.getCreateDate(now));
		absenceEvent.setModifiedDate(serviceContext.getModifiedDate(now));
		absenceEvent.setAbsenceCodeId(absenceCodeId);
		absenceEvent.setStudentId(studentId);
		absenceEvent.setAbsenceDate(absenceDate == null? absenceDate : truncateTime(absenceDate));
		absenceEvent.setAbsenceDescription(absenceDescription);
		absenceEvent.setWholeDayInd(wholeDayInd);
		absenceEvent.setExpandoBridgeAttributes(serviceContext);
		absenceEventPersistence.update(absenceEvent);

		resourceLocalService.addResources(user.getCompanyId(), groupId, userId,
			       AbsenceEvent.class.getName(), absenceEventId, false, true, true);
		return absenceEvent;
	}

	public AbsenceEvent updateAbsenceEvent(long userId, long absenceEventId, long absenceCodeId, long studentId, Date absenceDate, String absenceDescription, String wholeDayInd,
			ServiceContext serviceContext) throws PortalException, SystemException {
		Date now = new Date();
		validate(absenceCodeId, studentId, absenceDate, absenceDescription, wholeDayInd);
		AbsenceEvent absenceEvent = getAbsenceEvent(absenceEventId);
		
		User user = UserLocalServiceUtil.getUser(userId);
		absenceEvent.setUserId(userId);
		absenceEvent.setUserName(user.getFullName());
		absenceEvent.setModifiedDate(serviceContext.getModifiedDate(now));
		absenceEvent.setAbsenceCodeId(absenceCodeId);
		absenceEvent.setStudentId(studentId);
		absenceEvent.setAbsenceDate(absenceDate == null? absenceDate : truncateTime(absenceDate));
		absenceEvent.setAbsenceDescription(absenceDescription);
		absenceEvent.setWholeDayInd(wholeDayInd);
		absenceEvent.setExpandoBridgeAttributes(serviceContext);
		absenceEventPersistence.update(absenceEvent);
		resourceLocalService.updateResources(serviceContext.getCompanyId(),
		                serviceContext.getScopeGroupId(), AbsenceEvent.class.getName(), absenceEventId,
		                serviceContext.getGroupPermissions(),
		                serviceContext.getGuestPermissions());
		return absenceEvent;
	}
	
	public AbsenceEvent deleteAbsenceEvent(long absenceEventId,
            ServiceContext serviceContext) throws PortalException, SystemException {
		AbsenceEvent absenceEvent = getAbsenceEvent(absenceEventId);
	    resourceLocalService.deleteResource(serviceContext.getCompanyId(),
	                    AbsenceEvent.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
	                    absenceEventId);
	    absenceEvent = deleteAbsenceEvent(absenceEvent);
	    return absenceEvent;
	}
	
	public int getAbsenceEventCount(long groupId) throws SystemException {
        return absenceEventPersistence.countByGroupId(groupId);
	}

	public List getSearchAbsenceEvents(long absenceCodeId, long studentId, Date fromAbsenceDate, Date toAbsenceDate, String absenceDescription, String wholeDayInd, long userId,
			boolean andSearch, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		DynamicQuery dynamicQuery = buildAbsenceEventDynamicQuery(absenceCodeId, studentId, fromAbsenceDate == null? fromAbsenceDate : truncateTime(fromAbsenceDate), 
				toAbsenceDate == null? toAbsenceDate : truncateTime(toAbsenceDate), absenceDescription, wholeDayInd, userId, andSearch);
		return AbsenceEventLocalServiceUtil.dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	public int getSearchAbsenceEventCount(long absenceCodeId, long studentId, Date fromAbsenceDate, Date toAbsenceDate, String absenceDescription, String wholeDayInd, long userId, boolean andSearch) 
		throws SystemException {
		DynamicQuery dynamicQuery = buildAbsenceEventDynamicQuery(absenceCodeId, studentId, fromAbsenceDate == null? fromAbsenceDate : truncateTime(fromAbsenceDate), 
				toAbsenceDate == null? toAbsenceDate : truncateTime(toAbsenceDate), absenceDescription, wholeDayInd, userId, andSearch);
		return (int)AbsenceEventLocalServiceUtil.dynamicQueryCount(dynamicQuery);
	}

	protected DynamicQuery buildAbsenceEventDynamicQuery(long absenceCodeId, long studentId, Date fromAbsenceDate, Date toAbsenceDate, String absenceDescription, String wholeDayInd, long userId, boolean andSearch) {
		Junction junction = null;
		if(andSearch) {
			junction = RestrictionsFactoryUtil.conjunction();
		} else {
			junction = RestrictionsFactoryUtil.disjunction();
		}
		if(absenceCodeId > 0) {
			Property property = PropertyFactoryUtil.forName("absenceCodeId");
			junction.add(property.eq(Long.valueOf(absenceCodeId)));
		}
		if(studentId > 0) {
			Property property = PropertyFactoryUtil.forName("studentId");
			junction.add(property.eq(Long.valueOf(studentId)));
		}
		if (Validator.isNotNull(fromAbsenceDate)) {
			Property property = PropertyFactoryUtil.forName("absenceDate");
			junction.add(property.ge(fromAbsenceDate));
		}
		if (Validator.isNotNull(toAbsenceDate)) {
			Property property = PropertyFactoryUtil.forName("absenceDate");
			junction.add(property.le(toAbsenceDate));
		}
		if(Validator.isNotNull(absenceDescription)) {
			Property property = PropertyFactoryUtil.forName("absenceDescription");
			String value = (new StringBuilder("%")).append(absenceDescription).append("%").toString();
			junction.add(property.like(value));
		}
		if(Validator.isNotNull(wholeDayInd)) {
			Property property = PropertyFactoryUtil.forName("wholeDayInd");
			String value = (new StringBuilder("%")).append(wholeDayInd).append("%").toString();
			junction.add(property.like(value));
		}
		if(userId > 0) {
			Property property = PropertyFactoryUtil.forName("userId");
			junction.add(property.eq(Long.valueOf(userId)));
		}
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(AbsenceEvent.class, getClassLoader());
		return dynamicQuery.add(junction);
	}
	
	private Date truncateTime(Date tDate) {
		Calendar tCal = Calendar.getInstance();
		tCal.setTime(tDate);
		int tYear = tCal.get(Calendar.YEAR);
		int tMonth = tCal.get(Calendar.MONTH);
		int tDay = tCal.get(Calendar.DAY_OF_MONTH);
		tCal.set(tYear, tMonth, tDay, 0, 0);
		return tCal.getTime();
	}
}