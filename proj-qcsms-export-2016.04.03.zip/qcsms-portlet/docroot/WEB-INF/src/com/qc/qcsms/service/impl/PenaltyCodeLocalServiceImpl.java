/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.impl;

import java.util.Date;
import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.qc.qcsms.NoSuchPenaltyCodeException;
import com.qc.qcsms.PenaltyCodeException;
import com.qc.qcsms.PenaltyCodeLengthException;
import com.qc.qcsms.PenaltyCodeUniqueException;
import com.qc.qcsms.PenaltyDescriptionException;
import com.qc.qcsms.PenaltyDescriptionLengthException;
import com.qc.qcsms.model.PenaltyCode;
import com.qc.qcsms.service.PenaltyCodeLocalServiceUtil;
import com.qc.qcsms.service.base.PenaltyCodeLocalServiceBaseImpl;

/**
 * The implementation of the penalty code local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.qc.qcsms.service.PenaltyCodeLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author teddyku
 * @see com.qc.qcsms.service.base.PenaltyCodeLocalServiceBaseImpl
 * @see com.qc.qcsms.service.PenaltyCodeLocalServiceUtil
 */
public class PenaltyCodeLocalServiceImpl extends PenaltyCodeLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.qc.qcsms.service.PenaltyCodeLocalServiceUtil} to access the penalty code local service.
	 */
	public List<PenaltyCode> getPenaltyCodes(long groupId) throws SystemException {
	    return penaltyCodePersistence.findByGroupId(groupId);
	}

	public List<PenaltyCode> getPenaltyCodes(long groupId, int start, int end)
	   throws SystemException {
	    return penaltyCodePersistence.findByGroupId(groupId, start, end);
	}
	
	protected void validate (long penaltyCodeId, String code, String description) throws PortalException, SystemException {
	    if (Validator.isNull(code)) {
	    	throw new PenaltyCodeException();
	    }
	    if (code.length() > 3) {
	    	throw new PenaltyCodeLengthException();
	    }
	    if (Validator.isNull(description)) {
	    	throw new PenaltyDescriptionException();
	    }
	    if (description.length() > 255) {
	    	throw new PenaltyDescriptionLengthException();
	    }
	    try {
	    	PenaltyCode penaltyCode = penaltyCodePersistence.findByAssignedCode(code);
	    	if (penaltyCode.getPenaltyCodeId() != penaltyCodeId) throw new PenaltyCodeUniqueException();
	    }
	    catch(NoSuchPenaltyCodeException ex) {
	    	// Expected no record found
	    }
	}
	
	public PenaltyCode addPenaltyCode(long userId, String code, String description, 
		    ServiceContext serviceContext) throws SystemException, PortalException {
		long groupId = serviceContext.getScopeGroupId();
		User user = userPersistence.findByPrimaryKey(userId);
		Date now = new Date();
		validate(0, code, description);

		long penaltyCodeId = counterLocalService.increment();
		PenaltyCode penaltyCode = penaltyCodePersistence.create(penaltyCodeId);

		penaltyCode.setUuid(serviceContext.getUuid());
		penaltyCode.setUserId(userId);
		penaltyCode.setGroupId(groupId);
		penaltyCode.setCompanyId(user.getCompanyId());
		penaltyCode.setUserName(user.getFullName());
		penaltyCode.setCreateDate(serviceContext.getCreateDate(now));
		penaltyCode.setModifiedDate(serviceContext.getModifiedDate(now));
		penaltyCode.setAssignedCode(code);
		penaltyCode.setDescription(description);
		penaltyCode.setExpandoBridgeAttributes(serviceContext);
		penaltyCodePersistence.update(penaltyCode);

		resourceLocalService.addResources(user.getCompanyId(), groupId, userId,
			       PenaltyCode.class.getName(), penaltyCodeId, false, true, true);
		return penaltyCode;
	}

	public PenaltyCode updatePenaltyCode(long userId, long penaltyCodeId,
		String code, String description, ServiceContext serviceContext) throws PortalException, SystemException {
		Date now = new Date();
		validate(penaltyCodeId, code, description);
		PenaltyCode penaltyCode = getPenaltyCode(penaltyCodeId);
		
		User user = UserLocalServiceUtil.getUser(userId);
		penaltyCode.setUserId(userId);
		penaltyCode.setUserName(user.getFullName());
		penaltyCode.setModifiedDate(serviceContext.getModifiedDate(now));
		penaltyCode.setAssignedCode(code);
		penaltyCode.setDescription(description);
		penaltyCode.setExpandoBridgeAttributes(serviceContext);
		penaltyCodePersistence.update(penaltyCode);
		resourceLocalService.updateResources(serviceContext.getCompanyId(),
		                serviceContext.getScopeGroupId(), PenaltyCode.class.getName(), penaltyCodeId,
		                serviceContext.getGroupPermissions(),
		                serviceContext.getGuestPermissions());
		return penaltyCode;
	}
	
	public PenaltyCode deletePenaltyCode(long penaltyCodeId,
            ServiceContext serviceContext) throws PortalException, SystemException {
	    PenaltyCode penaltyCode = getPenaltyCode(penaltyCodeId);
	    resourceLocalService.deleteResource(serviceContext.getCompanyId(),
	                    PenaltyCode.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
	                    penaltyCodeId);
	    penaltyCode = deletePenaltyCode(penaltyCode);
	    return penaltyCode;
	}
	
	public int getPenaltyCodeCount(long groupId) throws SystemException {
        return penaltyCodePersistence.countByGroupId(groupId);
	}

	public List getSearchPenaltyCodes(String code, String description, boolean andSearch, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		DynamicQuery dynamicQuery = buildPenaltyCodeDynamicQuery(code, description, andSearch);
		return PenaltyCodeLocalServiceUtil.dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	public int getSearchPenaltyCodesCount(String code, String description, boolean andSearch) 
		throws SystemException {
		DynamicQuery dynamicQuery = buildPenaltyCodeDynamicQuery(code, description, andSearch);
		return (int)PenaltyCodeLocalServiceUtil.dynamicQueryCount(dynamicQuery);
	}

	protected DynamicQuery buildPenaltyCodeDynamicQuery(String code, String description, boolean andSearch) {
		Junction junction = null;
		if(andSearch) {
			junction = RestrictionsFactoryUtil.conjunction();
		} else {
			junction = RestrictionsFactoryUtil.disjunction();
		}
		if(Validator.isNotNull(code)) {
			Property property = PropertyFactoryUtil.forName("assignedCode");
			String value = (new StringBuilder("%")).append(code).append("%").toString();
			junction.add(property.like(value));
		}
		if(Validator.isNotNull(description)) {
			Property property = PropertyFactoryUtil.forName("description");
			String value = (new StringBuilder("%")).append(description).append("%").toString();
			junction.add(property.like(value));
		}
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(PenaltyCode.class, getClassLoader());
		return dynamicQuery.add(junction);
	}
}