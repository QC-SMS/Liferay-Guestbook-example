/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.impl;

import java.util.Date;
import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.qc.qcsms.ClassIdException;
import com.qc.qcsms.ClassNoException;
import com.qc.qcsms.ClassNoUniqueException;
import com.qc.qcsms.NoSuchStudentException;
import com.qc.qcsms.StudentNameException;
import com.qc.qcsms.StudentNameLengthException;
import com.qc.qcsms.model.Student;
import com.qc.qcsms.model.StudentClass;
import com.qc.qcsms.service.StudentClassLocalServiceUtil;
import com.qc.qcsms.service.base.StudentLocalServiceBaseImpl;

/**
 * The implementation of the student local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.qc.qcsms.service.StudentLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author teddyku
 * @see com.qc.qcsms.service.base.StudentLocalServiceBaseImpl
 * @see com.qc.qcsms.service.StudentLocalServiceUtil
 */
public class StudentLocalServiceImpl extends StudentLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.qc.qcsms.service.StudentLocalServiceUtil} to access the student local service.
	 */
	public List<Student> getStudents(long groupId) throws SystemException {
	    return studentPersistence.findByGroupId(groupId);
	}

	public List<Student> getStudents(long groupId, int start, int end)
	   throws SystemException {
	    return studentPersistence.findByGroupId(groupId, start, end);
	}
	
	protected void validate(long studentId, String studentName, long classId, int classNo) throws PortalException, SystemException {
	    if (Validator.isNull(studentName)) {
	    	throw new StudentNameException();
	    } 
	    if (studentName.length() > 255) {
	    	throw new StudentNameLengthException();
	    }
    	StudentClass studentClass = StudentClassLocalServiceUtil.getStudentClass(classId);
	    if (studentClass == null) {
	    	throw new ClassIdException();
	    }
	    if (classNo < 1) {
		       throw new ClassNoException();
	    } else {
	    	try {
	    		Student student = studentPersistence.findByClassNo(classId, classNo);
	    		if (student.getStudentId() != studentId) throw new ClassNoUniqueException();
	    	} 
	    	catch(NoSuchStudentException ex) {
		    	// Expected no student found
		    }
	    }
	}
	
	public Student addStudent(long userId, String studentName, long classId, int classNo, 
		    ServiceContext serviceContext) throws SystemException, PortalException {
		long groupId = serviceContext.getScopeGroupId();
		User user = userPersistence.findByPrimaryKey(userId);
		Date now = new Date();
		validate(0, studentName, classId, classNo);

		long studentId = counterLocalService.increment();
		Student student = studentPersistence.create(studentId);

		student.setUuid(serviceContext.getUuid());
		student.setUserId(userId);
		student.setGroupId(groupId);
		student.setCompanyId(user.getCompanyId());
		student.setUserName(user.getFullName());
		student.setCreateDate(serviceContext.getCreateDate(now));
		student.setModifiedDate(serviceContext.getModifiedDate(now));
		student.setStudentName(studentName);
		student.setClassId(classId);
		student.setClassNo(classNo);
		student.setExpandoBridgeAttributes(serviceContext);
		studentPersistence.update(student);

		resourceLocalService.addResources(user.getCompanyId(), groupId, userId,
			       Student.class.getName(), studentId, false, true, true);
		return student;
	}

	public Student updateStudent(long userId, long studentId,
		String studentName, long classId, int classNo, ServiceContext serviceContext) throws PortalException, SystemException {
		Date now = new Date();
		validate(studentId, studentName, classId, classNo);
		Student student = getStudent(studentId);
		
		User user = UserLocalServiceUtil.getUser(userId);
		student.setUserId(userId);
		student.setUserName(user.getFullName());
		student.setModifiedDate(serviceContext.getModifiedDate(now));
		student.setStudentName(studentName);
		student.setClassId(classId);
		student.setClassNo(classNo);
		student.setExpandoBridgeAttributes(serviceContext);
		studentPersistence.update(student);
		resourceLocalService.updateResources(serviceContext.getCompanyId(),
		                serviceContext.getScopeGroupId(), Student.class.getName(), studentId,
		                serviceContext.getGroupPermissions(),
		                serviceContext.getGuestPermissions());
		return student;
	}
	
	public Student deleteStudent(long studentId,
            ServiceContext serviceContext) throws PortalException, SystemException {
	    Student student = getStudent(studentId);
	    resourceLocalService.deleteResource(serviceContext.getCompanyId(),
	                    Student.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
	                    studentId);
	    student = deleteStudent(student);
	    return student;
	}
	
	public int getStudentCount(long groupId) throws SystemException {
        return studentPersistence.countByGroupId(groupId);
	}

	public List getSearchStudents(String studentName, long classId, int classNo, boolean andSearch, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		DynamicQuery dynamicQuery = buildStudentDynamicQuery(studentName, classId, classNo, andSearch);
		return StudentClassLocalServiceUtil.dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	public int getSearchStudentCount(String studentName, long classId, int classNo, boolean andSearch) 
		throws SystemException {
		DynamicQuery dynamicQuery = buildStudentDynamicQuery(studentName, classId, classNo, andSearch);
		return (int)StudentClassLocalServiceUtil.dynamicQueryCount(dynamicQuery);
	}

	protected DynamicQuery buildStudentDynamicQuery(String studentName, long classId, int classNo, boolean andSearch) {
		Junction junction = null;
		if(andSearch) {
			junction = RestrictionsFactoryUtil.conjunction();
		} else {
			junction = RestrictionsFactoryUtil.disjunction();
		}
		if(Validator.isNotNull(studentName)) {
			Property property = PropertyFactoryUtil.forName("studentName");
			String value = (new StringBuilder("%")).append(studentName).append("%").toString();
			junction.add(property.like(value));
		}
		if(classId > 0) {
			Property property = PropertyFactoryUtil.forName("classId");
			junction.add(property.eq(Long.valueOf(classId)));
		}
		if(classNo > 0) {
			Property property = PropertyFactoryUtil.forName("classNo");
			junction.add(property.eq(Integer.valueOf(classNo)));
		}
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(Student.class, getClassLoader());
		return dynamicQuery.add(junction);
	}
	
	public String getSelectOptionDescription(Student student) throws SystemException {
		String tString = "";
		if (student != null) {
			StudentClass tClass = StudentClassLocalServiceUtil.fetchStudentClass(student.getClassId());
			tString = tClass.getClassCode()+":"+student.getClassNo()+"-"+student.getStudentName();
		}
		return tString;
	}
}