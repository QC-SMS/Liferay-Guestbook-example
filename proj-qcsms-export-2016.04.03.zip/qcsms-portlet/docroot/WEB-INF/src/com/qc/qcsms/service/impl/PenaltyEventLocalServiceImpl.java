/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.qc.qcsms.PenaltyEventBrightFutureCompletedIndException;
import com.qc.qcsms.PenaltyEventCopyReturnedIndException;
import com.qc.qcsms.PenaltyEventDateException;
import com.qc.qcsms.PenaltyEventDescriptionException;
import com.qc.qcsms.PenaltyEventDescriptionLengthException;
import com.qc.qcsms.PenaltyEventRemarksLengthException;
import com.qc.qcsms.PenaltyEventStudentDisciplineEventMismatchException;
import com.qc.qcsms.PenaltyEventStudentLearningLogIndException;
import com.qc.qcsms.PenaltyEventWebSAMSIndException;
import com.qc.qcsms.model.DisciplineEvent;
import com.qc.qcsms.model.PenaltyCode;
import com.qc.qcsms.model.PenaltyEvent;
import com.qc.qcsms.model.Student;
import com.qc.qcsms.service.DisciplineEventLocalServiceUtil;
import com.qc.qcsms.service.PenaltyCodeLocalServiceUtil;
import com.qc.qcsms.service.PenaltyEventLocalServiceUtil;
import com.qc.qcsms.service.StudentLocalServiceUtil;
import com.qc.qcsms.service.base.PenaltyEventLocalServiceBaseImpl;

/**
 * The implementation of the penalty event local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.qc.qcsms.service.PenaltyEventLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author teddyku
 * @see com.qc.qcsms.service.base.PenaltyEventLocalServiceBaseImpl
 * @see com.qc.qcsms.service.PenaltyEventLocalServiceUtil
 */
public class PenaltyEventLocalServiceImpl
	extends PenaltyEventLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.qc.qcsms.service.PenaltyEventLocalServiceUtil} to access the penalty event local service.
	 */
	public List<PenaltyEvent> getPenaltyEvents(long groupId) throws SystemException {
	    return penaltyEventPersistence.findByGroupId(groupId);
	}

	public List<PenaltyEvent> getPenaltyEvents(long groupId, int start, int end)
	   throws SystemException {
	    return penaltyEventPersistence.findByGroupId(groupId, start, end);
	}
	
	protected void validate (long penaltyCodeId, long studentId, long disciplineEventId, Date eventDate, String eventDescription, String remarks,
			String studentLearningLogInd, String webSAMSInd, String brightFutureCompletedInd, String copyReturnedInd) throws PortalException, SystemException {
		PenaltyCode penaltyCode = PenaltyCodeLocalServiceUtil.getPenaltyCode(penaltyCodeId);
		Student student = StudentLocalServiceUtil.getStudent(studentId);
		if (Validator.isNotNull(disciplineEventId)) {
			DisciplineEvent disciplineEvent = DisciplineEventLocalServiceUtil.getDisciplineEvent(disciplineEventId);
			if (disciplineEvent.getStudentId() != studentId) {
				throw new PenaltyEventStudentDisciplineEventMismatchException();
			}
		}
 	    if (Validator.isNull(eventDate)) {
 	    	throw new PenaltyEventDateException();
 	    }
 	    if (Validator.isNull(eventDescription)) {
	    	throw new PenaltyEventDescriptionException();
	    }
	    if (eventDescription.length() > 255) {
	    	throw new PenaltyEventDescriptionLengthException();
	    }
	    if (Validator.isNotNull(remarks) && remarks.length() > 255) {
	    	throw new PenaltyEventRemarksLengthException();
	    }
	    if (Validator.isNull(studentLearningLogInd) || !"Y".equals(studentLearningLogInd) && !"N".equals(studentLearningLogInd)) {
	    	throw new PenaltyEventStudentLearningLogIndException();
	    }
	    if (Validator.isNull(webSAMSInd) || !"Y".equals(webSAMSInd) && !"N".equals(webSAMSInd)) {
	    	throw new PenaltyEventWebSAMSIndException();
	    }
	    if (Validator.isNull(brightFutureCompletedInd) || !"Y".equals(brightFutureCompletedInd) && !"N".equals(brightFutureCompletedInd)) {
	    	throw new PenaltyEventBrightFutureCompletedIndException();
	    }
	    if (Validator.isNull(copyReturnedInd) || !"Y".equals(copyReturnedInd) && !"N".equals(copyReturnedInd)) {
	    	throw new PenaltyEventCopyReturnedIndException();
	    }
	}
	
	public PenaltyEvent addPenaltyEvent(long userId, long penaltyCodeId, long studentId, long disciplineEventId, Date eventDate, String eventDescription, String remarks,
			String studentLearningLogInd, String webSAMSInd, String brightFutureCompletedInd, String copyReturnedInd,
		    ServiceContext serviceContext) throws SystemException, PortalException {
		long groupId = serviceContext.getScopeGroupId();
		User user = userPersistence.findByPrimaryKey(userId);
		Date now = new Date();
		validate(penaltyCodeId, studentId, disciplineEventId, eventDate, eventDescription, remarks, studentLearningLogInd, webSAMSInd, brightFutureCompletedInd, copyReturnedInd);

		long penaltyEventId = counterLocalService.increment();
		PenaltyEvent penaltyEvent = penaltyEventPersistence.create(penaltyEventId);

		penaltyEvent.setUuid(serviceContext.getUuid());
		penaltyEvent.setUserId(userId);
		penaltyEvent.setGroupId(groupId);
		penaltyEvent.setCompanyId(user.getCompanyId());
		penaltyEvent.setUserName(user.getFullName());
		penaltyEvent.setCreateDate(serviceContext.getCreateDate(now));
		penaltyEvent.setModifiedDate(serviceContext.getModifiedDate(now));
		penaltyEvent.setPenaltyCodeId(penaltyCodeId);
		penaltyEvent.setStudentId(studentId);
		penaltyEvent.setDisciplineEventId(disciplineEventId);
		penaltyEvent.setEventDate(eventDate == null? eventDate : truncateTime(eventDate));
		penaltyEvent.setEventDescription(eventDescription);
		penaltyEvent.setRemarks(remarks);
		penaltyEvent.setStudentLearningLogInd(studentLearningLogInd);
		penaltyEvent.setWebSAMSInd(webSAMSInd);
		penaltyEvent.setBrightFutureCompletedInd(brightFutureCompletedInd);
		penaltyEvent.setCopyReturnedInd(copyReturnedInd);
		penaltyEvent.setExpandoBridgeAttributes(serviceContext);
		penaltyEventPersistence.update(penaltyEvent);

		resourceLocalService.addResources(user.getCompanyId(), groupId, userId,
			       PenaltyEvent.class.getName(), penaltyEventId, false, true, true);
		return penaltyEvent;
	}

	public PenaltyEvent updatePenaltyEvent(long userId, long penaltyEventId, long penaltyCodeId, long studentId, long disciplineEventId, Date eventDate, String eventDescription, String remarks,
			String studentLearningLogInd, String webSAMSInd, String brightFutureCompletedInd, String copyReturnedInd,
			ServiceContext serviceContext) throws PortalException, SystemException {
		Date now = new Date();
		validate(penaltyCodeId, studentId, disciplineEventId, eventDate, eventDescription, remarks, studentLearningLogInd, webSAMSInd, brightFutureCompletedInd, copyReturnedInd);
		PenaltyEvent penaltyEvent = getPenaltyEvent(penaltyEventId);
		
		User user = UserLocalServiceUtil.getUser(userId);
		penaltyEvent.setUserId(userId);
		penaltyEvent.setUserName(user.getFullName());
		penaltyEvent.setModifiedDate(serviceContext.getModifiedDate(now));
		penaltyEvent.setPenaltyCodeId(penaltyCodeId);
		penaltyEvent.setStudentId(studentId);
		penaltyEvent.setDisciplineEventId(disciplineEventId);
		penaltyEvent.setEventDate(eventDate == null? eventDate : truncateTime(eventDate));
		penaltyEvent.setEventDescription(eventDescription);
		penaltyEvent.setRemarks(remarks);
		penaltyEvent.setStudentLearningLogInd(studentLearningLogInd);
		penaltyEvent.setWebSAMSInd(webSAMSInd);
		penaltyEvent.setBrightFutureCompletedInd(brightFutureCompletedInd);
		penaltyEvent.setCopyReturnedInd(copyReturnedInd);
		penaltyEvent.setExpandoBridgeAttributes(serviceContext);
		penaltyEventPersistence.update(penaltyEvent);
		resourceLocalService.updateResources(serviceContext.getCompanyId(),
		                serviceContext.getScopeGroupId(), PenaltyEvent.class.getName(), penaltyEventId,
		                serviceContext.getGroupPermissions(),
		                serviceContext.getGuestPermissions());
		return penaltyEvent;
	}
	
	public PenaltyEvent deletePenaltyEvent(long penaltyEventId,
            ServiceContext serviceContext) throws PortalException, SystemException {
		PenaltyEvent penaltyEvent = getPenaltyEvent(penaltyEventId);
	    resourceLocalService.deleteResource(serviceContext.getCompanyId(),
	                    PenaltyEvent.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
	                    penaltyEventId);
	    penaltyEvent = deletePenaltyEvent(penaltyEvent);
	    return penaltyEvent;
	}
	
	public int getPenaltyEventCount(long groupId) throws SystemException {
        return penaltyEventPersistence.countByGroupId(groupId);
	}

	public List getSearchPenaltyEvents(long penaltyCodeId, long studentId, long disciplineEventId, Date eventDate, String eventDescription, String remarks, 
			String studentLearningLogInd, String webSAMSInd, String brightFutureCompletedInd, String copyReturnedInd, boolean andSearch, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		DynamicQuery dynamicQuery = buildPenaltyEventDynamicQuery(penaltyCodeId, studentId, disciplineEventId, eventDate == null? eventDate : truncateTime(eventDate), eventDescription, remarks, studentLearningLogInd, webSAMSInd, brightFutureCompletedInd, copyReturnedInd, andSearch);
		return PenaltyEventLocalServiceUtil.dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	public int getSearchPenaltyEventCount(long penaltyCodeId, long studentId, long disciplineEventId, Date eventDate, String eventDescription, String remarks, 
			String studentLearningLogInd, String webSAMSInd, String brightFutureCompletedInd, String copyReturnedInd, boolean andSearch) 
		throws SystemException {
		DynamicQuery dynamicQuery = buildPenaltyEventDynamicQuery(penaltyCodeId, studentId, disciplineEventId, eventDate == null? eventDate : truncateTime(eventDate), eventDescription, remarks, studentLearningLogInd, webSAMSInd, brightFutureCompletedInd, copyReturnedInd, andSearch);
		return (int)PenaltyEventLocalServiceUtil.dynamicQueryCount(dynamicQuery);
	}

	protected DynamicQuery buildPenaltyEventDynamicQuery(long penaltyCodeId, long studentId, long disciplineEventId, Date eventDate, String eventDescription, String remarks, 
			String studentLearningLogInd, String webSAMSInd, String brightFutureCompletedInd, String copyReturnedInd, boolean andSearch) {
		Junction junction = null;
		if(andSearch) {
			junction = RestrictionsFactoryUtil.conjunction();
		} else {
			junction = RestrictionsFactoryUtil.disjunction();
		}
		if(penaltyCodeId > 0) {
			Property property = PropertyFactoryUtil.forName("penaltyCodeId");
			junction.add(property.eq(Long.valueOf(penaltyCodeId)));
		}
		if(studentId > 0) {
			Property property = PropertyFactoryUtil.forName("studentId");
			junction.add(property.eq(Long.valueOf(studentId)));
		}
		if(disciplineEventId > 0) {
			Property property = PropertyFactoryUtil.forName("disciplineEventId");
			junction.add(property.eq(Long.valueOf(disciplineEventId)));
		}
		if (Validator.isNotNull(eventDate)) {
			Property property = PropertyFactoryUtil.forName("eventDate");
			junction.add(property.eq(eventDate));
		}
		if(Validator.isNotNull(eventDescription)) {
			Property property = PropertyFactoryUtil.forName("eventDescription");
			String value = (new StringBuilder("%")).append(eventDescription).append("%").toString();
			junction.add(property.like(value));
		}
		if(Validator.isNotNull(remarks)) {
			Property property = PropertyFactoryUtil.forName("remarks");
			String value = (new StringBuilder("%")).append(remarks).append("%").toString();
			junction.add(property.like(value));
		}
		if(Validator.isNotNull(studentLearningLogInd)) {
			Property property = PropertyFactoryUtil.forName("studentLearningLogInd");
			String value = (new StringBuilder("%")).append(studentLearningLogInd).append("%").toString();
			junction.add(property.like(value));
		}
		if(Validator.isNotNull(webSAMSInd)) {
			Property property = PropertyFactoryUtil.forName("webSAMSInd");
			String value = (new StringBuilder("%")).append(webSAMSInd).append("%").toString();
			junction.add(property.like(value));
		}
		if(Validator.isNotNull(brightFutureCompletedInd)) {
			Property property = PropertyFactoryUtil.forName("brightFutureCompletedInd");
			String value = (new StringBuilder("%")).append(brightFutureCompletedInd).append("%").toString();
			junction.add(property.like(value));
		}
		if(Validator.isNotNull(copyReturnedInd)) {
			Property property = PropertyFactoryUtil.forName("copyReturnedInd");
			String value = (new StringBuilder("%")).append(copyReturnedInd).append("%").toString();
			junction.add(property.like(value));
		}
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(PenaltyEvent.class, getClassLoader());
		return dynamicQuery.add(junction);
	}
	
	private Date truncateTime(Date tDate) {
		Calendar tCal = Calendar.getInstance();
		tCal.setTime(tDate);
		int tYear = tCal.get(Calendar.YEAR);
		int tMonth = tCal.get(Calendar.MONTH);
		int tDay = tCal.get(Calendar.DAY_OF_MONTH);
		tCal.set(tYear, tMonth, tDay, 0, 0);
		return tCal.getTime();
	}
}