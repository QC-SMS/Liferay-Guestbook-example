/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.qc.qcsms.model.PenaltyCode;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing PenaltyCode in entity cache.
 *
 * @author teddyku
 * @see PenaltyCode
 * @generated
 */
public class PenaltyCodeCacheModel implements CacheModel<PenaltyCode>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", penaltyCodeId=");
		sb.append(penaltyCodeId);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", userName=");
		sb.append(userName);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", assignedCode=");
		sb.append(assignedCode);
		sb.append(", description=");
		sb.append(description);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public PenaltyCode toEntityModel() {
		PenaltyCodeImpl penaltyCodeImpl = new PenaltyCodeImpl();

		if (uuid == null) {
			penaltyCodeImpl.setUuid(StringPool.BLANK);
		}
		else {
			penaltyCodeImpl.setUuid(uuid);
		}

		penaltyCodeImpl.setPenaltyCodeId(penaltyCodeId);
		penaltyCodeImpl.setGroupId(groupId);
		penaltyCodeImpl.setCompanyId(companyId);
		penaltyCodeImpl.setUserId(userId);

		if (userName == null) {
			penaltyCodeImpl.setUserName(StringPool.BLANK);
		}
		else {
			penaltyCodeImpl.setUserName(userName);
		}

		if (createDate == Long.MIN_VALUE) {
			penaltyCodeImpl.setCreateDate(null);
		}
		else {
			penaltyCodeImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			penaltyCodeImpl.setModifiedDate(null);
		}
		else {
			penaltyCodeImpl.setModifiedDate(new Date(modifiedDate));
		}

		if (assignedCode == null) {
			penaltyCodeImpl.setAssignedCode(StringPool.BLANK);
		}
		else {
			penaltyCodeImpl.setAssignedCode(assignedCode);
		}

		if (description == null) {
			penaltyCodeImpl.setDescription(StringPool.BLANK);
		}
		else {
			penaltyCodeImpl.setDescription(description);
		}

		penaltyCodeImpl.resetOriginalValues();

		return penaltyCodeImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();
		penaltyCodeId = objectInput.readLong();
		groupId = objectInput.readLong();
		companyId = objectInput.readLong();
		userId = objectInput.readLong();
		userName = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
		assignedCode = objectInput.readUTF();
		description = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(penaltyCodeId);
		objectOutput.writeLong(groupId);
		objectOutput.writeLong(companyId);
		objectOutput.writeLong(userId);

		if (userName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userName);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);

		if (assignedCode == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(assignedCode);
		}

		if (description == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(description);
		}
	}

	public String uuid;
	public long penaltyCodeId;
	public long groupId;
	public long companyId;
	public long userId;
	public String userName;
	public long createDate;
	public long modifiedDate;
	public String assignedCode;
	public String description;
}