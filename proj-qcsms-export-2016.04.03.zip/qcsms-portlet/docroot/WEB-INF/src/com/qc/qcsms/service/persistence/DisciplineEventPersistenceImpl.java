/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.CalendarUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.security.permission.InlineSQLHelperUtil;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.qc.qcsms.NoSuchDisciplineEventException;
import com.qc.qcsms.model.DisciplineEvent;
import com.qc.qcsms.model.impl.DisciplineEventImpl;
import com.qc.qcsms.model.impl.DisciplineEventModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the discipline event service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see DisciplineEventPersistence
 * @see DisciplineEventUtil
 * @generated
 */
public class DisciplineEventPersistenceImpl extends BasePersistenceImpl<DisciplineEvent>
	implements DisciplineEventPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link DisciplineEventUtil} to access the discipline event persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = DisciplineEventImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByUuid",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
			new String[] { String.class.getName() },
			DisciplineEventModelImpl.UUID_COLUMN_BITMASK |
			DisciplineEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
			new String[] { String.class.getName() });

	/**
	 * Returns all the discipline events where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByUuid(String uuid)
		throws SystemException {
		return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discipline events where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @return the range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByUuid(String uuid, int start, int end)
		throws SystemException {
		return findByUuid(uuid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discipline events where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByUuid(String uuid, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid, start, end, orderByComparator };
		}

		List<DisciplineEvent> list = (List<DisciplineEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DisciplineEvent disciplineEvent : list) {
				if (!Validator.equals(uuid, disciplineEvent.getUuid())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				if (!pagination) {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DisciplineEvent>(list);
				}
				else {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discipline event in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByUuid_First(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByUuid_First(uuid,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the first discipline event in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByUuid_First(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		List<DisciplineEvent> list = findByUuid(uuid, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discipline event in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByUuid_Last(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByUuid_Last(uuid,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the last discipline event in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByUuid_Last(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid(uuid);

		if (count == 0) {
			return null;
		}

		List<DisciplineEvent> list = findByUuid(uuid, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discipline events before and after the current discipline event in the ordered set where uuid = &#63;.
	 *
	 * @param disciplineEventId the primary key of the current discipline event
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent[] findByUuid_PrevAndNext(long disciplineEventId,
		String uuid, OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = findByPrimaryKey(disciplineEventId);

		Session session = null;

		try {
			session = openSession();

			DisciplineEvent[] array = new DisciplineEventImpl[3];

			array[0] = getByUuid_PrevAndNext(session, disciplineEvent, uuid,
					orderByComparator, true);

			array[1] = disciplineEvent;

			array[2] = getByUuid_PrevAndNext(session, disciplineEvent, uuid,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DisciplineEvent getByUuid_PrevAndNext(Session session,
		DisciplineEvent disciplineEvent, String uuid,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_UUID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(disciplineEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DisciplineEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discipline events where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid(String uuid) throws SystemException {
		for (DisciplineEvent disciplineEvent : findByUuid(uuid,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(disciplineEvent);
		}
	}

	/**
	 * Returns the number of discipline events where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid(String uuid) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

		Object[] finderArgs = new Object[] { uuid };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCIPLINEEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_UUID_1 = "disciplineEvent.uuid IS NULL";
	private static final String _FINDER_COLUMN_UUID_UUID_2 = "disciplineEvent.uuid = ?";
	private static final String _FINDER_COLUMN_UUID_UUID_3 = "(disciplineEvent.uuid IS NULL OR disciplineEvent.uuid = '')";
	public static final FinderPath FINDER_PATH_FETCH_BY_UUID_G = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class, FINDER_CLASS_NAME_ENTITY,
			"fetchByUUID_G",
			new String[] { String.class.getName(), Long.class.getName() },
			DisciplineEventModelImpl.UUID_COLUMN_BITMASK |
			DisciplineEventModelImpl.GROUPID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID_G = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUUID_G",
			new String[] { String.class.getName(), Long.class.getName() });

	/**
	 * Returns the discipline event where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchDisciplineEventException} if it could not be found.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByUUID_G(String uuid, long groupId)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByUUID_G(uuid, groupId);

		if (disciplineEvent == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("uuid=");
			msg.append(uuid);

			msg.append(", groupId=");
			msg.append(groupId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchDisciplineEventException(msg.toString());
		}

		return disciplineEvent;
	}

	/**
	 * Returns the discipline event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByUUID_G(String uuid, long groupId)
		throws SystemException {
		return fetchByUUID_G(uuid, groupId, true);
	}

	/**
	 * Returns the discipline event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByUUID_G(String uuid, long groupId,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { uuid, groupId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_UUID_G,
					finderArgs, this);
		}

		if (result instanceof DisciplineEvent) {
			DisciplineEvent disciplineEvent = (DisciplineEvent)result;

			if (!Validator.equals(uuid, disciplineEvent.getUuid()) ||
					(groupId != disciplineEvent.getGroupId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_G_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(groupId);

				List<DisciplineEvent> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
						finderArgs, list);
				}
				else {
					DisciplineEvent disciplineEvent = list.get(0);

					result = disciplineEvent;

					cacheResult(disciplineEvent);

					if ((disciplineEvent.getUuid() == null) ||
							!disciplineEvent.getUuid().equals(uuid) ||
							(disciplineEvent.getGroupId() != groupId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
							finderArgs, disciplineEvent);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (DisciplineEvent)result;
		}
	}

	/**
	 * Removes the discipline event where uuid = &#63; and groupId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the discipline event that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent removeByUUID_G(String uuid, long groupId)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = findByUUID_G(uuid, groupId);

		return remove(disciplineEvent);
	}

	/**
	 * Returns the number of discipline events where uuid = &#63; and groupId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the number of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUUID_G(String uuid, long groupId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_G;

		Object[] finderArgs = new Object[] { uuid, groupId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_DISCIPLINEEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_G_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(groupId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_G_UUID_1 = "disciplineEvent.uuid IS NULL AND ";
	private static final String _FINDER_COLUMN_UUID_G_UUID_2 = "disciplineEvent.uuid = ? AND ";
	private static final String _FINDER_COLUMN_UUID_G_UUID_3 = "(disciplineEvent.uuid IS NULL OR disciplineEvent.uuid = '') AND ";
	private static final String _FINDER_COLUMN_UUID_G_GROUPID_2 = "disciplineEvent.groupId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByUuid_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C =
		new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid_C",
			new String[] { String.class.getName(), Long.class.getName() },
			DisciplineEventModelImpl.UUID_COLUMN_BITMASK |
			DisciplineEventModelImpl.COMPANYID_COLUMN_BITMASK |
			DisciplineEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID_C = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid_C",
			new String[] { String.class.getName(), Long.class.getName() });

	/**
	 * Returns all the discipline events where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByUuid_C(String uuid, long companyId)
		throws SystemException {
		return findByUuid_C(uuid, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discipline events where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @return the range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByUuid_C(String uuid, long companyId,
		int start, int end) throws SystemException {
		return findByUuid_C(uuid, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discipline events where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByUuid_C(String uuid, long companyId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C;
			finderArgs = new Object[] { uuid, companyId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C;
			finderArgs = new Object[] {
					uuid, companyId,
					
					start, end, orderByComparator
				};
		}

		List<DisciplineEvent> list = (List<DisciplineEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DisciplineEvent disciplineEvent : list) {
				if (!Validator.equals(uuid, disciplineEvent.getUuid()) ||
						(companyId != disciplineEvent.getCompanyId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_C_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DisciplineEvent>(list);
				}
				else {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discipline event in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByUuid_C_First(String uuid, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByUuid_C_First(uuid, companyId,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the first discipline event in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByUuid_C_First(String uuid, long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		List<DisciplineEvent> list = findByUuid_C(uuid, companyId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discipline event in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByUuid_C_Last(String uuid, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByUuid_C_Last(uuid, companyId,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the last discipline event in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByUuid_C_Last(String uuid, long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid_C(uuid, companyId);

		if (count == 0) {
			return null;
		}

		List<DisciplineEvent> list = findByUuid_C(uuid, companyId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discipline events before and after the current discipline event in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param disciplineEventId the primary key of the current discipline event
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent[] findByUuid_C_PrevAndNext(long disciplineEventId,
		String uuid, long companyId, OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = findByPrimaryKey(disciplineEventId);

		Session session = null;

		try {
			session = openSession();

			DisciplineEvent[] array = new DisciplineEventImpl[3];

			array[0] = getByUuid_C_PrevAndNext(session, disciplineEvent, uuid,
					companyId, orderByComparator, true);

			array[1] = disciplineEvent;

			array[2] = getByUuid_C_PrevAndNext(session, disciplineEvent, uuid,
					companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DisciplineEvent getByUuid_C_PrevAndNext(Session session,
		DisciplineEvent disciplineEvent, String uuid, long companyId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_C_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_C_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_C_UUID_2);
		}

		query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(disciplineEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DisciplineEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discipline events where uuid = &#63; and companyId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid_C(String uuid, long companyId)
		throws SystemException {
		for (DisciplineEvent disciplineEvent : findByUuid_C(uuid, companyId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(disciplineEvent);
		}
	}

	/**
	 * Returns the number of discipline events where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the number of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid_C(String uuid, long companyId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_C;

		Object[] finderArgs = new Object[] { uuid, companyId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_DISCIPLINEEVENT_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_C_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_C_UUID_1 = "disciplineEvent.uuid IS NULL AND ";
	private static final String _FINDER_COLUMN_UUID_C_UUID_2 = "disciplineEvent.uuid = ? AND ";
	private static final String _FINDER_COLUMN_UUID_C_UUID_3 = "(disciplineEvent.uuid IS NULL OR disciplineEvent.uuid = '') AND ";
	private static final String _FINDER_COLUMN_UUID_C_COMPANYID_2 = "disciplineEvent.companyId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_GROUPID = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByGroupId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID =
		new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByGroupId",
			new String[] { Long.class.getName() },
			DisciplineEventModelImpl.GROUPID_COLUMN_BITMASK |
			DisciplineEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_GROUPID = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByGroupId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the discipline events where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByGroupId(long groupId)
		throws SystemException {
		return findByGroupId(groupId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discipline events where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @return the range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByGroupId(long groupId, int start, int end)
		throws SystemException {
		return findByGroupId(groupId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discipline events where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByGroupId(long groupId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID;
			finderArgs = new Object[] { groupId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_GROUPID;
			finderArgs = new Object[] { groupId, start, end, orderByComparator };
		}

		List<DisciplineEvent> list = (List<DisciplineEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DisciplineEvent disciplineEvent : list) {
				if ((groupId != disciplineEvent.getGroupId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

			query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				if (!pagination) {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DisciplineEvent>(list);
				}
				else {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discipline event in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByGroupId_First(long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByGroupId_First(groupId,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the first discipline event in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByGroupId_First(long groupId,
		OrderByComparator orderByComparator) throws SystemException {
		List<DisciplineEvent> list = findByGroupId(groupId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discipline event in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByGroupId_Last(long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByGroupId_Last(groupId,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the last discipline event in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByGroupId_Last(long groupId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByGroupId(groupId);

		if (count == 0) {
			return null;
		}

		List<DisciplineEvent> list = findByGroupId(groupId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discipline events before and after the current discipline event in the ordered set where groupId = &#63;.
	 *
	 * @param disciplineEventId the primary key of the current discipline event
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent[] findByGroupId_PrevAndNext(long disciplineEventId,
		long groupId, OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = findByPrimaryKey(disciplineEventId);

		Session session = null;

		try {
			session = openSession();

			DisciplineEvent[] array = new DisciplineEventImpl[3];

			array[0] = getByGroupId_PrevAndNext(session, disciplineEvent,
					groupId, orderByComparator, true);

			array[1] = disciplineEvent;

			array[2] = getByGroupId_PrevAndNext(session, disciplineEvent,
					groupId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DisciplineEvent getByGroupId_PrevAndNext(Session session,
		DisciplineEvent disciplineEvent, long groupId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(groupId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(disciplineEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DisciplineEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Returns all the discipline events that the user has permission to view where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the matching discipline events that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> filterFindByGroupId(long groupId)
		throws SystemException {
		return filterFindByGroupId(groupId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discipline events that the user has permission to view where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @return the range of matching discipline events that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> filterFindByGroupId(long groupId, int start,
		int end) throws SystemException {
		return filterFindByGroupId(groupId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discipline events that the user has permissions to view where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discipline events that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> filterFindByGroupId(long groupId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return findByGroupId(groupId, start, end, orderByComparator);
		}

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(3 +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		if (getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_DISCIPLINEEVENT_WHERE);
		}
		else {
			query.append(_FILTER_SQL_SELECT_DISCIPLINEEVENT_NO_INLINE_DISTINCT_WHERE_1);
		}

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (!getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_DISCIPLINEEVENT_NO_INLINE_DISTINCT_WHERE_2);
		}

		if (orderByComparator != null) {
			if (getDB().isSupportsInlineDistinct()) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator, true);
			}
			else {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_TABLE,
					orderByComparator, true);
			}
		}
		else {
			if (getDB().isSupportsInlineDistinct()) {
				query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
			}
			else {
				query.append(DisciplineEventModelImpl.ORDER_BY_SQL);
			}
		}

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				DisciplineEvent.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		Session session = null;

		try {
			session = openSession();

			SQLQuery q = session.createSQLQuery(sql);

			if (getDB().isSupportsInlineDistinct()) {
				q.addEntity(_FILTER_ENTITY_ALIAS, DisciplineEventImpl.class);
			}
			else {
				q.addEntity(_FILTER_ENTITY_TABLE, DisciplineEventImpl.class);
			}

			QueryPos qPos = QueryPos.getInstance(q);

			qPos.add(groupId);

			return (List<DisciplineEvent>)QueryUtil.list(q, getDialect(),
				start, end);
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	/**
	 * Returns the discipline events before and after the current discipline event in the ordered set of discipline events that the user has permission to view where groupId = &#63;.
	 *
	 * @param disciplineEventId the primary key of the current discipline event
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent[] filterFindByGroupId_PrevAndNext(
		long disciplineEventId, long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return findByGroupId_PrevAndNext(disciplineEventId, groupId,
				orderByComparator);
		}

		DisciplineEvent disciplineEvent = findByPrimaryKey(disciplineEventId);

		Session session = null;

		try {
			session = openSession();

			DisciplineEvent[] array = new DisciplineEventImpl[3];

			array[0] = filterGetByGroupId_PrevAndNext(session, disciplineEvent,
					groupId, orderByComparator, true);

			array[1] = disciplineEvent;

			array[2] = filterGetByGroupId_PrevAndNext(session, disciplineEvent,
					groupId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DisciplineEvent filterGetByGroupId_PrevAndNext(Session session,
		DisciplineEvent disciplineEvent, long groupId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		if (getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_DISCIPLINEEVENT_WHERE);
		}
		else {
			query.append(_FILTER_SQL_SELECT_DISCIPLINEEVENT_NO_INLINE_DISTINCT_WHERE_1);
		}

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (!getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_DISCIPLINEEVENT_NO_INLINE_DISTINCT_WHERE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				if (getDB().isSupportsInlineDistinct()) {
					query.append(_ORDER_BY_ENTITY_ALIAS);
				}
				else {
					query.append(_ORDER_BY_ENTITY_TABLE);
				}

				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				if (getDB().isSupportsInlineDistinct()) {
					query.append(_ORDER_BY_ENTITY_ALIAS);
				}
				else {
					query.append(_ORDER_BY_ENTITY_TABLE);
				}

				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			if (getDB().isSupportsInlineDistinct()) {
				query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
			}
			else {
				query.append(DisciplineEventModelImpl.ORDER_BY_SQL);
			}
		}

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				DisciplineEvent.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		SQLQuery q = session.createSQLQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		if (getDB().isSupportsInlineDistinct()) {
			q.addEntity(_FILTER_ENTITY_ALIAS, DisciplineEventImpl.class);
		}
		else {
			q.addEntity(_FILTER_ENTITY_TABLE, DisciplineEventImpl.class);
		}

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(groupId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(disciplineEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DisciplineEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discipline events where groupId = &#63; from the database.
	 *
	 * @param groupId the group ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByGroupId(long groupId) throws SystemException {
		for (DisciplineEvent disciplineEvent : findByGroupId(groupId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(disciplineEvent);
		}
	}

	/**
	 * Returns the number of discipline events where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the number of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByGroupId(long groupId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_GROUPID;

		Object[] finderArgs = new Object[] { groupId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCIPLINEEVENT_WHERE);

			query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of discipline events that the user has permission to view where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the number of matching discipline events that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int filterCountByGroupId(long groupId) throws SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return countByGroupId(groupId);
		}

		StringBundler query = new StringBundler(2);

		query.append(_FILTER_SQL_COUNT_DISCIPLINEEVENT_WHERE);

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				DisciplineEvent.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		Session session = null;

		try {
			session = openSession();

			SQLQuery q = session.createSQLQuery(sql);

			q.addScalar(COUNT_COLUMN_NAME,
				com.liferay.portal.kernel.dao.orm.Type.LONG);

			QueryPos qPos = QueryPos.getInstance(q);

			qPos.add(groupId);

			Long count = (Long)q.uniqueResult();

			return count.intValue();
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	private static final String _FINDER_COLUMN_GROUPID_GROUPID_2 = "disciplineEvent.groupId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_STUDENTID =
		new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByStudentId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STUDENTID =
		new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByStudentId",
			new String[] { Long.class.getName() },
			DisciplineEventModelImpl.STUDENTID_COLUMN_BITMASK |
			DisciplineEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_STUDENTID = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByStudentId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the discipline events where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @return the matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByStudentId(long studentId)
		throws SystemException {
		return findByStudentId(studentId, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the discipline events where studentId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param studentId the student ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @return the range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByStudentId(long studentId, int start,
		int end) throws SystemException {
		return findByStudentId(studentId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discipline events where studentId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param studentId the student ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByStudentId(long studentId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STUDENTID;
			finderArgs = new Object[] { studentId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_STUDENTID;
			finderArgs = new Object[] { studentId, start, end, orderByComparator };
		}

		List<DisciplineEvent> list = (List<DisciplineEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DisciplineEvent disciplineEvent : list) {
				if ((studentId != disciplineEvent.getStudentId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

			query.append(_FINDER_COLUMN_STUDENTID_STUDENTID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(studentId);

				if (!pagination) {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DisciplineEvent>(list);
				}
				else {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discipline event in the ordered set where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByStudentId_First(long studentId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByStudentId_First(studentId,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("studentId=");
		msg.append(studentId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the first discipline event in the ordered set where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByStudentId_First(long studentId,
		OrderByComparator orderByComparator) throws SystemException {
		List<DisciplineEvent> list = findByStudentId(studentId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discipline event in the ordered set where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByStudentId_Last(long studentId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByStudentId_Last(studentId,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("studentId=");
		msg.append(studentId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the last discipline event in the ordered set where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByStudentId_Last(long studentId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByStudentId(studentId);

		if (count == 0) {
			return null;
		}

		List<DisciplineEvent> list = findByStudentId(studentId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discipline events before and after the current discipline event in the ordered set where studentId = &#63;.
	 *
	 * @param disciplineEventId the primary key of the current discipline event
	 * @param studentId the student ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent[] findByStudentId_PrevAndNext(
		long disciplineEventId, long studentId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = findByPrimaryKey(disciplineEventId);

		Session session = null;

		try {
			session = openSession();

			DisciplineEvent[] array = new DisciplineEventImpl[3];

			array[0] = getByStudentId_PrevAndNext(session, disciplineEvent,
					studentId, orderByComparator, true);

			array[1] = disciplineEvent;

			array[2] = getByStudentId_PrevAndNext(session, disciplineEvent,
					studentId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DisciplineEvent getByStudentId_PrevAndNext(Session session,
		DisciplineEvent disciplineEvent, long studentId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

		query.append(_FINDER_COLUMN_STUDENTID_STUDENTID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(studentId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(disciplineEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DisciplineEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discipline events where studentId = &#63; from the database.
	 *
	 * @param studentId the student ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByStudentId(long studentId) throws SystemException {
		for (DisciplineEvent disciplineEvent : findByStudentId(studentId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(disciplineEvent);
		}
	}

	/**
	 * Returns the number of discipline events where studentId = &#63;.
	 *
	 * @param studentId the student ID
	 * @return the number of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByStudentId(long studentId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_STUDENTID;

		Object[] finderArgs = new Object[] { studentId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCIPLINEEVENT_WHERE);

			query.append(_FINDER_COLUMN_STUDENTID_STUDENTID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(studentId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_STUDENTID_STUDENTID_2 = "disciplineEvent.studentId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_DISCIPLINECODE =
		new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByDisciplineCode",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCIPLINECODE =
		new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByDisciplineCode",
			new String[] { Long.class.getName() },
			DisciplineEventModelImpl.DISCIPLINECODEID_COLUMN_BITMASK |
			DisciplineEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_DISCIPLINECODE = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByDisciplineCode",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the discipline events where disciplineCodeId = &#63;.
	 *
	 * @param disciplineCodeId the discipline code ID
	 * @return the matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByDisciplineCode(long disciplineCodeId)
		throws SystemException {
		return findByDisciplineCode(disciplineCodeId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discipline events where disciplineCodeId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param disciplineCodeId the discipline code ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @return the range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByDisciplineCode(long disciplineCodeId,
		int start, int end) throws SystemException {
		return findByDisciplineCode(disciplineCodeId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discipline events where disciplineCodeId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param disciplineCodeId the discipline code ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByDisciplineCode(long disciplineCodeId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCIPLINECODE;
			finderArgs = new Object[] { disciplineCodeId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_DISCIPLINECODE;
			finderArgs = new Object[] {
					disciplineCodeId,
					
					start, end, orderByComparator
				};
		}

		List<DisciplineEvent> list = (List<DisciplineEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DisciplineEvent disciplineEvent : list) {
				if ((disciplineCodeId != disciplineEvent.getDisciplineCodeId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

			query.append(_FINDER_COLUMN_DISCIPLINECODE_DISCIPLINECODEID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(disciplineCodeId);

				if (!pagination) {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DisciplineEvent>(list);
				}
				else {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discipline event in the ordered set where disciplineCodeId = &#63;.
	 *
	 * @param disciplineCodeId the discipline code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByDisciplineCode_First(long disciplineCodeId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByDisciplineCode_First(disciplineCodeId,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("disciplineCodeId=");
		msg.append(disciplineCodeId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the first discipline event in the ordered set where disciplineCodeId = &#63;.
	 *
	 * @param disciplineCodeId the discipline code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByDisciplineCode_First(long disciplineCodeId,
		OrderByComparator orderByComparator) throws SystemException {
		List<DisciplineEvent> list = findByDisciplineCode(disciplineCodeId, 0,
				1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discipline event in the ordered set where disciplineCodeId = &#63;.
	 *
	 * @param disciplineCodeId the discipline code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByDisciplineCode_Last(long disciplineCodeId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByDisciplineCode_Last(disciplineCodeId,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("disciplineCodeId=");
		msg.append(disciplineCodeId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the last discipline event in the ordered set where disciplineCodeId = &#63;.
	 *
	 * @param disciplineCodeId the discipline code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByDisciplineCode_Last(long disciplineCodeId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByDisciplineCode(disciplineCodeId);

		if (count == 0) {
			return null;
		}

		List<DisciplineEvent> list = findByDisciplineCode(disciplineCodeId,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discipline events before and after the current discipline event in the ordered set where disciplineCodeId = &#63;.
	 *
	 * @param disciplineEventId the primary key of the current discipline event
	 * @param disciplineCodeId the discipline code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent[] findByDisciplineCode_PrevAndNext(
		long disciplineEventId, long disciplineCodeId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = findByPrimaryKey(disciplineEventId);

		Session session = null;

		try {
			session = openSession();

			DisciplineEvent[] array = new DisciplineEventImpl[3];

			array[0] = getByDisciplineCode_PrevAndNext(session,
					disciplineEvent, disciplineCodeId, orderByComparator, true);

			array[1] = disciplineEvent;

			array[2] = getByDisciplineCode_PrevAndNext(session,
					disciplineEvent, disciplineCodeId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DisciplineEvent getByDisciplineCode_PrevAndNext(Session session,
		DisciplineEvent disciplineEvent, long disciplineCodeId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

		query.append(_FINDER_COLUMN_DISCIPLINECODE_DISCIPLINECODEID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(disciplineCodeId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(disciplineEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DisciplineEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discipline events where disciplineCodeId = &#63; from the database.
	 *
	 * @param disciplineCodeId the discipline code ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByDisciplineCode(long disciplineCodeId)
		throws SystemException {
		for (DisciplineEvent disciplineEvent : findByDisciplineCode(
				disciplineCodeId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(disciplineEvent);
		}
	}

	/**
	 * Returns the number of discipline events where disciplineCodeId = &#63;.
	 *
	 * @param disciplineCodeId the discipline code ID
	 * @return the number of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByDisciplineCode(long disciplineCodeId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_DISCIPLINECODE;

		Object[] finderArgs = new Object[] { disciplineCodeId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCIPLINEEVENT_WHERE);

			query.append(_FINDER_COLUMN_DISCIPLINECODE_DISCIPLINECODEID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(disciplineCodeId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_DISCIPLINECODE_DISCIPLINECODEID_2 =
		"disciplineEvent.disciplineCodeId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_EVENTDATE =
		new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByEventDate",
			new String[] {
				Date.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EVENTDATE =
		new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByEventDate",
			new String[] { Date.class.getName() },
			DisciplineEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_EVENTDATE = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByEventDate",
			new String[] { Date.class.getName() });

	/**
	 * Returns all the discipline events where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @return the matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByEventDate(Date eventDate)
		throws SystemException {
		return findByEventDate(eventDate, QueryUtil.ALL_POS, QueryUtil.ALL_POS,
			null);
	}

	/**
	 * Returns a range of all the discipline events where eventDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param eventDate the event date
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @return the range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByEventDate(Date eventDate, int start,
		int end) throws SystemException {
		return findByEventDate(eventDate, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discipline events where eventDate = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param eventDate the event date
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByEventDate(Date eventDate, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EVENTDATE;
			finderArgs = new Object[] { eventDate };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_EVENTDATE;
			finderArgs = new Object[] { eventDate, start, end, orderByComparator };
		}

		List<DisciplineEvent> list = (List<DisciplineEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DisciplineEvent disciplineEvent : list) {
				if (!Validator.equals(eventDate, disciplineEvent.getEventDate())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

			boolean bindEventDate = false;

			if (eventDate == null) {
				query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_1);
			}
			else {
				bindEventDate = true;

				query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEventDate) {
					qPos.add(CalendarUtil.getTimestamp(eventDate));
				}

				if (!pagination) {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DisciplineEvent>(list);
				}
				else {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discipline event in the ordered set where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByEventDate_First(Date eventDate,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByEventDate_First(eventDate,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("eventDate=");
		msg.append(eventDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the first discipline event in the ordered set where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByEventDate_First(Date eventDate,
		OrderByComparator orderByComparator) throws SystemException {
		List<DisciplineEvent> list = findByEventDate(eventDate, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discipline event in the ordered set where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByEventDate_Last(Date eventDate,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByEventDate_Last(eventDate,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("eventDate=");
		msg.append(eventDate);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the last discipline event in the ordered set where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByEventDate_Last(Date eventDate,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByEventDate(eventDate);

		if (count == 0) {
			return null;
		}

		List<DisciplineEvent> list = findByEventDate(eventDate, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discipline events before and after the current discipline event in the ordered set where eventDate = &#63;.
	 *
	 * @param disciplineEventId the primary key of the current discipline event
	 * @param eventDate the event date
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent[] findByEventDate_PrevAndNext(
		long disciplineEventId, Date eventDate,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = findByPrimaryKey(disciplineEventId);

		Session session = null;

		try {
			session = openSession();

			DisciplineEvent[] array = new DisciplineEventImpl[3];

			array[0] = getByEventDate_PrevAndNext(session, disciplineEvent,
					eventDate, orderByComparator, true);

			array[1] = disciplineEvent;

			array[2] = getByEventDate_PrevAndNext(session, disciplineEvent,
					eventDate, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DisciplineEvent getByEventDate_PrevAndNext(Session session,
		DisciplineEvent disciplineEvent, Date eventDate,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

		boolean bindEventDate = false;

		if (eventDate == null) {
			query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_1);
		}
		else {
			bindEventDate = true;

			query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindEventDate) {
			qPos.add(CalendarUtil.getTimestamp(eventDate));
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(disciplineEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DisciplineEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discipline events where eventDate = &#63; from the database.
	 *
	 * @param eventDate the event date
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByEventDate(Date eventDate) throws SystemException {
		for (DisciplineEvent disciplineEvent : findByEventDate(eventDate,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(disciplineEvent);
		}
	}

	/**
	 * Returns the number of discipline events where eventDate = &#63;.
	 *
	 * @param eventDate the event date
	 * @return the number of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByEventDate(Date eventDate) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_EVENTDATE;

		Object[] finderArgs = new Object[] { eventDate };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCIPLINEEVENT_WHERE);

			boolean bindEventDate = false;

			if (eventDate == null) {
				query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_1);
			}
			else {
				bindEventDate = true;

				query.append(_FINDER_COLUMN_EVENTDATE_EVENTDATE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindEventDate) {
					qPos.add(CalendarUtil.getTimestamp(eventDate));
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_EVENTDATE_EVENTDATE_1 = "disciplineEvent.eventDate IS NULL";
	private static final String _FINDER_COLUMN_EVENTDATE_EVENTDATE_2 = "disciplineEvent.eventDate = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_PENALTYCODE =
		new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class, FINDER_CLASS_NAME_LIST_WITH_PAGINATION,
			"findByPenaltyCode",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PENALTYCODE =
		new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED,
			DisciplineEventImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByPenaltyCode",
			new String[] { Long.class.getName() },
			DisciplineEventModelImpl.PENALTYCODEID_COLUMN_BITMASK |
			DisciplineEventModelImpl.EVENTDATE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_PENALTYCODE = new FinderPath(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByPenaltyCode",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the discipline events where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @return the matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByPenaltyCode(long penaltyCodeId)
		throws SystemException {
		return findByPenaltyCode(penaltyCodeId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discipline events where penaltyCodeId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @return the range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByPenaltyCode(long penaltyCodeId,
		int start, int end) throws SystemException {
		return findByPenaltyCode(penaltyCodeId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the discipline events where penaltyCodeId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findByPenaltyCode(long penaltyCodeId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PENALTYCODE;
			finderArgs = new Object[] { penaltyCodeId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_PENALTYCODE;
			finderArgs = new Object[] {
					penaltyCodeId,
					
					start, end, orderByComparator
				};
		}

		List<DisciplineEvent> list = (List<DisciplineEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (DisciplineEvent disciplineEvent : list) {
				if ((penaltyCodeId != disciplineEvent.getPenaltyCodeId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

			query.append(_FINDER_COLUMN_PENALTYCODE_PENALTYCODEID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(penaltyCodeId);

				if (!pagination) {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DisciplineEvent>(list);
				}
				else {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first discipline event in the ordered set where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByPenaltyCode_First(long penaltyCodeId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByPenaltyCode_First(penaltyCodeId,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("penaltyCodeId=");
		msg.append(penaltyCodeId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the first discipline event in the ordered set where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByPenaltyCode_First(long penaltyCodeId,
		OrderByComparator orderByComparator) throws SystemException {
		List<DisciplineEvent> list = findByPenaltyCode(penaltyCodeId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last discipline event in the ordered set where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByPenaltyCode_Last(long penaltyCodeId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByPenaltyCode_Last(penaltyCodeId,
				orderByComparator);

		if (disciplineEvent != null) {
			return disciplineEvent;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("penaltyCodeId=");
		msg.append(penaltyCodeId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchDisciplineEventException(msg.toString());
	}

	/**
	 * Returns the last discipline event in the ordered set where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByPenaltyCode_Last(long penaltyCodeId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByPenaltyCode(penaltyCodeId);

		if (count == 0) {
			return null;
		}

		List<DisciplineEvent> list = findByPenaltyCode(penaltyCodeId,
				count - 1, count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the discipline events before and after the current discipline event in the ordered set where penaltyCodeId = &#63;.
	 *
	 * @param disciplineEventId the primary key of the current discipline event
	 * @param penaltyCodeId the penalty code ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent[] findByPenaltyCode_PrevAndNext(
		long disciplineEventId, long penaltyCodeId,
		OrderByComparator orderByComparator)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = findByPrimaryKey(disciplineEventId);

		Session session = null;

		try {
			session = openSession();

			DisciplineEvent[] array = new DisciplineEventImpl[3];

			array[0] = getByPenaltyCode_PrevAndNext(session, disciplineEvent,
					penaltyCodeId, orderByComparator, true);

			array[1] = disciplineEvent;

			array[2] = getByPenaltyCode_PrevAndNext(session, disciplineEvent,
					penaltyCodeId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected DisciplineEvent getByPenaltyCode_PrevAndNext(Session session,
		DisciplineEvent disciplineEvent, long penaltyCodeId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_DISCIPLINEEVENT_WHERE);

		query.append(_FINDER_COLUMN_PENALTYCODE_PENALTYCODEID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(DisciplineEventModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(penaltyCodeId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(disciplineEvent);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<DisciplineEvent> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the discipline events where penaltyCodeId = &#63; from the database.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByPenaltyCode(long penaltyCodeId)
		throws SystemException {
		for (DisciplineEvent disciplineEvent : findByPenaltyCode(
				penaltyCodeId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(disciplineEvent);
		}
	}

	/**
	 * Returns the number of discipline events where penaltyCodeId = &#63;.
	 *
	 * @param penaltyCodeId the penalty code ID
	 * @return the number of matching discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByPenaltyCode(long penaltyCodeId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_PENALTYCODE;

		Object[] finderArgs = new Object[] { penaltyCodeId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_DISCIPLINEEVENT_WHERE);

			query.append(_FINDER_COLUMN_PENALTYCODE_PENALTYCODEID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(penaltyCodeId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_PENALTYCODE_PENALTYCODEID_2 = "disciplineEvent.penaltyCodeId = ?";

	public DisciplineEventPersistenceImpl() {
		setModelClass(DisciplineEvent.class);
	}

	/**
	 * Caches the discipline event in the entity cache if it is enabled.
	 *
	 * @param disciplineEvent the discipline event
	 */
	@Override
	public void cacheResult(DisciplineEvent disciplineEvent) {
		EntityCacheUtil.putResult(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventImpl.class, disciplineEvent.getPrimaryKey(),
			disciplineEvent);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
			new Object[] { disciplineEvent.getUuid(), disciplineEvent.getGroupId() },
			disciplineEvent);

		disciplineEvent.resetOriginalValues();
	}

	/**
	 * Caches the discipline events in the entity cache if it is enabled.
	 *
	 * @param disciplineEvents the discipline events
	 */
	@Override
	public void cacheResult(List<DisciplineEvent> disciplineEvents) {
		for (DisciplineEvent disciplineEvent : disciplineEvents) {
			if (EntityCacheUtil.getResult(
						DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
						DisciplineEventImpl.class,
						disciplineEvent.getPrimaryKey()) == null) {
				cacheResult(disciplineEvent);
			}
			else {
				disciplineEvent.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all discipline events.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(DisciplineEventImpl.class.getName());
		}

		EntityCacheUtil.clearCache(DisciplineEventImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the discipline event.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(DisciplineEvent disciplineEvent) {
		EntityCacheUtil.removeResult(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventImpl.class, disciplineEvent.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(disciplineEvent);
	}

	@Override
	public void clearCache(List<DisciplineEvent> disciplineEvents) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (DisciplineEvent disciplineEvent : disciplineEvents) {
			EntityCacheUtil.removeResult(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
				DisciplineEventImpl.class, disciplineEvent.getPrimaryKey());

			clearUniqueFindersCache(disciplineEvent);
		}
	}

	protected void cacheUniqueFindersCache(DisciplineEvent disciplineEvent) {
		if (disciplineEvent.isNew()) {
			Object[] args = new Object[] {
					disciplineEvent.getUuid(), disciplineEvent.getGroupId()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
				disciplineEvent);
		}
		else {
			DisciplineEventModelImpl disciplineEventModelImpl = (DisciplineEventModelImpl)disciplineEvent;

			if ((disciplineEventModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						disciplineEvent.getUuid(), disciplineEvent.getGroupId()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
					Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
					disciplineEvent);
			}
		}
	}

	protected void clearUniqueFindersCache(DisciplineEvent disciplineEvent) {
		DisciplineEventModelImpl disciplineEventModelImpl = (DisciplineEventModelImpl)disciplineEvent;

		Object[] args = new Object[] {
				disciplineEvent.getUuid(), disciplineEvent.getGroupId()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);

		if ((disciplineEventModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
			args = new Object[] {
					disciplineEventModelImpl.getOriginalUuid(),
					disciplineEventModelImpl.getOriginalGroupId()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);
		}
	}

	/**
	 * Creates a new discipline event with the primary key. Does not add the discipline event to the database.
	 *
	 * @param disciplineEventId the primary key for the new discipline event
	 * @return the new discipline event
	 */
	@Override
	public DisciplineEvent create(long disciplineEventId) {
		DisciplineEvent disciplineEvent = new DisciplineEventImpl();

		disciplineEvent.setNew(true);
		disciplineEvent.setPrimaryKey(disciplineEventId);

		String uuid = PortalUUIDUtil.generate();

		disciplineEvent.setUuid(uuid);

		return disciplineEvent;
	}

	/**
	 * Removes the discipline event with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param disciplineEventId the primary key of the discipline event
	 * @return the discipline event that was removed
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent remove(long disciplineEventId)
		throws NoSuchDisciplineEventException, SystemException {
		return remove((Serializable)disciplineEventId);
	}

	/**
	 * Removes the discipline event with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the discipline event
	 * @return the discipline event that was removed
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent remove(Serializable primaryKey)
		throws NoSuchDisciplineEventException, SystemException {
		Session session = null;

		try {
			session = openSession();

			DisciplineEvent disciplineEvent = (DisciplineEvent)session.get(DisciplineEventImpl.class,
					primaryKey);

			if (disciplineEvent == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchDisciplineEventException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(disciplineEvent);
		}
		catch (NoSuchDisciplineEventException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected DisciplineEvent removeImpl(DisciplineEvent disciplineEvent)
		throws SystemException {
		disciplineEvent = toUnwrappedModel(disciplineEvent);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(disciplineEvent)) {
				disciplineEvent = (DisciplineEvent)session.get(DisciplineEventImpl.class,
						disciplineEvent.getPrimaryKeyObj());
			}

			if (disciplineEvent != null) {
				session.delete(disciplineEvent);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (disciplineEvent != null) {
			clearCache(disciplineEvent);
		}

		return disciplineEvent;
	}

	@Override
	public DisciplineEvent updateImpl(
		com.qc.qcsms.model.DisciplineEvent disciplineEvent)
		throws SystemException {
		disciplineEvent = toUnwrappedModel(disciplineEvent);

		boolean isNew = disciplineEvent.isNew();

		DisciplineEventModelImpl disciplineEventModelImpl = (DisciplineEventModelImpl)disciplineEvent;

		if (Validator.isNull(disciplineEvent.getUuid())) {
			String uuid = PortalUUIDUtil.generate();

			disciplineEvent.setUuid(uuid);
		}

		Session session = null;

		try {
			session = openSession();

			if (disciplineEvent.isNew()) {
				session.save(disciplineEvent);

				disciplineEvent.setNew(false);
			}
			else {
				session.merge(disciplineEvent);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !DisciplineEventModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((disciplineEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						disciplineEventModelImpl.getOriginalUuid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);

				args = new Object[] { disciplineEventModelImpl.getUuid() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);
			}

			if ((disciplineEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						disciplineEventModelImpl.getOriginalUuid(),
						disciplineEventModelImpl.getOriginalCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
					args);

				args = new Object[] {
						disciplineEventModelImpl.getUuid(),
						disciplineEventModelImpl.getCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
					args);
			}

			if ((disciplineEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						disciplineEventModelImpl.getOriginalGroupId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_GROUPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID,
					args);

				args = new Object[] { disciplineEventModelImpl.getGroupId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_GROUPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID,
					args);
			}

			if ((disciplineEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STUDENTID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						disciplineEventModelImpl.getOriginalStudentId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STUDENTID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STUDENTID,
					args);

				args = new Object[] { disciplineEventModelImpl.getStudentId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_STUDENTID,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_STUDENTID,
					args);
			}

			if ((disciplineEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCIPLINECODE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						disciplineEventModelImpl.getOriginalDisciplineCodeId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DISCIPLINECODE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCIPLINECODE,
					args);

				args = new Object[] {
						disciplineEventModelImpl.getDisciplineCodeId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_DISCIPLINECODE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_DISCIPLINECODE,
					args);
			}

			if ((disciplineEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EVENTDATE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						disciplineEventModelImpl.getOriginalEventDate()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_EVENTDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EVENTDATE,
					args);

				args = new Object[] { disciplineEventModelImpl.getEventDate() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_EVENTDATE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_EVENTDATE,
					args);
			}

			if ((disciplineEventModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PENALTYCODE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						disciplineEventModelImpl.getOriginalPenaltyCodeId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PENALTYCODE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PENALTYCODE,
					args);

				args = new Object[] { disciplineEventModelImpl.getPenaltyCodeId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_PENALTYCODE,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_PENALTYCODE,
					args);
			}
		}

		EntityCacheUtil.putResult(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
			DisciplineEventImpl.class, disciplineEvent.getPrimaryKey(),
			disciplineEvent);

		clearUniqueFindersCache(disciplineEvent);
		cacheUniqueFindersCache(disciplineEvent);

		return disciplineEvent;
	}

	protected DisciplineEvent toUnwrappedModel(DisciplineEvent disciplineEvent) {
		if (disciplineEvent instanceof DisciplineEventImpl) {
			return disciplineEvent;
		}

		DisciplineEventImpl disciplineEventImpl = new DisciplineEventImpl();

		disciplineEventImpl.setNew(disciplineEvent.isNew());
		disciplineEventImpl.setPrimaryKey(disciplineEvent.getPrimaryKey());

		disciplineEventImpl.setUuid(disciplineEvent.getUuid());
		disciplineEventImpl.setDisciplineEventId(disciplineEvent.getDisciplineEventId());
		disciplineEventImpl.setGroupId(disciplineEvent.getGroupId());
		disciplineEventImpl.setCompanyId(disciplineEvent.getCompanyId());
		disciplineEventImpl.setUserId(disciplineEvent.getUserId());
		disciplineEventImpl.setUserName(disciplineEvent.getUserName());
		disciplineEventImpl.setCreateDate(disciplineEvent.getCreateDate());
		disciplineEventImpl.setModifiedDate(disciplineEvent.getModifiedDate());
		disciplineEventImpl.setStudentId(disciplineEvent.getStudentId());
		disciplineEventImpl.setDisciplineCodeId(disciplineEvent.getDisciplineCodeId());
		disciplineEventImpl.setRemarks(disciplineEvent.getRemarks());
		disciplineEventImpl.setEventDate(disciplineEvent.getEventDate());
		disciplineEventImpl.setPenaltyCodeId(disciplineEvent.getPenaltyCodeId());

		return disciplineEventImpl;
	}

	/**
	 * Returns the discipline event with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the discipline event
	 * @return the discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByPrimaryKey(Serializable primaryKey)
		throws NoSuchDisciplineEventException, SystemException {
		DisciplineEvent disciplineEvent = fetchByPrimaryKey(primaryKey);

		if (disciplineEvent == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchDisciplineEventException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return disciplineEvent;
	}

	/**
	 * Returns the discipline event with the primary key or throws a {@link com.qc.qcsms.NoSuchDisciplineEventException} if it could not be found.
	 *
	 * @param disciplineEventId the primary key of the discipline event
	 * @return the discipline event
	 * @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent findByPrimaryKey(long disciplineEventId)
		throws NoSuchDisciplineEventException, SystemException {
		return findByPrimaryKey((Serializable)disciplineEventId);
	}

	/**
	 * Returns the discipline event with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the discipline event
	 * @return the discipline event, or <code>null</code> if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		DisciplineEvent disciplineEvent = (DisciplineEvent)EntityCacheUtil.getResult(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
				DisciplineEventImpl.class, primaryKey);

		if (disciplineEvent == _nullDisciplineEvent) {
			return null;
		}

		if (disciplineEvent == null) {
			Session session = null;

			try {
				session = openSession();

				disciplineEvent = (DisciplineEvent)session.get(DisciplineEventImpl.class,
						primaryKey);

				if (disciplineEvent != null) {
					cacheResult(disciplineEvent);
				}
				else {
					EntityCacheUtil.putResult(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
						DisciplineEventImpl.class, primaryKey,
						_nullDisciplineEvent);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(DisciplineEventModelImpl.ENTITY_CACHE_ENABLED,
					DisciplineEventImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return disciplineEvent;
	}

	/**
	 * Returns the discipline event with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param disciplineEventId the primary key of the discipline event
	 * @return the discipline event, or <code>null</code> if a discipline event with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public DisciplineEvent fetchByPrimaryKey(long disciplineEventId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)disciplineEventId);
	}

	/**
	 * Returns all the discipline events.
	 *
	 * @return the discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the discipline events.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @return the range of discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the discipline events.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of discipline events
	 * @param end the upper bound of the range of discipline events (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<DisciplineEvent> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<DisciplineEvent> list = (List<DisciplineEvent>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_DISCIPLINEEVENT);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_DISCIPLINEEVENT;

				if (pagination) {
					sql = sql.concat(DisciplineEventModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<DisciplineEvent>(list);
				}
				else {
					list = (List<DisciplineEvent>)QueryUtil.list(q,
							getDialect(), start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the discipline events from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (DisciplineEvent disciplineEvent : findAll()) {
			remove(disciplineEvent);
		}
	}

	/**
	 * Returns the number of discipline events.
	 *
	 * @return the number of discipline events
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_DISCIPLINEEVENT);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the discipline event persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.qc.qcsms.model.DisciplineEvent")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<DisciplineEvent>> listenersList = new ArrayList<ModelListener<DisciplineEvent>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<DisciplineEvent>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(DisciplineEventImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_DISCIPLINEEVENT = "SELECT disciplineEvent FROM DisciplineEvent disciplineEvent";
	private static final String _SQL_SELECT_DISCIPLINEEVENT_WHERE = "SELECT disciplineEvent FROM DisciplineEvent disciplineEvent WHERE ";
	private static final String _SQL_COUNT_DISCIPLINEEVENT = "SELECT COUNT(disciplineEvent) FROM DisciplineEvent disciplineEvent";
	private static final String _SQL_COUNT_DISCIPLINEEVENT_WHERE = "SELECT COUNT(disciplineEvent) FROM DisciplineEvent disciplineEvent WHERE ";
	private static final String _FILTER_ENTITY_TABLE_FILTER_PK_COLUMN = "disciplineEvent.disciplineEventId";
	private static final String _FILTER_SQL_SELECT_DISCIPLINEEVENT_WHERE = "SELECT DISTINCT {disciplineEvent.*} FROM qc_DisciplineEvent disciplineEvent WHERE ";
	private static final String _FILTER_SQL_SELECT_DISCIPLINEEVENT_NO_INLINE_DISTINCT_WHERE_1 =
		"SELECT {qc_DisciplineEvent.*} FROM (SELECT DISTINCT disciplineEvent.disciplineEventId FROM qc_DisciplineEvent disciplineEvent WHERE ";
	private static final String _FILTER_SQL_SELECT_DISCIPLINEEVENT_NO_INLINE_DISTINCT_WHERE_2 =
		") TEMP_TABLE INNER JOIN qc_DisciplineEvent ON TEMP_TABLE.disciplineEventId = qc_DisciplineEvent.disciplineEventId";
	private static final String _FILTER_SQL_COUNT_DISCIPLINEEVENT_WHERE = "SELECT COUNT(DISTINCT disciplineEvent.disciplineEventId) AS COUNT_VALUE FROM qc_DisciplineEvent disciplineEvent WHERE ";
	private static final String _FILTER_ENTITY_ALIAS = "disciplineEvent";
	private static final String _FILTER_ENTITY_TABLE = "qc_DisciplineEvent";
	private static final String _ORDER_BY_ENTITY_ALIAS = "disciplineEvent.";
	private static final String _ORDER_BY_ENTITY_TABLE = "qc_DisciplineEvent.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No DisciplineEvent exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No DisciplineEvent exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(DisciplineEventPersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"uuid"
			});
	private static DisciplineEvent _nullDisciplineEvent = new DisciplineEventImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<DisciplineEvent> toCacheModel() {
				return _nullDisciplineEventCacheModel;
			}
		};

	private static CacheModel<DisciplineEvent> _nullDisciplineEventCacheModel = new CacheModel<DisciplineEvent>() {
			@Override
			public DisciplineEvent toEntityModel() {
				return _nullDisciplineEvent;
			}
		};
}