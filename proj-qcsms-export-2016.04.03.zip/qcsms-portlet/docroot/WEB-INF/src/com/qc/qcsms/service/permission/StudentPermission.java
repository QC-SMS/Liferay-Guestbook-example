package com.qc.qcsms.service.permission;

import com.qc.qcsms.model.Student;
import com.qc.qcsms.service.StudentLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.security.permission.PermissionChecker;

public class StudentPermission {
    public static void check(PermissionChecker permissionChecker,
            long studentId, String actionId) throws PortalException,
            SystemException {

        if (!contains(permissionChecker, studentId, actionId)) {
            throw new PrincipalException();
        }
    }

    public static boolean contains(PermissionChecker permissionChecker,
            long studentId, String actionId) throws PortalException,
            SystemException {
        Student student = StudentLocalServiceUtil.getStudent(studentId);
        return permissionChecker
                .hasPermission(student.getGroupId(),
                        Student.class.getName(), student.getStudentId(),
                        actionId);
    }
}
