package com.qc.qcsms.service.permission;

import com.qc.qcsms.model.AbsenceEvent;
import com.qc.qcsms.service.AbsenceEventLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.security.permission.PermissionChecker;

public class AbsenceEventPermission {
    public static void check(PermissionChecker permissionChecker,
            long absenceEventId, String actionId) throws PortalException,
            SystemException {

        if (!contains(permissionChecker, absenceEventId, actionId)) {
            throw new PrincipalException();
        }
    }

    public static boolean contains(PermissionChecker permissionChecker,
            long absenceEventId, String actionId) throws PortalException,
            SystemException {
        AbsenceEvent absenceEvent = AbsenceEventLocalServiceUtil.getAbsenceEvent(absenceEventId);
        return permissionChecker
                .hasPermission(absenceEvent.getGroupId(),
                        AbsenceEvent.class.getName(), absenceEvent.getAbsenceEventId(),
                        actionId);
    }
}
