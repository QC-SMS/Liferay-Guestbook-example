package com.qc.qcsms.service.permission;

import com.qc.qcsms.model.AbsenceCode;
import com.qc.qcsms.service.AbsenceCodeLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.security.permission.PermissionChecker;

public class AbsenceCodePermission {
    public static void check(PermissionChecker permissionChecker,
            long absenceCodeId, String actionId) throws PortalException,
            SystemException {

        if (!contains(permissionChecker, absenceCodeId, actionId)) {
            throw new PrincipalException();
        }
    }

    public static boolean contains(PermissionChecker permissionChecker,
            long absenceCodeId, String actionId) throws PortalException,
            SystemException {
        AbsenceCode absenceCode = AbsenceCodeLocalServiceUtil.getAbsenceCode(absenceCodeId);
        return permissionChecker
                .hasPermission(absenceCode.getGroupId(),
                        AbsenceCode.class.getName(), absenceCode.getAbsenceCodeId(),
                        actionId);
    }
}
