/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.impl;

import java.util.Date;
import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.qc.qcsms.AbsenceCodeException;
import com.qc.qcsms.AbsenceCodeLengthException;
import com.qc.qcsms.AbsenceCodeUniqueException;
import com.qc.qcsms.AbsenceDescriptionException;
import com.qc.qcsms.AbsenceDescriptionLengthException;
import com.qc.qcsms.NoSuchAbsenceCodeException;
import com.qc.qcsms.model.AbsenceCode;
import com.qc.qcsms.service.AbsenceCodeLocalServiceUtil;
import com.qc.qcsms.service.base.AbsenceCodeLocalServiceBaseImpl;

/**
 * The implementation of the absence code local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.qc.qcsms.service.AbsenceCodeLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author teddyku
 * @see com.qc.qcsms.service.base.AbsenceCodeLocalServiceBaseImpl
 * @see com.qc.qcsms.service.AbsenceCodeLocalServiceUtil
 */
public class AbsenceCodeLocalServiceImpl extends AbsenceCodeLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.qc.qcsms.service.AbsenceCodeLocalServiceUtil} to access the absence code local service.
	 */
	public List<AbsenceCode> getAbsenceCodes(long groupId) throws SystemException {
	    return absenceCodePersistence.findByGroupId(groupId);
	}

	public List<AbsenceCode> getAbsenceCodes(long groupId, int start, int end)
	   throws SystemException {
	    return absenceCodePersistence.findByGroupId(groupId, start, end);
	}
	
	protected void validate(long absenceCodeId, String code, String description) throws PortalException, SystemException {
	    if (Validator.isNull(code)) {
	    	throw new AbsenceCodeException();
	    }
	    if (code.length() > 3) {
	    	throw new AbsenceCodeLengthException();
	    }
	    if (Validator.isNull(description)) {
	    	throw new AbsenceDescriptionException();
	    }
	    if (description.length() > 255) {
	    	throw new AbsenceDescriptionLengthException();
	    }
	    try {
	    	AbsenceCode absenceCode = absenceCodePersistence.findByAssignedCode(code);
	    	if (absenceCode.getAbsenceCodeId() != absenceCodeId) throw new AbsenceCodeUniqueException();
	    }
	    catch(NoSuchAbsenceCodeException ex) {
	    	// Expected no record found
	    }
	}
	
	public AbsenceCode addAbsenceCode(long userId, String code, String description, 
		    ServiceContext serviceContext) throws SystemException, PortalException {
		long groupId = serviceContext.getScopeGroupId();
		User user = userPersistence.findByPrimaryKey(userId);
		Date now = new Date();
		validate(0, code, description);

		long absenceCodeId = counterLocalService.increment();
		AbsenceCode absenceCode = absenceCodePersistence.create(absenceCodeId);

		absenceCode.setUuid(serviceContext.getUuid());
		absenceCode.setUserId(userId);
		absenceCode.setGroupId(groupId);
		absenceCode.setCompanyId(user.getCompanyId());
		absenceCode.setUserName(user.getFullName());
		absenceCode.setCreateDate(serviceContext.getCreateDate(now));
		absenceCode.setModifiedDate(serviceContext.getModifiedDate(now));
		absenceCode.setAssignedCode(code);
		absenceCode.setDescription(description);
		absenceCode.setExpandoBridgeAttributes(serviceContext);
		absenceCodePersistence.update(absenceCode);

		resourceLocalService.addResources(user.getCompanyId(), groupId, userId,
			       AbsenceCode.class.getName(), absenceCodeId, false, true, true);
		return absenceCode;
	}

	public AbsenceCode updateAbsenceCode(long userId, long absenceCodeId,
		String code, String description, ServiceContext serviceContext) throws PortalException, SystemException {
		Date now = new Date();
		validate(absenceCodeId, code, description);
		AbsenceCode absenceCode = getAbsenceCode(absenceCodeId);
		
		User user = UserLocalServiceUtil.getUser(userId);
		absenceCode.setUserId(userId);
		absenceCode.setUserName(user.getFullName());
		absenceCode.setModifiedDate(serviceContext.getModifiedDate(now));
		absenceCode.setAssignedCode(code);
		absenceCode.setDescription(description);
		absenceCode.setExpandoBridgeAttributes(serviceContext);
		absenceCodePersistence.update(absenceCode);
		resourceLocalService.updateResources(serviceContext.getCompanyId(),
		                serviceContext.getScopeGroupId(), AbsenceCode.class.getName(), absenceCodeId,
		                serviceContext.getGroupPermissions(),
		                serviceContext.getGuestPermissions());
		return absenceCode;
	}
	
	public AbsenceCode deleteAbsenceCode(long absenceCodeId,
            ServiceContext serviceContext) throws PortalException, SystemException {
	    AbsenceCode absenceCode = getAbsenceCode(absenceCodeId);
	    resourceLocalService.deleteResource(serviceContext.getCompanyId(),
	                    AbsenceCode.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
	                    absenceCodeId);
	    absenceCode = deleteAbsenceCode(absenceCode);
	    return absenceCode;
	}
	
	public int getAbsenceCodeCount(long groupId) throws SystemException {
        return absenceCodePersistence.countByGroupId(groupId);
	}

	public List getSearchAbsenceCodes(String code, String description, boolean andSearch, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		DynamicQuery dynamicQuery = buildAbsenceCodeDynamicQuery(code, description, andSearch);
		return AbsenceCodeLocalServiceUtil.dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	public int getSearchAbsenceCodesCount(String code, String description, boolean andSearch) 
		throws SystemException {
		DynamicQuery dynamicQuery = buildAbsenceCodeDynamicQuery(code, description, andSearch);
		return (int)AbsenceCodeLocalServiceUtil.dynamicQueryCount(dynamicQuery);
	}

	protected DynamicQuery buildAbsenceCodeDynamicQuery(String code, String description, boolean andSearch) {
		Junction junction = null;
		if(andSearch) {
			junction = RestrictionsFactoryUtil.conjunction();
		} else {
			junction = RestrictionsFactoryUtil.disjunction();
		}
		if(Validator.isNotNull(code)) {
			Property property = PropertyFactoryUtil.forName("assignedCode");
			String value = (new StringBuilder("%")).append(code).append("%").toString();
			junction.add(property.like(value));
		}
		if(Validator.isNotNull(description)) {
			Property property = PropertyFactoryUtil.forName("description");
			String value = (new StringBuilder("%")).append(description).append("%").toString();
			junction.add(property.like(value));
		}
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(AbsenceCode.class, getClassLoader());
		return dynamicQuery.add(junction);
	}
}