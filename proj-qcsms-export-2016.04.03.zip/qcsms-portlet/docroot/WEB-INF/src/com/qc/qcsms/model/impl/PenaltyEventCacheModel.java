/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.qc.qcsms.model.PenaltyEvent;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing PenaltyEvent in entity cache.
 *
 * @author teddyku
 * @see PenaltyEvent
 * @generated
 */
public class PenaltyEventCacheModel implements CacheModel<PenaltyEvent>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(37);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", penaltyEventId=");
		sb.append(penaltyEventId);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", userName=");
		sb.append(userName);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", studentId=");
		sb.append(studentId);
		sb.append(", disciplineEventId=");
		sb.append(disciplineEventId);
		sb.append(", penaltyCodeId=");
		sb.append(penaltyCodeId);
		sb.append(", eventDescription=");
		sb.append(eventDescription);
		sb.append(", remarks=");
		sb.append(remarks);
		sb.append(", studentLearningLogInd=");
		sb.append(studentLearningLogInd);
		sb.append(", webSAMSInd=");
		sb.append(webSAMSInd);
		sb.append(", brightFutureCompletedInd=");
		sb.append(brightFutureCompletedInd);
		sb.append(", copyReturnedInd=");
		sb.append(copyReturnedInd);
		sb.append(", eventDate=");
		sb.append(eventDate);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public PenaltyEvent toEntityModel() {
		PenaltyEventImpl penaltyEventImpl = new PenaltyEventImpl();

		if (uuid == null) {
			penaltyEventImpl.setUuid(StringPool.BLANK);
		}
		else {
			penaltyEventImpl.setUuid(uuid);
		}

		penaltyEventImpl.setPenaltyEventId(penaltyEventId);
		penaltyEventImpl.setGroupId(groupId);
		penaltyEventImpl.setCompanyId(companyId);
		penaltyEventImpl.setUserId(userId);

		if (userName == null) {
			penaltyEventImpl.setUserName(StringPool.BLANK);
		}
		else {
			penaltyEventImpl.setUserName(userName);
		}

		if (createDate == Long.MIN_VALUE) {
			penaltyEventImpl.setCreateDate(null);
		}
		else {
			penaltyEventImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			penaltyEventImpl.setModifiedDate(null);
		}
		else {
			penaltyEventImpl.setModifiedDate(new Date(modifiedDate));
		}

		penaltyEventImpl.setStudentId(studentId);
		penaltyEventImpl.setDisciplineEventId(disciplineEventId);
		penaltyEventImpl.setPenaltyCodeId(penaltyCodeId);

		if (eventDescription == null) {
			penaltyEventImpl.setEventDescription(StringPool.BLANK);
		}
		else {
			penaltyEventImpl.setEventDescription(eventDescription);
		}

		if (remarks == null) {
			penaltyEventImpl.setRemarks(StringPool.BLANK);
		}
		else {
			penaltyEventImpl.setRemarks(remarks);
		}

		if (studentLearningLogInd == null) {
			penaltyEventImpl.setStudentLearningLogInd(StringPool.BLANK);
		}
		else {
			penaltyEventImpl.setStudentLearningLogInd(studentLearningLogInd);
		}

		if (webSAMSInd == null) {
			penaltyEventImpl.setWebSAMSInd(StringPool.BLANK);
		}
		else {
			penaltyEventImpl.setWebSAMSInd(webSAMSInd);
		}

		if (brightFutureCompletedInd == null) {
			penaltyEventImpl.setBrightFutureCompletedInd(StringPool.BLANK);
		}
		else {
			penaltyEventImpl.setBrightFutureCompletedInd(brightFutureCompletedInd);
		}

		if (copyReturnedInd == null) {
			penaltyEventImpl.setCopyReturnedInd(StringPool.BLANK);
		}
		else {
			penaltyEventImpl.setCopyReturnedInd(copyReturnedInd);
		}

		if (eventDate == Long.MIN_VALUE) {
			penaltyEventImpl.setEventDate(null);
		}
		else {
			penaltyEventImpl.setEventDate(new Date(eventDate));
		}

		penaltyEventImpl.resetOriginalValues();

		return penaltyEventImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();
		penaltyEventId = objectInput.readLong();
		groupId = objectInput.readLong();
		companyId = objectInput.readLong();
		userId = objectInput.readLong();
		userName = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
		studentId = objectInput.readLong();
		disciplineEventId = objectInput.readLong();
		penaltyCodeId = objectInput.readLong();
		eventDescription = objectInput.readUTF();
		remarks = objectInput.readUTF();
		studentLearningLogInd = objectInput.readUTF();
		webSAMSInd = objectInput.readUTF();
		brightFutureCompletedInd = objectInput.readUTF();
		copyReturnedInd = objectInput.readUTF();
		eventDate = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(penaltyEventId);
		objectOutput.writeLong(groupId);
		objectOutput.writeLong(companyId);
		objectOutput.writeLong(userId);

		if (userName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userName);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);
		objectOutput.writeLong(studentId);
		objectOutput.writeLong(disciplineEventId);
		objectOutput.writeLong(penaltyCodeId);

		if (eventDescription == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(eventDescription);
		}

		if (remarks == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(remarks);
		}

		if (studentLearningLogInd == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(studentLearningLogInd);
		}

		if (webSAMSInd == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(webSAMSInd);
		}

		if (brightFutureCompletedInd == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(brightFutureCompletedInd);
		}

		if (copyReturnedInd == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(copyReturnedInd);
		}

		objectOutput.writeLong(eventDate);
	}

	public String uuid;
	public long penaltyEventId;
	public long groupId;
	public long companyId;
	public long userId;
	public String userName;
	public long createDate;
	public long modifiedDate;
	public long studentId;
	public long disciplineEventId;
	public long penaltyCodeId;
	public String eventDescription;
	public String remarks;
	public String studentLearningLogInd;
	public String webSAMSInd;
	public String brightFutureCompletedInd;
	public String copyReturnedInd;
	public long eventDate;
}