/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.qc.qcsms.DisciplineEventDateException;
import com.qc.qcsms.DisciplineEventRemarksLengthException;
import com.qc.qcsms.DisciplineEventTeacherException;
import com.qc.qcsms.DisciplineEventTeacherLengthException;
import com.qc.qcsms.model.DisciplineCode;
import com.qc.qcsms.model.DisciplineEvent;
import com.qc.qcsms.model.PenaltyCode;
import com.qc.qcsms.model.Student;
import com.qc.qcsms.model.StudentClass;
import com.qc.qcsms.service.DisciplineCodeLocalServiceUtil;
import com.qc.qcsms.service.DisciplineEventLocalServiceUtil;
import com.qc.qcsms.service.PenaltyCodeLocalServiceUtil;
import com.qc.qcsms.service.StudentClassLocalServiceUtil;
import com.qc.qcsms.service.StudentLocalServiceUtil;
import com.qc.qcsms.service.base.DisciplineEventLocalServiceBaseImpl;

/**
 * The implementation of the discipline event local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.qc.qcsms.service.DisciplineEventLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author teddyku
 * @see com.qc.qcsms.service.base.DisciplineEventLocalServiceBaseImpl
 * @see com.qc.qcsms.service.DisciplineEventLocalServiceUtil
 */
public class DisciplineEventLocalServiceImpl
	extends DisciplineEventLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.qc.qcsms.service.DisciplineEventLocalServiceUtil} to access the discipline event local service.
	 */
	public List<DisciplineEvent> getDisciplineEvents(long groupId) throws SystemException {
	    return disciplineEventPersistence.findByGroupId(groupId);
	}

	public List<DisciplineEvent> getDisciplineEvents(long groupId, int start, int end)
	   throws SystemException {
	    return disciplineEventPersistence.findByGroupId(groupId, start, end);
	}
	
	protected void validate (long studentId, long disciplineCodeId, Date eventDate, String remarks, long penaltyCodeId) throws PortalException, SystemException {
		Student student = StudentLocalServiceUtil.getStudent(studentId);
		DisciplineCode displineCode = DisciplineCodeLocalServiceUtil.getDisciplineCode(disciplineCodeId);
		PenaltyCode penaltyCode = PenaltyCodeLocalServiceUtil.getPenaltyCode(penaltyCodeId);
		if (Validator.isNull(eventDate)) {
 	    	throw new DisciplineEventDateException();
 	    }
	    if (Validator.isNotNull(remarks) && remarks.length() > 255) {
	    	throw new DisciplineEventRemarksLengthException();
	    }
	}
	
	public DisciplineEvent addDisciplineEvent(long userId, long studentId, long disciplineCodeId, Date eventDate, String remarks, long penaltyCodeId,
		    ServiceContext serviceContext) throws SystemException, PortalException {
		long groupId = serviceContext.getScopeGroupId();
		User user = userPersistence.findByPrimaryKey(userId);
		Date now = new Date();
		validate(studentId, disciplineCodeId, eventDate, remarks, penaltyCodeId);

		long disciplineEventId = counterLocalService.increment();
		DisciplineEvent disciplineEvent = disciplineEventPersistence.create(disciplineEventId);

		disciplineEvent.setUuid(serviceContext.getUuid());
		disciplineEvent.setUserId(userId);
		disciplineEvent.setGroupId(groupId);
		disciplineEvent.setCompanyId(user.getCompanyId());
		disciplineEvent.setUserName(user.getFullName());
		disciplineEvent.setCreateDate(serviceContext.getCreateDate(now));
		disciplineEvent.setModifiedDate(serviceContext.getModifiedDate(now));
		disciplineEvent.setStudentId(studentId);
		disciplineEvent.setDisciplineCodeId(disciplineCodeId);
		disciplineEvent.setEventDate(eventDate == null? eventDate : truncateTime(eventDate));
		disciplineEvent.setRemarks(remarks);
		disciplineEvent.setPenaltyCodeId(penaltyCodeId);
		disciplineEvent.setExpandoBridgeAttributes(serviceContext);
		disciplineEventPersistence.update(disciplineEvent);

		resourceLocalService.addResources(user.getCompanyId(), groupId, userId,
			       DisciplineEvent.class.getName(), disciplineEventId, false, true, true);
		return disciplineEvent;
	}

	public DisciplineEvent updateDisciplineEvent(long userId, long disciplineEventId, long studentId, long disciplineCodeId, Date eventDate, String remarks, long penaltyCodeId, 
			ServiceContext serviceContext) throws PortalException, SystemException {
		Date now = new Date();
		validate(studentId, disciplineCodeId, eventDate, remarks, penaltyCodeId);
		DisciplineEvent disciplineEvent = getDisciplineEvent(disciplineEventId);
		
		User user = UserLocalServiceUtil.getUser(userId);
		disciplineEvent.setUserId(userId);
		disciplineEvent.setUserName(user.getFullName());
		disciplineEvent.setModifiedDate(serviceContext.getModifiedDate(now));
		disciplineEvent.setStudentId(studentId);
		disciplineEvent.setDisciplineCodeId(disciplineCodeId);
		disciplineEvent.setEventDate(eventDate == null? eventDate : truncateTime(eventDate));
		disciplineEvent.setRemarks(remarks);
		disciplineEvent.setPenaltyCodeId(penaltyCodeId);
		disciplineEvent.setExpandoBridgeAttributes(serviceContext);
		disciplineEventPersistence.update(disciplineEvent);
		resourceLocalService.updateResources(serviceContext.getCompanyId(),
		                serviceContext.getScopeGroupId(), DisciplineEvent.class.getName(), disciplineEventId,
		                serviceContext.getGroupPermissions(),
		                serviceContext.getGuestPermissions());
		return disciplineEvent;
	}
	
	public DisciplineEvent deleteDisciplineEvent(long disciplineEventId,
            ServiceContext serviceContext) throws PortalException, SystemException {
		DisciplineEvent disciplineEvent = getDisciplineEvent(disciplineEventId);
	    resourceLocalService.deleteResource(serviceContext.getCompanyId(),
	                    DisciplineEvent.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
	                    disciplineEventId);
	    disciplineEvent = deleteDisciplineEvent(disciplineEvent);
	    return disciplineEvent;
	}
	
	public int getDisciplineEventCount(long groupId) throws SystemException {
        return disciplineEventPersistence.countByGroupId(groupId);
	}

	public List getSearchDisciplineEvents(long studentId, long disciplineCodeId, Date fromEventDate, Date toEventDate, String remarks, long penaltyCodeId, long userId, boolean andSearch, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		DynamicQuery dynamicQuery = buildDisciplineEventDynamicQuery(studentId, disciplineCodeId, fromEventDate == null? fromEventDate : truncateTime(fromEventDate), 
				toEventDate == null? toEventDate : truncateTime(toEventDate), remarks, penaltyCodeId, userId, andSearch);
		return DisciplineEventLocalServiceUtil.dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	public int getSearchDisciplineEventCount(long studentId, long disciplineCodeId, Date fromEventDate, Date toEventDate, String remarks, long penaltyCodeId, long userId, boolean andSearch) 
		throws SystemException {
		DynamicQuery dynamicQuery = buildDisciplineEventDynamicQuery(studentId, disciplineCodeId, fromEventDate == null? fromEventDate : truncateTime(fromEventDate), 
				toEventDate == null? toEventDate : truncateTime(toEventDate), remarks, penaltyCodeId, userId, andSearch);
		return (int)DisciplineEventLocalServiceUtil.dynamicQueryCount(dynamicQuery);
	}

	protected DynamicQuery buildDisciplineEventDynamicQuery(long studentId, long disciplineCodeId, Date fromEventDate, Date toEventDate, String remarks, long penaltyCodeId, long userId, boolean andSearch) {
		Junction junction = null;
		if(andSearch) {
			junction = RestrictionsFactoryUtil.conjunction();
		} else {
			junction = RestrictionsFactoryUtil.disjunction();
		}
		if(studentId > 0) {
			Property property = PropertyFactoryUtil.forName("studentId");
			junction.add(property.eq(Long.valueOf(studentId)));
		}
		if(disciplineCodeId > 0) {
			Property property = PropertyFactoryUtil.forName("disciplineCodeId");
			junction.add(property.eq(Long.valueOf(disciplineCodeId)));
		}
		if (Validator.isNotNull(fromEventDate)) {
			Property property = PropertyFactoryUtil.forName("eventDate");
			junction.add(property.ge(fromEventDate));
		}
		if (Validator.isNotNull(toEventDate)) {
			Property property = PropertyFactoryUtil.forName("eventDate");
			junction.add(property.le(toEventDate));
		}
		if(Validator.isNotNull(remarks)) {
			Property property = PropertyFactoryUtil.forName("remarks");
			String value = (new StringBuilder("%")).append(remarks).append("%").toString();
			junction.add(property.like(value));
		}
		if(penaltyCodeId > 0) {
			Property property = PropertyFactoryUtil.forName("penaltyCodeId");
			junction.add(property.eq(Long.valueOf(penaltyCodeId)));
		}
		if(userId > 0) {
			Property property = PropertyFactoryUtil.forName("userId");
			junction.add(property.eq(Long.valueOf(userId)));
		}
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(DisciplineEvent.class, getClassLoader());
		return dynamicQuery.add(junction);
	}
	
	private Date truncateTime(Date tDate) {
		Calendar tCal = Calendar.getInstance();
		tCal.setTime(tDate);
		int tYear = tCal.get(Calendar.YEAR);
		int tMonth = tCal.get(Calendar.MONTH);
		int tDay = tCal.get(Calendar.DAY_OF_MONTH);
		tCal.set(tYear, tMonth, tDay, 0, 0);
		return tCal.getTime();
	}
	
	public String getSelectOptionDescription(DisciplineEvent disciplineEvent) throws SystemException {
		String tString = "";
		if (disciplineEvent != null) {
			Student student = StudentLocalServiceUtil.fetchStudent(disciplineEvent.getStudentId());
			StudentClass sClass = StudentClassLocalServiceUtil.fetchStudentClass(student.getClassId());
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			tString = sdf.format(disciplineEvent.getEventDate())+"-"+sClass.getClassCode()+","+student.getClassNo()+","+student.getStudentName()+"/"+disciplineEvent.getRemarks();
		}
		return tString;
	}
}