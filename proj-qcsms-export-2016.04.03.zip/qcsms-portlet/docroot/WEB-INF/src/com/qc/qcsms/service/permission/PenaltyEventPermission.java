package com.qc.qcsms.service.permission;

import com.qc.qcsms.model.PenaltyEvent;
import com.qc.qcsms.service.PenaltyEventLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.security.permission.PermissionChecker;

public class PenaltyEventPermission {
    public static void check(PermissionChecker permissionChecker,
            long penaltyEventId, String actionId) throws PortalException,
            SystemException {

        if (!contains(permissionChecker, penaltyEventId, actionId)) {
            throw new PrincipalException();
        }
    }

    public static boolean contains(PermissionChecker permissionChecker,
            long penaltyEventId, String actionId) throws PortalException,
            SystemException {
        PenaltyEvent penaltyEvent = PenaltyEventLocalServiceUtil.getPenaltyEvent(penaltyEventId);
        return permissionChecker
                .hasPermission(penaltyEvent.getGroupId(),
                        PenaltyEvent.class.getName(), penaltyEvent.getPenaltyEventId(),
                        actionId);
    }
}
