package com.qc.qcsms.service.permission;

import com.qc.qcsms.model.DisciplineEvent;
import com.qc.qcsms.service.DisciplineEventLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.security.permission.PermissionChecker;

public class DisciplineEventPermission {
    public static void check(PermissionChecker permissionChecker,
            long disciplineEventId, String actionId) throws PortalException,
            SystemException {

        if (!contains(permissionChecker, disciplineEventId, actionId)) {
            throw new PrincipalException();
        }
    }

    public static boolean contains(PermissionChecker permissionChecker,
            long disciplineEventId, String actionId) throws PortalException,
            SystemException {
        DisciplineEvent disciplineEvent = DisciplineEventLocalServiceUtil.getDisciplineEvent(disciplineEventId);
        return permissionChecker
                .hasPermission(disciplineEvent.getGroupId(),
                        DisciplineEvent.class.getName(), disciplineEvent.getDisciplineEventId(),
                        actionId);
    }
}
