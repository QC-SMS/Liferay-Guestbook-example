/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.qc.qcsms.model.DisciplineEvent;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing DisciplineEvent in entity cache.
 *
 * @author teddyku
 * @see DisciplineEvent
 * @generated
 */
public class DisciplineEventCacheModel implements CacheModel<DisciplineEvent>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(27);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", disciplineEventId=");
		sb.append(disciplineEventId);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", userName=");
		sb.append(userName);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", studentId=");
		sb.append(studentId);
		sb.append(", disciplineCodeId=");
		sb.append(disciplineCodeId);
		sb.append(", remarks=");
		sb.append(remarks);
		sb.append(", eventDate=");
		sb.append(eventDate);
		sb.append(", penaltyCodeId=");
		sb.append(penaltyCodeId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public DisciplineEvent toEntityModel() {
		DisciplineEventImpl disciplineEventImpl = new DisciplineEventImpl();

		if (uuid == null) {
			disciplineEventImpl.setUuid(StringPool.BLANK);
		}
		else {
			disciplineEventImpl.setUuid(uuid);
		}

		disciplineEventImpl.setDisciplineEventId(disciplineEventId);
		disciplineEventImpl.setGroupId(groupId);
		disciplineEventImpl.setCompanyId(companyId);
		disciplineEventImpl.setUserId(userId);

		if (userName == null) {
			disciplineEventImpl.setUserName(StringPool.BLANK);
		}
		else {
			disciplineEventImpl.setUserName(userName);
		}

		if (createDate == Long.MIN_VALUE) {
			disciplineEventImpl.setCreateDate(null);
		}
		else {
			disciplineEventImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			disciplineEventImpl.setModifiedDate(null);
		}
		else {
			disciplineEventImpl.setModifiedDate(new Date(modifiedDate));
		}

		disciplineEventImpl.setStudentId(studentId);
		disciplineEventImpl.setDisciplineCodeId(disciplineCodeId);

		if (remarks == null) {
			disciplineEventImpl.setRemarks(StringPool.BLANK);
		}
		else {
			disciplineEventImpl.setRemarks(remarks);
		}

		if (eventDate == Long.MIN_VALUE) {
			disciplineEventImpl.setEventDate(null);
		}
		else {
			disciplineEventImpl.setEventDate(new Date(eventDate));
		}

		disciplineEventImpl.setPenaltyCodeId(penaltyCodeId);

		disciplineEventImpl.resetOriginalValues();

		return disciplineEventImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();
		disciplineEventId = objectInput.readLong();
		groupId = objectInput.readLong();
		companyId = objectInput.readLong();
		userId = objectInput.readLong();
		userName = objectInput.readUTF();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
		studentId = objectInput.readLong();
		disciplineCodeId = objectInput.readLong();
		remarks = objectInput.readUTF();
		eventDate = objectInput.readLong();
		penaltyCodeId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(disciplineEventId);
		objectOutput.writeLong(groupId);
		objectOutput.writeLong(companyId);
		objectOutput.writeLong(userId);

		if (userName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userName);
		}

		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);
		objectOutput.writeLong(studentId);
		objectOutput.writeLong(disciplineCodeId);

		if (remarks == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(remarks);
		}

		objectOutput.writeLong(eventDate);
		objectOutput.writeLong(penaltyCodeId);
	}

	public String uuid;
	public long disciplineEventId;
	public long groupId;
	public long companyId;
	public long userId;
	public String userName;
	public long createDate;
	public long modifiedDate;
	public long studentId;
	public long disciplineCodeId;
	public String remarks;
	public long eventDate;
	public long penaltyCodeId;
}