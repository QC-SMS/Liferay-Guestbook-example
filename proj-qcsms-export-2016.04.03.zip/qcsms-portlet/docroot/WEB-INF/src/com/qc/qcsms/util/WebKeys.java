package com.qc.qcsms.util;

public class WebKeys implements com.liferay.portal.kernel.util.WebKeys {
	public static final String STUDENTCLASS = "STUDENTCLASS";
	public static final String STUDENT = "STUDENT";
}
