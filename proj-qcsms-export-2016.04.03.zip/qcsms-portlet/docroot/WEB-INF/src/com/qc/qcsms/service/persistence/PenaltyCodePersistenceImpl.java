/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.security.permission.InlineSQLHelperUtil;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.qc.qcsms.NoSuchPenaltyCodeException;
import com.qc.qcsms.model.PenaltyCode;
import com.qc.qcsms.model.impl.PenaltyCodeImpl;
import com.qc.qcsms.model.impl.PenaltyCodeModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the penalty code service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see PenaltyCodePersistence
 * @see PenaltyCodeUtil
 * @generated
 */
public class PenaltyCodePersistenceImpl extends BasePersistenceImpl<PenaltyCode>
	implements PenaltyCodePersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link PenaltyCodeUtil} to access the penalty code persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = PenaltyCodeImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, PenaltyCodeImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, PenaltyCodeImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, PenaltyCodeImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, PenaltyCodeImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
			new String[] { String.class.getName() },
			PenaltyCodeModelImpl.UUID_COLUMN_BITMASK |
			PenaltyCodeModelImpl.ASSIGNEDCODE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
			new String[] { String.class.getName() });

	/**
	 * Returns all the penalty codes where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findByUuid(String uuid) throws SystemException {
		return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty codes where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of penalty codes
	 * @param end the upper bound of the range of penalty codes (not inclusive)
	 * @return the range of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findByUuid(String uuid, int start, int end)
		throws SystemException {
		return findByUuid(uuid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty codes where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of penalty codes
	 * @param end the upper bound of the range of penalty codes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findByUuid(String uuid, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid, start, end, orderByComparator };
		}

		List<PenaltyCode> list = (List<PenaltyCode>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PenaltyCode penaltyCode : list) {
				if (!Validator.equals(uuid, penaltyCode.getUuid())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PENALTYCODE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PenaltyCodeModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				if (!pagination) {
					list = (List<PenaltyCode>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyCode>(list);
				}
				else {
					list = (List<PenaltyCode>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first penalty code in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode findByUuid_First(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = fetchByUuid_First(uuid, orderByComparator);

		if (penaltyCode != null) {
			return penaltyCode;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyCodeException(msg.toString());
	}

	/**
	 * Returns the first penalty code in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty code, or <code>null</code> if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByUuid_First(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		List<PenaltyCode> list = findByUuid(uuid, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last penalty code in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode findByUuid_Last(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = fetchByUuid_Last(uuid, orderByComparator);

		if (penaltyCode != null) {
			return penaltyCode;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyCodeException(msg.toString());
	}

	/**
	 * Returns the last penalty code in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty code, or <code>null</code> if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByUuid_Last(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid(uuid);

		if (count == 0) {
			return null;
		}

		List<PenaltyCode> list = findByUuid(uuid, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the penalty codes before and after the current penalty code in the ordered set where uuid = &#63;.
	 *
	 * @param penaltyCodeId the primary key of the current penalty code
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a penalty code with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode[] findByUuid_PrevAndNext(long penaltyCodeId,
		String uuid, OrderByComparator orderByComparator)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = findByPrimaryKey(penaltyCodeId);

		Session session = null;

		try {
			session = openSession();

			PenaltyCode[] array = new PenaltyCodeImpl[3];

			array[0] = getByUuid_PrevAndNext(session, penaltyCode, uuid,
					orderByComparator, true);

			array[1] = penaltyCode;

			array[2] = getByUuid_PrevAndNext(session, penaltyCode, uuid,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyCode getByUuid_PrevAndNext(Session session,
		PenaltyCode penaltyCode, String uuid,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PENALTYCODE_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_UUID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PenaltyCodeModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyCode);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyCode> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the penalty codes where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid(String uuid) throws SystemException {
		for (PenaltyCode penaltyCode : findByUuid(uuid, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(penaltyCode);
		}
	}

	/**
	 * Returns the number of penalty codes where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid(String uuid) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

		Object[] finderArgs = new Object[] { uuid };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PENALTYCODE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_UUID_1 = "penaltyCode.uuid IS NULL";
	private static final String _FINDER_COLUMN_UUID_UUID_2 = "penaltyCode.uuid = ?";
	private static final String _FINDER_COLUMN_UUID_UUID_3 = "(penaltyCode.uuid IS NULL OR penaltyCode.uuid = '')";
	public static final FinderPath FINDER_PATH_FETCH_BY_UUID_G = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, PenaltyCodeImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByUUID_G",
			new String[] { String.class.getName(), Long.class.getName() },
			PenaltyCodeModelImpl.UUID_COLUMN_BITMASK |
			PenaltyCodeModelImpl.GROUPID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID_G = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUUID_G",
			new String[] { String.class.getName(), Long.class.getName() });

	/**
	 * Returns the penalty code where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchPenaltyCodeException} if it could not be found.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode findByUUID_G(String uuid, long groupId)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = fetchByUUID_G(uuid, groupId);

		if (penaltyCode == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("uuid=");
			msg.append(uuid);

			msg.append(", groupId=");
			msg.append(groupId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchPenaltyCodeException(msg.toString());
		}

		return penaltyCode;
	}

	/**
	 * Returns the penalty code where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching penalty code, or <code>null</code> if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByUUID_G(String uuid, long groupId)
		throws SystemException {
		return fetchByUUID_G(uuid, groupId, true);
	}

	/**
	 * Returns the penalty code where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching penalty code, or <code>null</code> if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByUUID_G(String uuid, long groupId,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { uuid, groupId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_UUID_G,
					finderArgs, this);
		}

		if (result instanceof PenaltyCode) {
			PenaltyCode penaltyCode = (PenaltyCode)result;

			if (!Validator.equals(uuid, penaltyCode.getUuid()) ||
					(groupId != penaltyCode.getGroupId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_PENALTYCODE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_G_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(groupId);

				List<PenaltyCode> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
						finderArgs, list);
				}
				else {
					PenaltyCode penaltyCode = list.get(0);

					result = penaltyCode;

					cacheResult(penaltyCode);

					if ((penaltyCode.getUuid() == null) ||
							!penaltyCode.getUuid().equals(uuid) ||
							(penaltyCode.getGroupId() != groupId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
							finderArgs, penaltyCode);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (PenaltyCode)result;
		}
	}

	/**
	 * Removes the penalty code where uuid = &#63; and groupId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the penalty code that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode removeByUUID_G(String uuid, long groupId)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = findByUUID_G(uuid, groupId);

		return remove(penaltyCode);
	}

	/**
	 * Returns the number of penalty codes where uuid = &#63; and groupId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the number of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUUID_G(String uuid, long groupId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_G;

		Object[] finderArgs = new Object[] { uuid, groupId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_PENALTYCODE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_G_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(groupId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_G_UUID_1 = "penaltyCode.uuid IS NULL AND ";
	private static final String _FINDER_COLUMN_UUID_G_UUID_2 = "penaltyCode.uuid = ? AND ";
	private static final String _FINDER_COLUMN_UUID_G_UUID_3 = "(penaltyCode.uuid IS NULL OR penaltyCode.uuid = '') AND ";
	private static final String _FINDER_COLUMN_UUID_G_GROUPID_2 = "penaltyCode.groupId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, PenaltyCodeImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C =
		new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, PenaltyCodeImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid_C",
			new String[] { String.class.getName(), Long.class.getName() },
			PenaltyCodeModelImpl.UUID_COLUMN_BITMASK |
			PenaltyCodeModelImpl.COMPANYID_COLUMN_BITMASK |
			PenaltyCodeModelImpl.ASSIGNEDCODE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID_C = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid_C",
			new String[] { String.class.getName(), Long.class.getName() });

	/**
	 * Returns all the penalty codes where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findByUuid_C(String uuid, long companyId)
		throws SystemException {
		return findByUuid_C(uuid, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty codes where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of penalty codes
	 * @param end the upper bound of the range of penalty codes (not inclusive)
	 * @return the range of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findByUuid_C(String uuid, long companyId,
		int start, int end) throws SystemException {
		return findByUuid_C(uuid, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty codes where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of penalty codes
	 * @param end the upper bound of the range of penalty codes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findByUuid_C(String uuid, long companyId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C;
			finderArgs = new Object[] { uuid, companyId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C;
			finderArgs = new Object[] {
					uuid, companyId,
					
					start, end, orderByComparator
				};
		}

		List<PenaltyCode> list = (List<PenaltyCode>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PenaltyCode penaltyCode : list) {
				if (!Validator.equals(uuid, penaltyCode.getUuid()) ||
						(companyId != penaltyCode.getCompanyId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_PENALTYCODE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_C_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PenaltyCodeModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<PenaltyCode>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyCode>(list);
				}
				else {
					list = (List<PenaltyCode>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first penalty code in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode findByUuid_C_First(String uuid, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = fetchByUuid_C_First(uuid, companyId,
				orderByComparator);

		if (penaltyCode != null) {
			return penaltyCode;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyCodeException(msg.toString());
	}

	/**
	 * Returns the first penalty code in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty code, or <code>null</code> if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByUuid_C_First(String uuid, long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		List<PenaltyCode> list = findByUuid_C(uuid, companyId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last penalty code in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode findByUuid_C_Last(String uuid, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = fetchByUuid_C_Last(uuid, companyId,
				orderByComparator);

		if (penaltyCode != null) {
			return penaltyCode;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyCodeException(msg.toString());
	}

	/**
	 * Returns the last penalty code in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty code, or <code>null</code> if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByUuid_C_Last(String uuid, long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid_C(uuid, companyId);

		if (count == 0) {
			return null;
		}

		List<PenaltyCode> list = findByUuid_C(uuid, companyId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the penalty codes before and after the current penalty code in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param penaltyCodeId the primary key of the current penalty code
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a penalty code with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode[] findByUuid_C_PrevAndNext(long penaltyCodeId,
		String uuid, long companyId, OrderByComparator orderByComparator)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = findByPrimaryKey(penaltyCodeId);

		Session session = null;

		try {
			session = openSession();

			PenaltyCode[] array = new PenaltyCodeImpl[3];

			array[0] = getByUuid_C_PrevAndNext(session, penaltyCode, uuid,
					companyId, orderByComparator, true);

			array[1] = penaltyCode;

			array[2] = getByUuid_C_PrevAndNext(session, penaltyCode, uuid,
					companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyCode getByUuid_C_PrevAndNext(Session session,
		PenaltyCode penaltyCode, String uuid, long companyId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PENALTYCODE_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_C_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_C_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_C_UUID_2);
		}

		query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PenaltyCodeModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyCode);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyCode> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the penalty codes where uuid = &#63; and companyId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid_C(String uuid, long companyId)
		throws SystemException {
		for (PenaltyCode penaltyCode : findByUuid_C(uuid, companyId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(penaltyCode);
		}
	}

	/**
	 * Returns the number of penalty codes where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the number of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid_C(String uuid, long companyId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_C;

		Object[] finderArgs = new Object[] { uuid, companyId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_PENALTYCODE_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_C_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_C_UUID_1 = "penaltyCode.uuid IS NULL AND ";
	private static final String _FINDER_COLUMN_UUID_C_UUID_2 = "penaltyCode.uuid = ? AND ";
	private static final String _FINDER_COLUMN_UUID_C_UUID_3 = "(penaltyCode.uuid IS NULL OR penaltyCode.uuid = '') AND ";
	private static final String _FINDER_COLUMN_UUID_C_COMPANYID_2 = "penaltyCode.companyId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_GROUPID = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, PenaltyCodeImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByGroupId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID =
		new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, PenaltyCodeImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByGroupId",
			new String[] { Long.class.getName() },
			PenaltyCodeModelImpl.GROUPID_COLUMN_BITMASK |
			PenaltyCodeModelImpl.ASSIGNEDCODE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_GROUPID = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByGroupId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the penalty codes where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findByGroupId(long groupId)
		throws SystemException {
		return findByGroupId(groupId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty codes where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of penalty codes
	 * @param end the upper bound of the range of penalty codes (not inclusive)
	 * @return the range of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findByGroupId(long groupId, int start, int end)
		throws SystemException {
		return findByGroupId(groupId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty codes where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of penalty codes
	 * @param end the upper bound of the range of penalty codes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findByGroupId(long groupId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID;
			finderArgs = new Object[] { groupId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_GROUPID;
			finderArgs = new Object[] { groupId, start, end, orderByComparator };
		}

		List<PenaltyCode> list = (List<PenaltyCode>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (PenaltyCode penaltyCode : list) {
				if ((groupId != penaltyCode.getGroupId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_PENALTYCODE_WHERE);

			query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(PenaltyCodeModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				if (!pagination) {
					list = (List<PenaltyCode>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyCode>(list);
				}
				else {
					list = (List<PenaltyCode>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first penalty code in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode findByGroupId_First(long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = fetchByGroupId_First(groupId,
				orderByComparator);

		if (penaltyCode != null) {
			return penaltyCode;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyCodeException(msg.toString());
	}

	/**
	 * Returns the first penalty code in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching penalty code, or <code>null</code> if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByGroupId_First(long groupId,
		OrderByComparator orderByComparator) throws SystemException {
		List<PenaltyCode> list = findByGroupId(groupId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last penalty code in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode findByGroupId_Last(long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = fetchByGroupId_Last(groupId, orderByComparator);

		if (penaltyCode != null) {
			return penaltyCode;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchPenaltyCodeException(msg.toString());
	}

	/**
	 * Returns the last penalty code in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching penalty code, or <code>null</code> if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByGroupId_Last(long groupId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByGroupId(groupId);

		if (count == 0) {
			return null;
		}

		List<PenaltyCode> list = findByGroupId(groupId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the penalty codes before and after the current penalty code in the ordered set where groupId = &#63;.
	 *
	 * @param penaltyCodeId the primary key of the current penalty code
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a penalty code with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode[] findByGroupId_PrevAndNext(long penaltyCodeId,
		long groupId, OrderByComparator orderByComparator)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = findByPrimaryKey(penaltyCodeId);

		Session session = null;

		try {
			session = openSession();

			PenaltyCode[] array = new PenaltyCodeImpl[3];

			array[0] = getByGroupId_PrevAndNext(session, penaltyCode, groupId,
					orderByComparator, true);

			array[1] = penaltyCode;

			array[2] = getByGroupId_PrevAndNext(session, penaltyCode, groupId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyCode getByGroupId_PrevAndNext(Session session,
		PenaltyCode penaltyCode, long groupId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_PENALTYCODE_WHERE);

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(PenaltyCodeModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(groupId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyCode);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyCode> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Returns all the penalty codes that the user has permission to view where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the matching penalty codes that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> filterFindByGroupId(long groupId)
		throws SystemException {
		return filterFindByGroupId(groupId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty codes that the user has permission to view where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of penalty codes
	 * @param end the upper bound of the range of penalty codes (not inclusive)
	 * @return the range of matching penalty codes that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> filterFindByGroupId(long groupId, int start,
		int end) throws SystemException {
		return filterFindByGroupId(groupId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty codes that the user has permissions to view where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of penalty codes
	 * @param end the upper bound of the range of penalty codes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching penalty codes that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> filterFindByGroupId(long groupId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return findByGroupId(groupId, start, end, orderByComparator);
		}

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(3 +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		if (getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_PENALTYCODE_WHERE);
		}
		else {
			query.append(_FILTER_SQL_SELECT_PENALTYCODE_NO_INLINE_DISTINCT_WHERE_1);
		}

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (!getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_PENALTYCODE_NO_INLINE_DISTINCT_WHERE_2);
		}

		if (orderByComparator != null) {
			if (getDB().isSupportsInlineDistinct()) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator, true);
			}
			else {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_TABLE,
					orderByComparator, true);
			}
		}
		else {
			if (getDB().isSupportsInlineDistinct()) {
				query.append(PenaltyCodeModelImpl.ORDER_BY_JPQL);
			}
			else {
				query.append(PenaltyCodeModelImpl.ORDER_BY_SQL);
			}
		}

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				PenaltyCode.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		Session session = null;

		try {
			session = openSession();

			SQLQuery q = session.createSQLQuery(sql);

			if (getDB().isSupportsInlineDistinct()) {
				q.addEntity(_FILTER_ENTITY_ALIAS, PenaltyCodeImpl.class);
			}
			else {
				q.addEntity(_FILTER_ENTITY_TABLE, PenaltyCodeImpl.class);
			}

			QueryPos qPos = QueryPos.getInstance(q);

			qPos.add(groupId);

			return (List<PenaltyCode>)QueryUtil.list(q, getDialect(), start, end);
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	/**
	 * Returns the penalty codes before and after the current penalty code in the ordered set of penalty codes that the user has permission to view where groupId = &#63;.
	 *
	 * @param penaltyCodeId the primary key of the current penalty code
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a penalty code with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode[] filterFindByGroupId_PrevAndNext(long penaltyCodeId,
		long groupId, OrderByComparator orderByComparator)
		throws NoSuchPenaltyCodeException, SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return findByGroupId_PrevAndNext(penaltyCodeId, groupId,
				orderByComparator);
		}

		PenaltyCode penaltyCode = findByPrimaryKey(penaltyCodeId);

		Session session = null;

		try {
			session = openSession();

			PenaltyCode[] array = new PenaltyCodeImpl[3];

			array[0] = filterGetByGroupId_PrevAndNext(session, penaltyCode,
					groupId, orderByComparator, true);

			array[1] = penaltyCode;

			array[2] = filterGetByGroupId_PrevAndNext(session, penaltyCode,
					groupId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected PenaltyCode filterGetByGroupId_PrevAndNext(Session session,
		PenaltyCode penaltyCode, long groupId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		if (getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_PENALTYCODE_WHERE);
		}
		else {
			query.append(_FILTER_SQL_SELECT_PENALTYCODE_NO_INLINE_DISTINCT_WHERE_1);
		}

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (!getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_PENALTYCODE_NO_INLINE_DISTINCT_WHERE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				if (getDB().isSupportsInlineDistinct()) {
					query.append(_ORDER_BY_ENTITY_ALIAS);
				}
				else {
					query.append(_ORDER_BY_ENTITY_TABLE);
				}

				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				if (getDB().isSupportsInlineDistinct()) {
					query.append(_ORDER_BY_ENTITY_ALIAS);
				}
				else {
					query.append(_ORDER_BY_ENTITY_TABLE);
				}

				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			if (getDB().isSupportsInlineDistinct()) {
				query.append(PenaltyCodeModelImpl.ORDER_BY_JPQL);
			}
			else {
				query.append(PenaltyCodeModelImpl.ORDER_BY_SQL);
			}
		}

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				PenaltyCode.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		SQLQuery q = session.createSQLQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		if (getDB().isSupportsInlineDistinct()) {
			q.addEntity(_FILTER_ENTITY_ALIAS, PenaltyCodeImpl.class);
		}
		else {
			q.addEntity(_FILTER_ENTITY_TABLE, PenaltyCodeImpl.class);
		}

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(groupId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(penaltyCode);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<PenaltyCode> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the penalty codes where groupId = &#63; from the database.
	 *
	 * @param groupId the group ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByGroupId(long groupId) throws SystemException {
		for (PenaltyCode penaltyCode : findByGroupId(groupId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(penaltyCode);
		}
	}

	/**
	 * Returns the number of penalty codes where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the number of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByGroupId(long groupId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_GROUPID;

		Object[] finderArgs = new Object[] { groupId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PENALTYCODE_WHERE);

			query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of penalty codes that the user has permission to view where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the number of matching penalty codes that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int filterCountByGroupId(long groupId) throws SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return countByGroupId(groupId);
		}

		StringBundler query = new StringBundler(2);

		query.append(_FILTER_SQL_COUNT_PENALTYCODE_WHERE);

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				PenaltyCode.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		Session session = null;

		try {
			session = openSession();

			SQLQuery q = session.createSQLQuery(sql);

			q.addScalar(COUNT_COLUMN_NAME,
				com.liferay.portal.kernel.dao.orm.Type.LONG);

			QueryPos qPos = QueryPos.getInstance(q);

			qPos.add(groupId);

			Long count = (Long)q.uniqueResult();

			return count.intValue();
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	private static final String _FINDER_COLUMN_GROUPID_GROUPID_2 = "penaltyCode.groupId = ?";
	public static final FinderPath FINDER_PATH_FETCH_BY_ASSIGNEDCODE = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, PenaltyCodeImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByAssignedCode",
			new String[] { String.class.getName() },
			PenaltyCodeModelImpl.ASSIGNEDCODE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_ASSIGNEDCODE = new FinderPath(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByAssignedCode",
			new String[] { String.class.getName() });

	/**
	 * Returns the penalty code where assignedCode = &#63; or throws a {@link com.qc.qcsms.NoSuchPenaltyCodeException} if it could not be found.
	 *
	 * @param assignedCode the assigned code
	 * @return the matching penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode findByAssignedCode(String assignedCode)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = fetchByAssignedCode(assignedCode);

		if (penaltyCode == null) {
			StringBundler msg = new StringBundler(4);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("assignedCode=");
			msg.append(assignedCode);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchPenaltyCodeException(msg.toString());
		}

		return penaltyCode;
	}

	/**
	 * Returns the penalty code where assignedCode = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param assignedCode the assigned code
	 * @return the matching penalty code, or <code>null</code> if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByAssignedCode(String assignedCode)
		throws SystemException {
		return fetchByAssignedCode(assignedCode, true);
	}

	/**
	 * Returns the penalty code where assignedCode = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param assignedCode the assigned code
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching penalty code, or <code>null</code> if a matching penalty code could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByAssignedCode(String assignedCode,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { assignedCode };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_ASSIGNEDCODE,
					finderArgs, this);
		}

		if (result instanceof PenaltyCode) {
			PenaltyCode penaltyCode = (PenaltyCode)result;

			if (!Validator.equals(assignedCode, penaltyCode.getAssignedCode())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_SELECT_PENALTYCODE_WHERE);

			boolean bindAssignedCode = false;

			if (assignedCode == null) {
				query.append(_FINDER_COLUMN_ASSIGNEDCODE_ASSIGNEDCODE_1);
			}
			else if (assignedCode.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ASSIGNEDCODE_ASSIGNEDCODE_3);
			}
			else {
				bindAssignedCode = true;

				query.append(_FINDER_COLUMN_ASSIGNEDCODE_ASSIGNEDCODE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAssignedCode) {
					qPos.add(assignedCode);
				}

				List<PenaltyCode> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ASSIGNEDCODE,
						finderArgs, list);
				}
				else {
					if ((list.size() > 1) && _log.isWarnEnabled()) {
						_log.warn(
							"PenaltyCodePersistenceImpl.fetchByAssignedCode(String, boolean) with parameters (" +
							StringUtil.merge(finderArgs) +
							") yields a result set with more than 1 result. This violates the logical unique restriction. There is no order guarantee on which result is returned by this finder.");
					}

					PenaltyCode penaltyCode = list.get(0);

					result = penaltyCode;

					cacheResult(penaltyCode);

					if ((penaltyCode.getAssignedCode() == null) ||
							!penaltyCode.getAssignedCode().equals(assignedCode)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ASSIGNEDCODE,
							finderArgs, penaltyCode);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_ASSIGNEDCODE,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (PenaltyCode)result;
		}
	}

	/**
	 * Removes the penalty code where assignedCode = &#63; from the database.
	 *
	 * @param assignedCode the assigned code
	 * @return the penalty code that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode removeByAssignedCode(String assignedCode)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = findByAssignedCode(assignedCode);

		return remove(penaltyCode);
	}

	/**
	 * Returns the number of penalty codes where assignedCode = &#63;.
	 *
	 * @param assignedCode the assigned code
	 * @return the number of matching penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByAssignedCode(String assignedCode)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_ASSIGNEDCODE;

		Object[] finderArgs = new Object[] { assignedCode };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_PENALTYCODE_WHERE);

			boolean bindAssignedCode = false;

			if (assignedCode == null) {
				query.append(_FINDER_COLUMN_ASSIGNEDCODE_ASSIGNEDCODE_1);
			}
			else if (assignedCode.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_ASSIGNEDCODE_ASSIGNEDCODE_3);
			}
			else {
				bindAssignedCode = true;

				query.append(_FINDER_COLUMN_ASSIGNEDCODE_ASSIGNEDCODE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindAssignedCode) {
					qPos.add(assignedCode);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_ASSIGNEDCODE_ASSIGNEDCODE_1 = "penaltyCode.assignedCode IS NULL";
	private static final String _FINDER_COLUMN_ASSIGNEDCODE_ASSIGNEDCODE_2 = "penaltyCode.assignedCode = ?";
	private static final String _FINDER_COLUMN_ASSIGNEDCODE_ASSIGNEDCODE_3 = "(penaltyCode.assignedCode IS NULL OR penaltyCode.assignedCode = '')";

	public PenaltyCodePersistenceImpl() {
		setModelClass(PenaltyCode.class);
	}

	/**
	 * Caches the penalty code in the entity cache if it is enabled.
	 *
	 * @param penaltyCode the penalty code
	 */
	@Override
	public void cacheResult(PenaltyCode penaltyCode) {
		EntityCacheUtil.putResult(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeImpl.class, penaltyCode.getPrimaryKey(), penaltyCode);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
			new Object[] { penaltyCode.getUuid(), penaltyCode.getGroupId() },
			penaltyCode);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ASSIGNEDCODE,
			new Object[] { penaltyCode.getAssignedCode() }, penaltyCode);

		penaltyCode.resetOriginalValues();
	}

	/**
	 * Caches the penalty codes in the entity cache if it is enabled.
	 *
	 * @param penaltyCodes the penalty codes
	 */
	@Override
	public void cacheResult(List<PenaltyCode> penaltyCodes) {
		for (PenaltyCode penaltyCode : penaltyCodes) {
			if (EntityCacheUtil.getResult(
						PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
						PenaltyCodeImpl.class, penaltyCode.getPrimaryKey()) == null) {
				cacheResult(penaltyCode);
			}
			else {
				penaltyCode.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all penalty codes.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(PenaltyCodeImpl.class.getName());
		}

		EntityCacheUtil.clearCache(PenaltyCodeImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the penalty code.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(PenaltyCode penaltyCode) {
		EntityCacheUtil.removeResult(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeImpl.class, penaltyCode.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(penaltyCode);
	}

	@Override
	public void clearCache(List<PenaltyCode> penaltyCodes) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (PenaltyCode penaltyCode : penaltyCodes) {
			EntityCacheUtil.removeResult(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
				PenaltyCodeImpl.class, penaltyCode.getPrimaryKey());

			clearUniqueFindersCache(penaltyCode);
		}
	}

	protected void cacheUniqueFindersCache(PenaltyCode penaltyCode) {
		if (penaltyCode.isNew()) {
			Object[] args = new Object[] {
					penaltyCode.getUuid(), penaltyCode.getGroupId()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
				penaltyCode);

			args = new Object[] { penaltyCode.getAssignedCode() };

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_ASSIGNEDCODE, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ASSIGNEDCODE, args,
				penaltyCode);
		}
		else {
			PenaltyCodeModelImpl penaltyCodeModelImpl = (PenaltyCodeModelImpl)penaltyCode;

			if ((penaltyCodeModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyCode.getUuid(), penaltyCode.getGroupId()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
					Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
					penaltyCode);
			}

			if ((penaltyCodeModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_ASSIGNEDCODE.getColumnBitmask()) != 0) {
				Object[] args = new Object[] { penaltyCode.getAssignedCode() };

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_ASSIGNEDCODE,
					args, Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_ASSIGNEDCODE,
					args, penaltyCode);
			}
		}
	}

	protected void clearUniqueFindersCache(PenaltyCode penaltyCode) {
		PenaltyCodeModelImpl penaltyCodeModelImpl = (PenaltyCodeModelImpl)penaltyCode;

		Object[] args = new Object[] {
				penaltyCode.getUuid(), penaltyCode.getGroupId()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);

		if ((penaltyCodeModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
			args = new Object[] {
					penaltyCodeModelImpl.getOriginalUuid(),
					penaltyCodeModelImpl.getOriginalGroupId()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);
		}

		args = new Object[] { penaltyCode.getAssignedCode() };

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNEDCODE, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_ASSIGNEDCODE, args);

		if ((penaltyCodeModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_ASSIGNEDCODE.getColumnBitmask()) != 0) {
			args = new Object[] { penaltyCodeModelImpl.getOriginalAssignedCode() };

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_ASSIGNEDCODE, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_ASSIGNEDCODE, args);
		}
	}

	/**
	 * Creates a new penalty code with the primary key. Does not add the penalty code to the database.
	 *
	 * @param penaltyCodeId the primary key for the new penalty code
	 * @return the new penalty code
	 */
	@Override
	public PenaltyCode create(long penaltyCodeId) {
		PenaltyCode penaltyCode = new PenaltyCodeImpl();

		penaltyCode.setNew(true);
		penaltyCode.setPrimaryKey(penaltyCodeId);

		String uuid = PortalUUIDUtil.generate();

		penaltyCode.setUuid(uuid);

		return penaltyCode;
	}

	/**
	 * Removes the penalty code with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param penaltyCodeId the primary key of the penalty code
	 * @return the penalty code that was removed
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a penalty code with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode remove(long penaltyCodeId)
		throws NoSuchPenaltyCodeException, SystemException {
		return remove((Serializable)penaltyCodeId);
	}

	/**
	 * Removes the penalty code with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the penalty code
	 * @return the penalty code that was removed
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a penalty code with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode remove(Serializable primaryKey)
		throws NoSuchPenaltyCodeException, SystemException {
		Session session = null;

		try {
			session = openSession();

			PenaltyCode penaltyCode = (PenaltyCode)session.get(PenaltyCodeImpl.class,
					primaryKey);

			if (penaltyCode == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchPenaltyCodeException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(penaltyCode);
		}
		catch (NoSuchPenaltyCodeException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected PenaltyCode removeImpl(PenaltyCode penaltyCode)
		throws SystemException {
		penaltyCode = toUnwrappedModel(penaltyCode);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(penaltyCode)) {
				penaltyCode = (PenaltyCode)session.get(PenaltyCodeImpl.class,
						penaltyCode.getPrimaryKeyObj());
			}

			if (penaltyCode != null) {
				session.delete(penaltyCode);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (penaltyCode != null) {
			clearCache(penaltyCode);
		}

		return penaltyCode;
	}

	@Override
	public PenaltyCode updateImpl(com.qc.qcsms.model.PenaltyCode penaltyCode)
		throws SystemException {
		penaltyCode = toUnwrappedModel(penaltyCode);

		boolean isNew = penaltyCode.isNew();

		PenaltyCodeModelImpl penaltyCodeModelImpl = (PenaltyCodeModelImpl)penaltyCode;

		if (Validator.isNull(penaltyCode.getUuid())) {
			String uuid = PortalUUIDUtil.generate();

			penaltyCode.setUuid(uuid);
		}

		Session session = null;

		try {
			session = openSession();

			if (penaltyCode.isNew()) {
				session.save(penaltyCode);

				penaltyCode.setNew(false);
			}
			else {
				session.merge(penaltyCode);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !PenaltyCodeModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((penaltyCodeModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyCodeModelImpl.getOriginalUuid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);

				args = new Object[] { penaltyCodeModelImpl.getUuid() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);
			}

			if ((penaltyCodeModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyCodeModelImpl.getOriginalUuid(),
						penaltyCodeModelImpl.getOriginalCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
					args);

				args = new Object[] {
						penaltyCodeModelImpl.getUuid(),
						penaltyCodeModelImpl.getCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
					args);
			}

			if ((penaltyCodeModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						penaltyCodeModelImpl.getOriginalGroupId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_GROUPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID,
					args);

				args = new Object[] { penaltyCodeModelImpl.getGroupId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_GROUPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID,
					args);
			}
		}

		EntityCacheUtil.putResult(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
			PenaltyCodeImpl.class, penaltyCode.getPrimaryKey(), penaltyCode);

		clearUniqueFindersCache(penaltyCode);
		cacheUniqueFindersCache(penaltyCode);

		return penaltyCode;
	}

	protected PenaltyCode toUnwrappedModel(PenaltyCode penaltyCode) {
		if (penaltyCode instanceof PenaltyCodeImpl) {
			return penaltyCode;
		}

		PenaltyCodeImpl penaltyCodeImpl = new PenaltyCodeImpl();

		penaltyCodeImpl.setNew(penaltyCode.isNew());
		penaltyCodeImpl.setPrimaryKey(penaltyCode.getPrimaryKey());

		penaltyCodeImpl.setUuid(penaltyCode.getUuid());
		penaltyCodeImpl.setPenaltyCodeId(penaltyCode.getPenaltyCodeId());
		penaltyCodeImpl.setGroupId(penaltyCode.getGroupId());
		penaltyCodeImpl.setCompanyId(penaltyCode.getCompanyId());
		penaltyCodeImpl.setUserId(penaltyCode.getUserId());
		penaltyCodeImpl.setUserName(penaltyCode.getUserName());
		penaltyCodeImpl.setCreateDate(penaltyCode.getCreateDate());
		penaltyCodeImpl.setModifiedDate(penaltyCode.getModifiedDate());
		penaltyCodeImpl.setAssignedCode(penaltyCode.getAssignedCode());
		penaltyCodeImpl.setDescription(penaltyCode.getDescription());

		return penaltyCodeImpl;
	}

	/**
	 * Returns the penalty code with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the penalty code
	 * @return the penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a penalty code with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode findByPrimaryKey(Serializable primaryKey)
		throws NoSuchPenaltyCodeException, SystemException {
		PenaltyCode penaltyCode = fetchByPrimaryKey(primaryKey);

		if (penaltyCode == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchPenaltyCodeException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return penaltyCode;
	}

	/**
	 * Returns the penalty code with the primary key or throws a {@link com.qc.qcsms.NoSuchPenaltyCodeException} if it could not be found.
	 *
	 * @param penaltyCodeId the primary key of the penalty code
	 * @return the penalty code
	 * @throws com.qc.qcsms.NoSuchPenaltyCodeException if a penalty code with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode findByPrimaryKey(long penaltyCodeId)
		throws NoSuchPenaltyCodeException, SystemException {
		return findByPrimaryKey((Serializable)penaltyCodeId);
	}

	/**
	 * Returns the penalty code with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the penalty code
	 * @return the penalty code, or <code>null</code> if a penalty code with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		PenaltyCode penaltyCode = (PenaltyCode)EntityCacheUtil.getResult(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
				PenaltyCodeImpl.class, primaryKey);

		if (penaltyCode == _nullPenaltyCode) {
			return null;
		}

		if (penaltyCode == null) {
			Session session = null;

			try {
				session = openSession();

				penaltyCode = (PenaltyCode)session.get(PenaltyCodeImpl.class,
						primaryKey);

				if (penaltyCode != null) {
					cacheResult(penaltyCode);
				}
				else {
					EntityCacheUtil.putResult(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
						PenaltyCodeImpl.class, primaryKey, _nullPenaltyCode);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(PenaltyCodeModelImpl.ENTITY_CACHE_ENABLED,
					PenaltyCodeImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return penaltyCode;
	}

	/**
	 * Returns the penalty code with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param penaltyCodeId the primary key of the penalty code
	 * @return the penalty code, or <code>null</code> if a penalty code with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public PenaltyCode fetchByPrimaryKey(long penaltyCodeId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)penaltyCodeId);
	}

	/**
	 * Returns all the penalty codes.
	 *
	 * @return the penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the penalty codes.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of penalty codes
	 * @param end the upper bound of the range of penalty codes (not inclusive)
	 * @return the range of penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the penalty codes.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of penalty codes
	 * @param end the upper bound of the range of penalty codes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<PenaltyCode> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<PenaltyCode> list = (List<PenaltyCode>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_PENALTYCODE);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_PENALTYCODE;

				if (pagination) {
					sql = sql.concat(PenaltyCodeModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<PenaltyCode>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<PenaltyCode>(list);
				}
				else {
					list = (List<PenaltyCode>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the penalty codes from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (PenaltyCode penaltyCode : findAll()) {
			remove(penaltyCode);
		}
	}

	/**
	 * Returns the number of penalty codes.
	 *
	 * @return the number of penalty codes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_PENALTYCODE);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the penalty code persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.qc.qcsms.model.PenaltyCode")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<PenaltyCode>> listenersList = new ArrayList<ModelListener<PenaltyCode>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<PenaltyCode>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(PenaltyCodeImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_PENALTYCODE = "SELECT penaltyCode FROM PenaltyCode penaltyCode";
	private static final String _SQL_SELECT_PENALTYCODE_WHERE = "SELECT penaltyCode FROM PenaltyCode penaltyCode WHERE ";
	private static final String _SQL_COUNT_PENALTYCODE = "SELECT COUNT(penaltyCode) FROM PenaltyCode penaltyCode";
	private static final String _SQL_COUNT_PENALTYCODE_WHERE = "SELECT COUNT(penaltyCode) FROM PenaltyCode penaltyCode WHERE ";
	private static final String _FILTER_ENTITY_TABLE_FILTER_PK_COLUMN = "penaltyCode.penaltyCodeId";
	private static final String _FILTER_SQL_SELECT_PENALTYCODE_WHERE = "SELECT DISTINCT {penaltyCode.*} FROM qc_PenaltyCode penaltyCode WHERE ";
	private static final String _FILTER_SQL_SELECT_PENALTYCODE_NO_INLINE_DISTINCT_WHERE_1 =
		"SELECT {qc_PenaltyCode.*} FROM (SELECT DISTINCT penaltyCode.penaltyCodeId FROM qc_PenaltyCode penaltyCode WHERE ";
	private static final String _FILTER_SQL_SELECT_PENALTYCODE_NO_INLINE_DISTINCT_WHERE_2 =
		") TEMP_TABLE INNER JOIN qc_PenaltyCode ON TEMP_TABLE.penaltyCodeId = qc_PenaltyCode.penaltyCodeId";
	private static final String _FILTER_SQL_COUNT_PENALTYCODE_WHERE = "SELECT COUNT(DISTINCT penaltyCode.penaltyCodeId) AS COUNT_VALUE FROM qc_PenaltyCode penaltyCode WHERE ";
	private static final String _FILTER_ENTITY_ALIAS = "penaltyCode";
	private static final String _FILTER_ENTITY_TABLE = "qc_PenaltyCode";
	private static final String _ORDER_BY_ENTITY_ALIAS = "penaltyCode.";
	private static final String _ORDER_BY_ENTITY_TABLE = "qc_PenaltyCode.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No PenaltyCode exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No PenaltyCode exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(PenaltyCodePersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"uuid"
			});
	private static PenaltyCode _nullPenaltyCode = new PenaltyCodeImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<PenaltyCode> toCacheModel() {
				return _nullPenaltyCodeCacheModel;
			}
		};

	private static CacheModel<PenaltyCode> _nullPenaltyCodeCacheModel = new CacheModel<PenaltyCode>() {
			@Override
			public PenaltyCode toEntityModel() {
				return _nullPenaltyCode;
			}
		};
}