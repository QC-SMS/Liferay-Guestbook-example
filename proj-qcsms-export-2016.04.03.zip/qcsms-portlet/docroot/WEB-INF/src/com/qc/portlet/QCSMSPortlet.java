package com.qc.portlet;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class QCSMSPortlet
 */
public class QCSMSPortlet extends MVCPortlet {
 

}
