package com.qc.portlet;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.qc.qcsms.PenaltyCodeException;
import com.qc.qcsms.PenaltyCodeLengthException;
import com.qc.qcsms.PenaltyCodeUniqueException;
import com.qc.qcsms.PenaltyDescriptionException;
import com.qc.qcsms.PenaltyDescriptionLengthException;
import com.qc.qcsms.model.PenaltyCode;
import com.qc.qcsms.service.PenaltyCodeLocalServiceUtil;

/**
 * Portlet implementation class PenaltyCodeAdminPortlet
 */
public class PenaltyCodeAdminPortlet extends MVCPortlet {
	public void addPenaltyCode(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    PenaltyCode.class.getName(), request);
	    String assignedCode = ParamUtil.getString(request, "assignedCode");
	    String description = ParamUtil.getString(request, "description");
	    try {
	    	PenaltyCodeLocalServiceUtil.addPenaltyCode(serviceContext.getUserId(),
	            assignedCode, description, serviceContext);
	            SessionMessages.add(request, "penaltyCodeAdded");
	    } catch (PortalException e) {
	    	handlePortalException(request, response, e);
	    }
	}

	public void updatePenaltyCode(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    PenaltyCode.class.getName(), request);
	    String assignedCode = ParamUtil.getString(request, "assignedCode");
	    String description = ParamUtil.getString(request, "description");
	    long penaltyCodeId = ParamUtil.getLong(request, "penaltyCodeId");
	    try {
	    	PenaltyCodeLocalServiceUtil.updatePenaltyCode(serviceContext.getUserId(), 
	    			penaltyCodeId, assignedCode, description, serviceContext);
	            SessionMessages.add(request, "penaltyCodeUpdated");
	    } catch (PortalException pe) {
	    	handlePortalException(request, response, pe);
	    }
	}

	public void deletePenaltyCode(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    PenaltyCode.class.getName(), request);
	    long penaltyCodeId = ParamUtil.getLong(request, "penaltyCodeId");
	    try {
	            PenaltyCodeLocalServiceUtil.deletePenaltyCode(penaltyCodeId, serviceContext);
	            SessionMessages.add(request, "penaltyCodeDeleted");
	    } catch (PortalException pe) {
	            SessionErrors.add(request, pe.getClass().getName());
	    }
	}
	
	private void handlePortalException(ActionRequest request, ActionResponse response, PortalException e) {
    	if (e instanceof PenaltyCodeException) {
    		SessionErrors.add(request, "penalty-code");
    	} else if (e instanceof PenaltyCodeLengthException) {
    		SessionErrors.add(request, "penalty-code-length");
    	} else if (e instanceof PenaltyDescriptionException){
    		SessionErrors.add(request, "penalty-description");
    	} else if (e instanceof PenaltyDescriptionLengthException) {
    		SessionErrors.add(request, "penalty-description-length");
    	} else if (e instanceof PenaltyCodeUniqueException) {
    		SessionErrors.add(request, "penalty-code-unique");
    	} else {
            SessionErrors.add(request, e.getClass().getName());
    	}
        response.setRenderParameter("mvcPath", "/html/penaltycodeadmin/edit_penaltycode.jsp");		
	}
}
