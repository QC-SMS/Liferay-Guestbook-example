package com.qc.portlet;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.qc.qcsms.ClassCodeException;
import com.qc.qcsms.ClassCodeLengthException;
import com.qc.qcsms.FormClassException;
import com.qc.qcsms.model.StudentClass;
import com.qc.qcsms.service.StudentClassLocalServiceUtil;

/**
 * Portlet implementation class StudentClassAdminPortlet
 */
public class StudentClassAdminPortlet extends MVCPortlet {
	public void addStudentClass(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    StudentClass.class.getName(), request);
	    String classCode = ParamUtil.getString(request, "classCode");
	    try {
	    	StudentClassLocalServiceUtil.addStudentClass(serviceContext.getUserId(), classCode, serviceContext);
	
	            SessionMessages.add(request, "studentClassAdded");
	    } catch (PortalException e) {
	    	handlePortalException(request, response, e);
	    }
	}

	public void updateStudentClass(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    StudentClass.class.getName(), request);
	    String classCode = ParamUtil.getString(request, "classCode");
	    long studentClassId = ParamUtil.getLong(request, "studentClassId");
	    try {
	    	StudentClassLocalServiceUtil.updateStudentClass(serviceContext.getUserId(), 
	    			studentClassId, classCode, serviceContext);
	
	            SessionMessages.add(request, "studentClassUpdated");
	    } catch (PortalException pe) {
	    	handlePortalException(request, response, pe);
	    }
	}

	public void deleteStudentClass(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    StudentClass.class.getName(), request);
	    long studentClassId = ParamUtil.getLong(request, "studentClassId");
	    try {
	            StudentClassLocalServiceUtil.deleteStudentClass(studentClassId, serviceContext);
	            SessionMessages.add(request, "studentClassDeleted");
	    } catch (PortalException pe) {
	            SessionErrors.add(request, pe.getClass().getName());
	    }
	}
	
	private void handlePortalException(ActionRequest request, ActionResponse response, PortalException e) {
    	if (e instanceof FormClassException) {
    		SessionErrors.add(request, "form-class");
    	} else if (e instanceof ClassCodeException) {
    		SessionErrors.add(request, "class-code");
    	} else if (e instanceof ClassCodeLengthException) {
    		SessionErrors.add(request, "class-code-length");
    	} else {
            SessionErrors.add(request, e.getClass().getName());
    	}
        response.setRenderParameter("mvcPath", "/html/studentclassadmin/edit_studentclass.jsp");
	}
}
