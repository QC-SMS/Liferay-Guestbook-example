package com.qc.portlet;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.qc.qcsms.DisciplineCodeException;
import com.qc.qcsms.DisciplineCodeLengthException;
import com.qc.qcsms.DisciplineCodeUniqueException;
import com.qc.qcsms.DisciplineDescriptionException;
import com.qc.qcsms.DisciplineDescriptionLengthException;
import com.qc.qcsms.DisciplineSeverityException;
import com.qc.qcsms.model.DisciplineCode;
import com.qc.qcsms.service.DisciplineCodeLocalServiceUtil;

/**
 * Portlet implementation class DisciplineCodeAdmin
 */
public class DisciplineCodeAdminPortlet extends MVCPortlet {
	public void addDisciplineCode(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    DisciplineCode.class.getName(), request);
	    String assignedCode = ParamUtil.getString(request, "assignedCode");
	    String description = ParamUtil.getString(request, "description");
	    String severity = ParamUtil.getString(request, "severity");
	    try {
	    	DisciplineCodeLocalServiceUtil.addDisciplineCode(serviceContext.getUserId(),
	            assignedCode, description, severity, serviceContext);
	            SessionMessages.add(request, "disciplineCodeAdded");
	    } catch (PortalException e) {
	    	handlePortalException(request, response, e);
	    }
	}

	public void updateDisciplineCode(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    DisciplineCode.class.getName(), request);
	    String assignedCode = ParamUtil.getString(request, "assignedCode");
	    String description = ParamUtil.getString(request, "description");
	    String severity = ParamUtil.getString(request, "severity");
	    long disciplineCodeId = ParamUtil.getLong(request, "disciplineCodeId");
	    try {
	    	DisciplineCodeLocalServiceUtil.updateDisciplineCode(serviceContext.getUserId(), 
	    			disciplineCodeId, assignedCode, description, severity, serviceContext);
	            SessionMessages.add(request, "disciplineCodeUpdated");
	    } catch (PortalException pe) {
	    	handlePortalException(request, response, pe);
	    }
	}

	public void deleteDisciplineCode(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    DisciplineCode.class.getName(), request);
	    long disciplineCodeId = ParamUtil.getLong(request, "disciplineCodeId");
	    try {
	            DisciplineCodeLocalServiceUtil.deleteDisciplineCode(disciplineCodeId, serviceContext);
	            SessionMessages.add(request, "disciplineCodeDeleted");
	    } catch (PortalException pe) {
	            SessionErrors.add(request, pe.getClass().getName());
	    }
	}
	
	private void handlePortalException(ActionRequest request, ActionResponse response, PortalException e) {
    	if (e instanceof DisciplineCodeException) {
    		SessionErrors.add(request, "discipline-code");
    	} else if (e instanceof DisciplineCodeLengthException) {
    		SessionErrors.add(request, "discipline-code-length");
    	} else if (e instanceof DisciplineDescriptionException){
    		SessionErrors.add(request, "discipline-description");
    	} else if (e instanceof DisciplineDescriptionLengthException) {
    		SessionErrors.add(request, "discipline-description-length");
    	} else if (e instanceof DisciplineSeverityException) {
    		SessionErrors.add(request, "discipline-severity");
    	} else if (e instanceof DisciplineCodeUniqueException) {
    		SessionErrors.add(request, "discipline-code-unique");
    	} else {
            SessionErrors.add(request, e.getClass().getName());
    	}
        response.setRenderParameter("mvcPath", "/html/disciplinecodeadmin/edit_disciplinecode.jsp");
	}
}
