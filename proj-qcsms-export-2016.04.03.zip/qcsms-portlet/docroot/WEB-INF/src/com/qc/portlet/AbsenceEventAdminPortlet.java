package com.qc.portlet;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.qc.qcsms.AbsenceEventDateException;
import com.qc.qcsms.AbsenceEventDescriptionLengthException;
import com.qc.qcsms.AbsenceEventWholeDayIndException;
import com.qc.qcsms.NoSuchAbsenceCodeException;
import com.qc.qcsms.NoSuchStudentException;
import com.qc.qcsms.model.AbsenceEvent;
import com.qc.qcsms.service.AbsenceEventLocalServiceUtil;

/**
 * Portlet implementation class AbsenceEventAdminPortlet
 */
public class AbsenceEventAdminPortlet extends MVCPortlet {
	public void addAbsenceEvent(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    AbsenceEvent.class.getName(), request);
	    Long absenceCodeId = ParamUtil.getLong(request, "absenceCodeId");
	    Long studentId = ParamUtil.getLong(request, "studentId");
	    Date absenceDate = ParamUtil.getDate(request, "absenceDate", new SimpleDateFormat("M/d/y"));
	    String absenceDescription = ParamUtil.getString(request, "absenceDescription");
	    String wholeDayInd = ParamUtil.getString(request, "wholeDayInd");
	    try {
	    	AbsenceEventLocalServiceUtil.addAbsenceEvent(serviceContext.getUserId(),
	            absenceCodeId, studentId, absenceDate, absenceDescription, wholeDayInd, serviceContext);
	            SessionMessages.add(request, "absenceEventAdded");
	    } catch (PortalException e) {
	    	handlePortalException(request, response, e);
	    }
	}

	public void updateAbsenceEvent(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	    		AbsenceEvent.class.getName(), request);
	    Long absenceEventId = ParamUtil.getLong(request, "absenceEventId");
	    Long absenceCodeId = ParamUtil.getLong(request, "absenceCodeId");
	    Long studentId = ParamUtil.getLong(request, "studentId");
	    Date absenceDate = ParamUtil.getDate(request, "absenceDate", new SimpleDateFormat("M/d/y"));
	    String absenceDescription = ParamUtil.getString(request, "absenceDescription");
	    String wholeDayInd = ParamUtil.getString(request, "wholeDayInd");
	    
	    try {
	    	AbsenceEventLocalServiceUtil.updateAbsenceEvent(serviceContext.getUserId(), 
	    			absenceEventId, absenceCodeId, studentId, absenceDate, absenceDescription, wholeDayInd, serviceContext);
	        SessionMessages.add(request, "absenceEventUpdated");
	    } catch (PortalException pe) {
	    	handlePortalException(request, response, pe);
	    }
	}

	public void deleteAbsenceEvent(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    AbsenceEvent.class.getName(), request);
	    long absenceEventId = ParamUtil.getLong(request, "absenceEventId");
	    try {
	            AbsenceEventLocalServiceUtil.deleteAbsenceEvent(absenceEventId, serviceContext);
	            SessionMessages.add(request, "absenceEventDeleted");
	    } catch (PortalException pe) {
	            SessionErrors.add(request, pe.getClass().getName());
	    }
	}

	public void deleteMultipleAbsenceEvents(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    AbsenceEvent.class.getName(), request);
	    String absenceEventId = ParamUtil.getString(request, "absenceEventId");
	    StringTokenizer st = new StringTokenizer(absenceEventId, ",");
	    while(st.hasMoreTokens()) {
		    try {
	            AbsenceEventLocalServiceUtil.deleteAbsenceEvent(Long.parseLong(st.nextToken()), serviceContext);
	            SessionMessages.add(request, "absenceEventDeleted");
		    } catch (PortalException pe) {
		            SessionErrors.add(request, pe.getClass().getName());
		    }
	    }
	}
	
	private void handlePortalException(ActionRequest request, ActionResponse response, PortalException e) {
    	if (e instanceof NoSuchAbsenceCodeException) {
    		SessionErrors.add(request, "AbsenceEvent-AbsenceCode");
    	} else if (e instanceof NoSuchStudentException) {
    		SessionErrors.add(request, "AbsenceEvent-Student");
    	} else if (e instanceof AbsenceEventDateException) {
    		SessionErrors.add(request, "AbsenceEvent-Date");
    	} else if (e instanceof AbsenceEventDescriptionLengthException){
    		SessionErrors.add(request, "AbsenceEvent-Description-Length");
    	} else if (e instanceof AbsenceEventWholeDayIndException) {
    		SessionErrors.add(request, "AbsenceEvent-WholeDayInd");
    	} else {
            SessionErrors.add(request, e.getClass().getName());
    	}
        response.setRenderParameter("mvcPath", "/html/absenceeventadmin/edit_absenceevent.jsp");
	}
}
