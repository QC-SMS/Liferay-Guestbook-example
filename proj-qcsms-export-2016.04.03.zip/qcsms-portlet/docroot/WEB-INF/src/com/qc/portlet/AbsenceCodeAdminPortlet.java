package com.qc.portlet;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.qc.qcsms.AbsenceCodeException;
import com.qc.qcsms.AbsenceCodeLengthException;
import com.qc.qcsms.AbsenceCodeUniqueException;
import com.qc.qcsms.AbsenceDescriptionException;
import com.qc.qcsms.AbsenceDescriptionLengthException;
import com.qc.qcsms.model.AbsenceCode;
import com.qc.qcsms.service.AbsenceCodeLocalServiceUtil;

/**
 * Portlet implementation class AbsenceCodeAdminPortlet
 */
public class AbsenceCodeAdminPortlet extends MVCPortlet {
	public void addAbsenceCode(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    AbsenceCode.class.getName(), request);
	    String assignedCode = ParamUtil.getString(request, "assignedCode");
	    String description = ParamUtil.getString(request, "description");
	    try {
	    	AbsenceCodeLocalServiceUtil.addAbsenceCode(serviceContext.getUserId(),
	            assignedCode, description, serviceContext);
	            SessionMessages.add(request, "absenceCodeAdded");
	    } catch (PortalException e) {
	    	handlePortalException(request, response, e);
	    }
	}

	public void updateAbsenceCode(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    AbsenceCode.class.getName(), request);
	    String assignedCode = ParamUtil.getString(request, "assignedCode");
	    String description = ParamUtil.getString(request, "description");
	    long absenceCodeId = ParamUtil.getLong(request, "absenceCodeId");
	    try {
	    	AbsenceCodeLocalServiceUtil.updateAbsenceCode(serviceContext.getUserId(), 
	    			absenceCodeId, assignedCode, description, serviceContext);
	            SessionMessages.add(request, "absenceCodeUpdated");
	    } catch (PortalException pe) {
	    	handlePortalException(request, response, pe);
	    }
	}

	public void deleteAbsenceCode(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    AbsenceCode.class.getName(), request);
	    long absenceCodeId = ParamUtil.getLong(request, "absenceCodeId");
	    try {
	            AbsenceCodeLocalServiceUtil.deleteAbsenceCode(absenceCodeId, serviceContext);
	            SessionMessages.add(request, "absenceCodeDeleted");
	    } catch (PortalException pe) {
	            SessionErrors.add(request, pe.getClass().getName());
	    }
	}
	
	private void handlePortalException(ActionRequest request, ActionResponse response, PortalException e) {
    	if (e instanceof AbsenceCodeException) {
    		SessionErrors.add(request, "absence-code");
    	} else if (e instanceof AbsenceCodeLengthException) {
    		SessionErrors.add(request, "absence-code-length");
    	} else if (e instanceof AbsenceDescriptionException){
    		SessionErrors.add(request, "absence-description");
    	} else if (e instanceof AbsenceDescriptionLengthException) {
    		SessionErrors.add(request, "absence-description-length");
    	} else if (e instanceof AbsenceCodeUniqueException) {
    		SessionErrors.add(request, "absence-code-unique");
    	} else {
            SessionErrors.add(request, e.getClass().getName());
    	}
        response.setRenderParameter("mvcPath", "/html/absencecodeadmin/edit_absencecode.jsp");
	}
}
