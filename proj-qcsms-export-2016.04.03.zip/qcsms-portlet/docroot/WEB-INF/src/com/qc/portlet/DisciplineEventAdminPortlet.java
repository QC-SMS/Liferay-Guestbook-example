package com.qc.portlet;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.qc.qcsms.DisciplineEventDateException;
import com.qc.qcsms.DisciplineEventRemarksLengthException;
import com.qc.qcsms.DisciplineEventTeacherException;
import com.qc.qcsms.DisciplineEventTeacherLengthException;
import com.qc.qcsms.NoSuchDisciplineCodeException;
import com.qc.qcsms.NoSuchPenaltyCodeException;
import com.qc.qcsms.NoSuchStudentException;
import com.qc.qcsms.model.DisciplineEvent;
import com.qc.qcsms.service.DisciplineEventLocalServiceUtil;

/**
 * Portlet implementation class DisciplineActionPortlet
 */
public class DisciplineEventAdminPortlet extends MVCPortlet {
	public void addDisciplineEvent(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    DisciplineEvent.class.getName(), request);
	    Long studentId = ParamUtil.getLong(request, "studentId");
	    Long disciplineCodeId = ParamUtil.getLong(request, "disciplineCodeId");
	    Date eventDate = ParamUtil.getDate(request, "eventDate", new SimpleDateFormat("M/d/y"));
	    String remarks = ParamUtil.getString(request, "remarks");
	    Long penaltyCodeId = ParamUtil.getLong(request, "penaltyCodeId");
	    try {
	    	DisciplineEventLocalServiceUtil.addDisciplineEvent(serviceContext.getUserId(),
	            studentId, disciplineCodeId, eventDate, remarks, penaltyCodeId, serviceContext);
	            SessionMessages.add(request, "disciplineEventAdded");
	    } catch (PortalException e) {
	    	handlePortalException(request, response, e);
	    }
	}

	public void updateDisciplineEvent(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	    		DisciplineEvent.class.getName(), request);
	    Long disciplineEventId = ParamUtil.getLong(request, "disciplineEventId");
	    Long studentId = ParamUtil.getLong(request, "studentId");
	    Long disciplineCodeId = ParamUtil.getLong(request, "disciplineCodeId");
	    Date eventDate = ParamUtil.getDate(request, "eventDate", new SimpleDateFormat("M/d/y"));
	    String remarks = ParamUtil.getString(request, "remarks");
	    Long penaltyCodeId = ParamUtil.getLong(request, "penaltyCodeId");
	    try {
	    	DisciplineEventLocalServiceUtil.updateDisciplineEvent(serviceContext.getUserId(), 
	    			disciplineEventId, studentId, disciplineCodeId, eventDate, remarks, penaltyCodeId, serviceContext);
	        SessionMessages.add(request, "disciplineEventUpdated");
	    } catch (PortalException pe) {
	    	handlePortalException(request, response, pe);
	    }
	}

	public void deleteDisciplineEvent(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    DisciplineEvent.class.getName(), request);
	    long disciplineEventId = ParamUtil.getLong(request, "disciplineEventId");
	    try {
	            DisciplineEventLocalServiceUtil.deleteDisciplineEvent(disciplineEventId, serviceContext);
	            SessionMessages.add(request, "disciplineEventDeleted");
	    } catch (PortalException pe) {
	            SessionErrors.add(request, pe.getClass().getName());
	    }
	}
	
	public void deleteMultipleDisciplineEvents(ActionRequest request, ActionResponse response) 
        throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    DisciplineEvent.class.getName(), request);
	    String disciplineEventId = ParamUtil.getString(request, "disciplineEventId");
	    StringTokenizer st = new StringTokenizer(disciplineEventId, ",");
	    while(st.hasMoreTokens()) {
	    	long tDisciplineEventId = Long.parseLong(st.nextToken());
		    try {
	            DisciplineEventLocalServiceUtil.deleteDisciplineEvent(tDisciplineEventId, serviceContext);
	            SessionMessages.add(request, "disciplineEventDeleted");
		    } catch (PortalException pe) {
		            SessionErrors.add(request, pe.getClass().getName());
		    }
	    }
	}
	
	private void handlePortalException(ActionRequest request, ActionResponse response, PortalException e) {
    	if (e instanceof NoSuchStudentException) {
    		SessionErrors.add(request, "DisciplineEvent-Student");
    	} else if (e instanceof NoSuchDisciplineCodeException) {
    		SessionErrors.add(request, "DisciplineEvent-DisciplineCode");
    	} else if (e instanceof NoSuchPenaltyCodeException) {
    		SessionErrors.add(request, "DisciplineEvent-PenaltyCode");
    	} else if (e instanceof DisciplineEventDateException) {
    		SessionErrors.add(request, "DisciplineEvent-Date");
    	} else if (e instanceof DisciplineEventRemarksLengthException){
    		SessionErrors.add(request, "DisciplineEvent-Remarks-Length");
    	} else {
            SessionErrors.add(request, e.getClass().getName());
    	}
        response.setRenderParameter("mvcPath", "/html/disciplineeventadmin/edit_disciplineevent.jsp");
	}
}
