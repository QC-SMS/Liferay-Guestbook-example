package com.qc.portlet;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.qc.qcsms.ClassIdException;
import com.qc.qcsms.ClassNoException;
import com.qc.qcsms.ClassNoUniqueException;
import com.qc.qcsms.StudentNameException;
import com.qc.qcsms.StudentNameLengthException;
import com.qc.qcsms.model.Student;
import com.qc.qcsms.service.StudentLocalServiceUtil;

/**
 * Portlet implementation class StudentAdmin
 */
public class StudentAdminPortlet extends MVCPortlet {
	public void addStudent(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    Student.class.getName(), request);
	    String studentName = ParamUtil.getString(request, "studentName");
	    Long classId = ParamUtil.getLong(request, "classId");
	    int classNo = ParamUtil.getInteger(request, "classNo");
	    try {
	    	StudentLocalServiceUtil.addStudent(serviceContext.getUserId(),
	            studentName, classId, classNo, serviceContext);
	
	            SessionMessages.add(request, "studentAdded");
	    } catch (PortalException e) {
	    	handlePortalException(request, response, e);
	    }
	}

	public void updateStudent(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    Student.class.getName(), request);
	    String studentName = ParamUtil.getString(request, "studentName");
	    Long classId = ParamUtil.getLong(request, "classId");
	    int classNo = ParamUtil.getInteger(request, "classNo");
	    long studentId = ParamUtil.getLong(request, "studentId");
	    try {
	    	StudentLocalServiceUtil.updateStudent(serviceContext.getUserId(), 
	    			studentId, studentName, classId, classNo, serviceContext);
	        SessionMessages.add(request, "studentUpdated");
	    } catch (PortalException pe) {
	    	handlePortalException(request, response, pe);
	    }
	}

	public void deleteStudent(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
	    ServiceContext serviceContext = ServiceContextFactory.getInstance(
	                    Student.class.getName(), request);
	    long studentId = ParamUtil.getLong(request, "studentId");
	    try {
	            StudentLocalServiceUtil.deleteStudent(studentId, serviceContext);
	            SessionMessages.add(request, "studentDeleted");
	    } catch (PortalException pe) {
	            SessionErrors.add(request, pe.getClass().getName());
	    }
	}

	public void addDisciplineEvent(ActionRequest request, ActionResponse response)
            throws PortalException, SystemException {
		(new DisciplineEventAdminPortlet()).addDisciplineEvent(request, response);
	}
	
	private void handlePortalException(ActionRequest request, ActionResponse response, PortalException e) {
    	if (e instanceof StudentNameException) {
    		SessionErrors.add(request, "student-name");
    	} else if (e instanceof StudentNameLengthException) {
    		SessionErrors.add(request, "student-name-length");
    	} else if (e instanceof ClassIdException){
    		SessionErrors.add(request, "class-id");
    	} else if (e instanceof ClassNoException) {
    		SessionErrors.add(request, "class-no");
    	} else if (e instanceof ClassNoUniqueException){
    		SessionErrors.add(request, "class-no-unique");
    	} else {
            SessionErrors.add(request, e.getClass().getName());
    	}
        response.setRenderParameter("mvcPath", "/html/studentadmin/edit_student.jsp");
	}
}
