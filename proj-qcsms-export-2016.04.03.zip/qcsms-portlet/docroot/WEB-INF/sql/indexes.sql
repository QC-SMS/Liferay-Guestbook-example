create index IX_572E5252 on QC_AbsenceCode (assignedCode);
create index IX_3AF5BC87 on QC_AbsenceCode (groupId);
create index IX_DB8EC4D1 on QC_AbsenceCode (uuid_);
create index IX_27D0C2B7 on QC_AbsenceCode (uuid_, companyId);
create unique index IX_91488AF9 on QC_AbsenceCode (uuid_, groupId);

create index IX_2A252525 on QC_AbsenceEvent (absenceCodeId);
create index IX_51B9522B on QC_AbsenceEvent (absenceDate);
create index IX_76015DA on QC_AbsenceEvent (groupId);
create index IX_20D35016 on QC_AbsenceEvent (studentId);
create index IX_7F5556E4 on QC_AbsenceEvent (uuid_);
create index IX_6ECA36C4 on QC_AbsenceEvent (uuid_, companyId);
create unique index IX_D0399E46 on QC_AbsenceEvent (uuid_, groupId);

create index IX_CED624BF on QC_DisciplineCode (assignedCode);
create index IX_B9C9E392 on QC_DisciplineCode (code_);
create index IX_F3A2DC61 on QC_DisciplineCode (disciplineCode);
create index IX_59C559FA on QC_DisciplineCode (groupId);
create index IX_58D72761 on QC_DisciplineCode (severity);
create index IX_7C7D2304 on QC_DisciplineCode (uuid_);
create index IX_93F96A4 on QC_DisciplineCode (uuid_, companyId);
create unique index IX_BE457626 on QC_DisciplineCode (uuid_, groupId);

create index IX_4862BCEF on QC_DisciplineEvent (disciplineCodeId);
create index IX_2A685F5 on QC_DisciplineEvent (eventDate);
create index IX_C28426C7 on QC_DisciplineEvent (groupId);
create index IX_1DB0BA9E on QC_DisciplineEvent (penaltyCodeId);
create index IX_A336D9C3 on QC_DisciplineEvent (studentId);
create index IX_FFDC3CAF on QC_DisciplineEvent (teacher);
create index IX_FC32BF11 on QC_DisciplineEvent (uuid_);
create index IX_BB35E077 on QC_DisciplineEvent (uuid_, companyId);
create unique index IX_42DA18B9 on QC_DisciplineEvent (uuid_, groupId);

create index IX_89F3EA9E on QC_PenaltyCode (assignedCode);
create index IX_F74D24BB on QC_PenaltyCode (groupId);
create index IX_974AAA05 on QC_PenaltyCode (uuid_);
create index IX_D2395503 on QC_PenaltyCode (uuid_, companyId);
create unique index IX_29094045 on QC_PenaltyCode (uuid_, groupId);

create index IX_7BBDFCB1 on QC_PenaltyEvent (disciplineEventId);
create index IX_FFEA3794 on QC_PenaltyEvent (eventDate);
create index IX_D5F5B426 on QC_PenaltyEvent (groupId);
create index IX_887484BD on QC_PenaltyEvent (penaltyCodeId);
create index IX_A07A8B62 on QC_PenaltyEvent (studentId);
create index IX_3B161830 on QC_PenaltyEvent (uuid_);
create index IX_1173EDF8 on QC_PenaltyEvent (uuid_, companyId);
create unique index IX_308F927A on QC_PenaltyEvent (uuid_, groupId);

create index IX_4463046F on QC_Student (classId);
create index IX_6F1FABA on QC_Student (classId, classNo);
create index IX_446FF722 on QC_Student (classes);
create index IX_EC9275F6 on QC_Student (groupId);
create index IX_26990E00 on QC_Student (uuid_);
create index IX_844C3628 on QC_Student (uuid_, companyId);
create unique index IX_DC3C26AA on QC_Student (uuid_, groupId);

create index IX_965DDD85 on QC_StudentClass (classCode);
create index IX_98323A49 on QC_StudentClass (formNo);
create index IX_D908D80C on QC_StudentClass (formNo, classCode);
create index IX_AABFCC3A on QC_StudentClass (groupId);
create index IX_61EF2544 on QC_StudentClass (uuid_);
create index IX_F841AC64 on QC_StudentClass (uuid_, companyId);
create unique index IX_7E51FBE6 on QC_StudentClass (uuid_, groupId);

create index IX_96C05652 on qc_AbsenceCode (assignedCode);
create index IX_41313887 on qc_AbsenceCode (groupId);
create index IX_F27940D1 on qc_AbsenceCode (uuid_);
create index IX_86C0C6B7 on qc_AbsenceCode (uuid_, companyId);
create unique index IX_34698EF9 on qc_AbsenceCode (uuid_, groupId);

create index IX_CD462925 on qc_AbsenceEvent (absenceCodeId);
create index IX_914B562B on qc_AbsenceEvent (absenceDate);
create index IX_C89419DA on qc_AbsenceEvent (groupId);
create index IX_65165416 on qc_AbsenceEvent (studentId);
create index IX_45BA5AE4 on qc_AbsenceEvent (uuid_);
create index IX_EDDAB2C4 on qc_AbsenceEvent (uuid_, companyId);
create unique index IX_91391A46 on qc_AbsenceEvent (uuid_, groupId);

create index IX_8FD5A0BF on qc_DisciplineCode (assignedCode);
create index IX_9E085DFA on qc_DisciplineCode (groupId);
create index IX_9CF4A361 on qc_DisciplineCode (severity);
create index IX_3DB12704 on qc_DisciplineCode (uuid_);
create index IX_62112A4 on qc_DisciplineCode (uuid_, companyId);
create unique index IX_3D55F226 on qc_DisciplineCode (uuid_, groupId);

create index IX_E7B0C0EF on qc_DisciplineEvent (disciplineCodeId);
create index IX_B55501F5 on qc_DisciplineEvent (eventDate);
create index IX_6A1A2C7 on qc_DisciplineEvent (groupId);
create index IX_9CC1369E on qc_DisciplineEvent (penaltyCodeId);
create index IX_55E555C3 on qc_DisciplineEvent (studentId);
create index IX_43F9B8AF on qc_DisciplineEvent (teacher);
create index IX_617F3B11 on qc_DisciplineEvent (uuid_);
create index IX_5A83E477 on qc_DisciplineEvent (uuid_, companyId);
create unique index IX_A5D91CB9 on qc_DisciplineEvent (uuid_, groupId);

create index IX_C985EE9E on qc_PenaltyCode (assignedCode);
create index IX_FD88A0BB on qc_PenaltyCode (groupId);
create index IX_AE352605 on qc_PenaltyCode (uuid_);
create index IX_31295903 on qc_PenaltyCode (uuid_, companyId);
create unique index IX_CC2A4445 on qc_PenaltyCode (uuid_, groupId);

create index IX_CBBC806F on qc_Student (classId);
create index IX_4683FEBA on qc_Student (classId, classNo);
create index IX_73EBF1F6 on qc_Student (groupId);
create index IX_6E218A00 on qc_Student (uuid_);
create index IX_C3DE3A28 on qc_Student (uuid_, companyId);
create unique index IX_207F2AAA on qc_Student (uuid_, groupId);

create index IX_DAA0E185 on qc_StudentClass (classCode);
create index IX_6BF3D03A on qc_StudentClass (groupId);
create index IX_28542944 on qc_StudentClass (uuid_);
create index IX_77522864 on qc_StudentClass (uuid_, companyId);
create unique index IX_3F5177E6 on qc_StudentClass (uuid_, groupId);