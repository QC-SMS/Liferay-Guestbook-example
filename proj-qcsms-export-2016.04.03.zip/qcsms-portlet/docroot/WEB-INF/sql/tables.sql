create table QC_AbsenceCode (
	uuid_ VARCHAR(75) null,
	absenceCodeId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	assignedCode VARCHAR(75) null,
	description VARCHAR(75) null
);

create table QC_AbsenceEvent (
	uuid_ VARCHAR(75) null,
	absenceEventId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	studentId LONG,
	absenceCodeId LONG,
	absenceDescription VARCHAR(75) null,
	absenceDate DATE null,
	wholeDayInd VARCHAR(75) null
);

create table QC_DisciplineCode (
	uuid_ VARCHAR(75) null,
	disciplineCodeId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	assignedCode VARCHAR(75) null,
	description VARCHAR(75) null,
	severity VARCHAR(75) null
);

create table QC_DisciplineEvent (
	uuid_ VARCHAR(75) null,
	disciplineEventId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	studentId LONG,
	disciplineCodeId LONG,
	remarks VARCHAR(75) null,
	eventDate DATE null,
	teacher VARCHAR(75) null,
	penaltyCodeId LONG
);

create table QC_PenaltyCode (
	uuid_ VARCHAR(75) null,
	penaltyCodeId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	assignedCode VARCHAR(75) null,
	description VARCHAR(75) null
);

create table QC_PenaltyEvent (
	uuid_ VARCHAR(75) null,
	penaltyEventId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	studentId LONG,
	disciplineEventId LONG,
	penaltyCodeId LONG,
	eventDescription VARCHAR(75) null,
	remarks VARCHAR(75) null,
	studentLearningLogInd VARCHAR(75) null,
	webSAMSInd VARCHAR(75) null,
	brightFutureCompletedInd VARCHAR(75) null,
	copyReturnedInd VARCHAR(75) null,
	eventDate DATE null
);

create table QC_Student (
	uuid_ VARCHAR(75) null,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	studentId LONG not null primary key,
	classId LONG,
	studentName VARCHAR(75) null,
	classNo INTEGER
);

create table QC_StudentClass (
	uuid_ VARCHAR(75) null,
	classId LONG not null primary key,
	classCode VARCHAR(75) null,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null
);

create table qc_AbsenceCode (
	uuid_ VARCHAR(75) null,
	absenceCodeId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	assignedCode VARCHAR(75) null,
	description VARCHAR(75) null
);

create table qc_AbsenceEvent (
	uuid_ VARCHAR(75) null,
	absenceEventId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	studentId LONG,
	absenceCodeId LONG,
	absenceDescription VARCHAR(75) null,
	absenceDate DATE null,
	wholeDayInd VARCHAR(75) null
);

create table qc_DisciplineCode (
	uuid_ VARCHAR(75) null,
	disciplineCodeId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	assignedCode VARCHAR(75) null,
	description VARCHAR(75) null,
	severity VARCHAR(75) null
);

create table qc_DisciplineEvent (
	uuid_ VARCHAR(75) null,
	disciplineEventId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	studentId LONG,
	disciplineCodeId LONG,
	remarks VARCHAR(75) null,
	eventDate DATE null,
	penaltyCodeId LONG
);

create table qc_PenaltyCode (
	uuid_ VARCHAR(75) null,
	penaltyCodeId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	assignedCode VARCHAR(75) null,
	description VARCHAR(75) null
);

create table qc_Student (
	uuid_ VARCHAR(75) null,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	studentId LONG not null primary key,
	classId LONG,
	studentName VARCHAR(75) null,
	classNo INTEGER
);

create table qc_StudentClass (
	uuid_ VARCHAR(75) null,
	classId LONG not null primary key,
	classCode VARCHAR(75) null,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null
);