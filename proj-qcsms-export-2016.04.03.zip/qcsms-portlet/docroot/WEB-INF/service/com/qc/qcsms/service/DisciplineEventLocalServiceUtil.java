/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for DisciplineEvent. This utility wraps
 * {@link com.qc.qcsms.service.impl.DisciplineEventLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author teddyku
 * @see DisciplineEventLocalService
 * @see com.qc.qcsms.service.base.DisciplineEventLocalServiceBaseImpl
 * @see com.qc.qcsms.service.impl.DisciplineEventLocalServiceImpl
 * @generated
 */
public class DisciplineEventLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.qc.qcsms.service.impl.DisciplineEventLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the discipline event to the database. Also notifies the appropriate model listeners.
	*
	* @param disciplineEvent the discipline event
	* @return the discipline event that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent addDisciplineEvent(
		com.qc.qcsms.model.DisciplineEvent disciplineEvent)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addDisciplineEvent(disciplineEvent);
	}

	/**
	* Creates a new discipline event with the primary key. Does not add the discipline event to the database.
	*
	* @param disciplineEventId the primary key for the new discipline event
	* @return the new discipline event
	*/
	public static com.qc.qcsms.model.DisciplineEvent createDisciplineEvent(
		long disciplineEventId) {
		return getService().createDisciplineEvent(disciplineEventId);
	}

	/**
	* Deletes the discipline event with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param disciplineEventId the primary key of the discipline event
	* @return the discipline event that was removed
	* @throws PortalException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent deleteDisciplineEvent(
		long disciplineEventId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteDisciplineEvent(disciplineEventId);
	}

	/**
	* Deletes the discipline event from the database. Also notifies the appropriate model listeners.
	*
	* @param disciplineEvent the discipline event
	* @return the discipline event that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent deleteDisciplineEvent(
		com.qc.qcsms.model.DisciplineEvent disciplineEvent)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteDisciplineEvent(disciplineEvent);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.qc.qcsms.model.DisciplineEvent fetchDisciplineEvent(
		long disciplineEventId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchDisciplineEvent(disciplineEventId);
	}

	/**
	* Returns the discipline event with the matching UUID and company.
	*
	* @param uuid the discipline event's UUID
	* @param companyId the primary key of the company
	* @return the matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchDisciplineEventByUuidAndCompanyId(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .fetchDisciplineEventByUuidAndCompanyId(uuid, companyId);
	}

	/**
	* Returns the discipline event matching the UUID and group.
	*
	* @param uuid the discipline event's UUID
	* @param groupId the primary key of the group
	* @return the matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchDisciplineEventByUuidAndGroupId(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchDisciplineEventByUuidAndGroupId(uuid, groupId);
	}

	/**
	* Returns the discipline event with the primary key.
	*
	* @param disciplineEventId the primary key of the discipline event
	* @return the discipline event
	* @throws PortalException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent getDisciplineEvent(
		long disciplineEventId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getDisciplineEvent(disciplineEventId);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns the discipline event with the matching UUID and company.
	*
	* @param uuid the discipline event's UUID
	* @param companyId the primary key of the company
	* @return the matching discipline event
	* @throws PortalException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent getDisciplineEventByUuidAndCompanyId(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getDisciplineEventByUuidAndCompanyId(uuid, companyId);
	}

	/**
	* Returns the discipline event matching the UUID and group.
	*
	* @param uuid the discipline event's UUID
	* @param groupId the primary key of the group
	* @return the matching discipline event
	* @throws PortalException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent getDisciplineEventByUuidAndGroupId(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getDisciplineEventByUuidAndGroupId(uuid, groupId);
	}

	/**
	* Returns a range of all the discipline events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @return the range of discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> getDisciplineEvents(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getDisciplineEvents(start, end);
	}

	/**
	* Returns the number of discipline events.
	*
	* @return the number of discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static int getDisciplineEventsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getDisciplineEventsCount();
	}

	/**
	* Updates the discipline event in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param disciplineEvent the discipline event
	* @return the discipline event that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent updateDisciplineEvent(
		com.qc.qcsms.model.DisciplineEvent disciplineEvent)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateDisciplineEvent(disciplineEvent);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> getDisciplineEvents(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getDisciplineEvents(groupId);
	}

	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> getDisciplineEvents(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getDisciplineEvents(groupId, start, end);
	}

	public static com.qc.qcsms.model.DisciplineEvent addDisciplineEvent(
		long userId, long studentId, long disciplineCodeId,
		java.util.Date eventDate, java.lang.String remarks, long penaltyCodeId,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .addDisciplineEvent(userId, studentId, disciplineCodeId,
			eventDate, remarks, penaltyCodeId, serviceContext);
	}

	public static com.qc.qcsms.model.DisciplineEvent updateDisciplineEvent(
		long userId, long disciplineEventId, long studentId,
		long disciplineCodeId, java.util.Date eventDate,
		java.lang.String remarks, long penaltyCodeId,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .updateDisciplineEvent(userId, disciplineEventId, studentId,
			disciplineCodeId, eventDate, remarks, penaltyCodeId, serviceContext);
	}

	public static com.qc.qcsms.model.DisciplineEvent deleteDisciplineEvent(
		long disciplineEventId,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .deleteDisciplineEvent(disciplineEventId, serviceContext);
	}

	public static int getDisciplineEventCount(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getDisciplineEventCount(groupId);
	}

	public static java.util.List getSearchDisciplineEvents(long studentId,
		long disciplineCodeId, java.util.Date fromEventDate,
		java.util.Date toEventDate, java.lang.String remarks,
		long penaltyCodeId, long userId, boolean andSearch, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .getSearchDisciplineEvents(studentId, disciplineCodeId,
			fromEventDate, toEventDate, remarks, penaltyCodeId, userId,
			andSearch, start, end, orderByComparator);
	}

	public static int getSearchDisciplineEventCount(long studentId,
		long disciplineCodeId, java.util.Date fromEventDate,
		java.util.Date toEventDate, java.lang.String remarks,
		long penaltyCodeId, long userId, boolean andSearch)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .getSearchDisciplineEventCount(studentId, disciplineCodeId,
			fromEventDate, toEventDate, remarks, penaltyCodeId, userId,
			andSearch);
	}

	public static java.lang.String getSelectOptionDescription(
		com.qc.qcsms.model.DisciplineEvent disciplineEvent)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getSelectOptionDescription(disciplineEvent);
	}

	public static void clearService() {
		_service = null;
	}

	public static DisciplineEventLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					DisciplineEventLocalService.class.getName());

			if (invokableLocalService instanceof DisciplineEventLocalService) {
				_service = (DisciplineEventLocalService)invokableLocalService;
			}
			else {
				_service = new DisciplineEventLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(DisciplineEventLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(DisciplineEventLocalService service) {
	}

	private static DisciplineEventLocalService _service;
}