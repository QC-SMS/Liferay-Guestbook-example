/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.qc.qcsms.model.PenaltyEvent;

/**
 * The persistence interface for the penalty event service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see PenaltyEventPersistenceImpl
 * @see PenaltyEventUtil
 * @generated
 */
public interface PenaltyEventPersistence extends BasePersistence<PenaltyEvent> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link PenaltyEventUtil} to access the penalty event persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the penalty events where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the penalty events where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the penalty events where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first penalty event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the first penalty event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last penalty event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the last penalty event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where uuid = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent[] findByUuid_PrevAndNext(
		long penaltyEventId, java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Removes all the penalty events where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of penalty events where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty event where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchPenaltyEventException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByUUID_G(java.lang.String uuid,
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the penalty event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByUUID_G(
		java.lang.String uuid, long groupId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the penalty event where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the penalty event that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent removeByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the number of penalty events where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public int countByUUID_G(java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the penalty events where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid_C(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the penalty events where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the penalty events where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the first penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the last penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent[] findByUuid_C_PrevAndNext(
		long penaltyEventId, java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Removes all the penalty events where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of penalty events where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public int countByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the penalty events where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the penalty events where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the penalty events where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first penalty event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByGroupId_First(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the first penalty event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByGroupId_First(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last penalty event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByGroupId_Last(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the last penalty event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByGroupId_Last(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where groupId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent[] findByGroupId_PrevAndNext(
		long penaltyEventId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns all the penalty events that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching penalty events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> filterFindByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the penalty events that the user has permission to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> filterFindByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the penalty events that the user has permissions to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> filterFindByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set of penalty events that the user has permission to view where groupId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent[] filterFindByGroupId_PrevAndNext(
		long penaltyEventId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Removes all the penalty events where groupId = &#63; from the database.
	*
	* @param groupId the group ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of penalty events where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public int countByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of penalty events that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching penalty events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public int filterCountByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the penalty events where studentId = &#63;.
	*
	* @param studentId the student ID
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByStudentId(
		long studentId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the penalty events where studentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param studentId the student ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByStudentId(
		long studentId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the penalty events where studentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param studentId the student ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByStudentId(
		long studentId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first penalty event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByStudentId_First(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the first penalty event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByStudentId_First(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last penalty event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByStudentId_Last(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the last penalty event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByStudentId_Last(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where studentId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent[] findByStudentId_PrevAndNext(
		long penaltyEventId, long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Removes all the penalty events where studentId = &#63; from the database.
	*
	* @param studentId the student ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByStudentId(long studentId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of penalty events where studentId = &#63;.
	*
	* @param studentId the student ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public int countByStudentId(long studentId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the penalty events where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByPenaltyCodeId(
		long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the penalty events where penaltyCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param penaltyCodeId the penalty code ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByPenaltyCodeId(
		long penaltyCodeId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the penalty events where penaltyCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param penaltyCodeId the penalty code ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByPenaltyCodeId(
		long penaltyCodeId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first penalty event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByPenaltyCodeId_First(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the first penalty event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByPenaltyCodeId_First(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last penalty event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByPenaltyCodeId_Last(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the last penalty event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByPenaltyCodeId_Last(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent[] findByPenaltyCodeId_PrevAndNext(
		long penaltyEventId, long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Removes all the penalty events where penaltyCodeId = &#63; from the database.
	*
	* @param penaltyCodeId the penalty code ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByPenaltyCodeId(long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of penalty events where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public int countByPenaltyCodeId(long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the penalty events where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByDisciplineEventId(
		long disciplineEventId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the penalty events where disciplineEventId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param disciplineEventId the discipline event ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByDisciplineEventId(
		long disciplineEventId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the penalty events where disciplineEventId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param disciplineEventId the discipline event ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByDisciplineEventId(
		long disciplineEventId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first penalty event in the ordered set where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByDisciplineEventId_First(
		long disciplineEventId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the first penalty event in the ordered set where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByDisciplineEventId_First(
		long disciplineEventId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last penalty event in the ordered set where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByDisciplineEventId_Last(
		long disciplineEventId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the last penalty event in the ordered set where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByDisciplineEventId_Last(
		long disciplineEventId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where disciplineEventId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param disciplineEventId the discipline event ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent[] findByDisciplineEventId_PrevAndNext(
		long penaltyEventId, long disciplineEventId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Removes all the penalty events where disciplineEventId = &#63; from the database.
	*
	* @param disciplineEventId the discipline event ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByDisciplineEventId(long disciplineEventId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of penalty events where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public int countByDisciplineEventId(long disciplineEventId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the penalty events where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByEventDate(
		java.util.Date eventDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the penalty events where eventDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param eventDate the event date
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByEventDate(
		java.util.Date eventDate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the penalty events where eventDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param eventDate the event date
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findByEventDate(
		java.util.Date eventDate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first penalty event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByEventDate_First(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the first penalty event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByEventDate_First(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last penalty event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByEventDate_Last(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the last penalty event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByEventDate_Last(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where eventDate = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent[] findByEventDate_PrevAndNext(
		long penaltyEventId, java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Removes all the penalty events where eventDate = &#63; from the database.
	*
	* @param eventDate the event date
	* @throws SystemException if a system exception occurred
	*/
	public void removeByEventDate(java.util.Date eventDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of penalty events where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public int countByEventDate(java.util.Date eventDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the penalty event in the entity cache if it is enabled.
	*
	* @param penaltyEvent the penalty event
	*/
	public void cacheResult(com.qc.qcsms.model.PenaltyEvent penaltyEvent);

	/**
	* Caches the penalty events in the entity cache if it is enabled.
	*
	* @param penaltyEvents the penalty events
	*/
	public void cacheResult(
		java.util.List<com.qc.qcsms.model.PenaltyEvent> penaltyEvents);

	/**
	* Creates a new penalty event with the primary key. Does not add the penalty event to the database.
	*
	* @param penaltyEventId the primary key for the new penalty event
	* @return the new penalty event
	*/
	public com.qc.qcsms.model.PenaltyEvent create(long penaltyEventId);

	/**
	* Removes the penalty event with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param penaltyEventId the primary key of the penalty event
	* @return the penalty event that was removed
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent remove(long penaltyEventId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	public com.qc.qcsms.model.PenaltyEvent updateImpl(
		com.qc.qcsms.model.PenaltyEvent penaltyEvent)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the penalty event with the primary key or throws a {@link com.qc.qcsms.NoSuchPenaltyEventException} if it could not be found.
	*
	* @param penaltyEventId the primary key of the penalty event
	* @return the penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent findByPrimaryKey(long penaltyEventId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException;

	/**
	* Returns the penalty event with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param penaltyEventId the primary key of the penalty event
	* @return the penalty event, or <code>null</code> if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.PenaltyEvent fetchByPrimaryKey(
		long penaltyEventId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the penalty events.
	*
	* @return the penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the penalty events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findAll(int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the penalty events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of penalty events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.PenaltyEvent> findAll(int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the penalty events from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of penalty events.
	*
	* @return the number of penalty events
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}