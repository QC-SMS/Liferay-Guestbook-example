/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link AbsenceCode}.
 * </p>
 *
 * @author teddyku
 * @see AbsenceCode
 * @generated
 */
public class AbsenceCodeWrapper implements AbsenceCode,
	ModelWrapper<AbsenceCode> {
	public AbsenceCodeWrapper(AbsenceCode absenceCode) {
		_absenceCode = absenceCode;
	}

	@Override
	public Class<?> getModelClass() {
		return AbsenceCode.class;
	}

	@Override
	public String getModelClassName() {
		return AbsenceCode.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("absenceCodeId", getAbsenceCodeId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("assignedCode", getAssignedCode());
		attributes.put("description", getDescription());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long absenceCodeId = (Long)attributes.get("absenceCodeId");

		if (absenceCodeId != null) {
			setAbsenceCodeId(absenceCodeId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String assignedCode = (String)attributes.get("assignedCode");

		if (assignedCode != null) {
			setAssignedCode(assignedCode);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}
	}

	/**
	* Returns the primary key of this absence code.
	*
	* @return the primary key of this absence code
	*/
	@Override
	public long getPrimaryKey() {
		return _absenceCode.getPrimaryKey();
	}

	/**
	* Sets the primary key of this absence code.
	*
	* @param primaryKey the primary key of this absence code
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_absenceCode.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this absence code.
	*
	* @return the uuid of this absence code
	*/
	@Override
	public java.lang.String getUuid() {
		return _absenceCode.getUuid();
	}

	/**
	* Sets the uuid of this absence code.
	*
	* @param uuid the uuid of this absence code
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_absenceCode.setUuid(uuid);
	}

	/**
	* Returns the absence code ID of this absence code.
	*
	* @return the absence code ID of this absence code
	*/
	@Override
	public long getAbsenceCodeId() {
		return _absenceCode.getAbsenceCodeId();
	}

	/**
	* Sets the absence code ID of this absence code.
	*
	* @param absenceCodeId the absence code ID of this absence code
	*/
	@Override
	public void setAbsenceCodeId(long absenceCodeId) {
		_absenceCode.setAbsenceCodeId(absenceCodeId);
	}

	/**
	* Returns the group ID of this absence code.
	*
	* @return the group ID of this absence code
	*/
	@Override
	public long getGroupId() {
		return _absenceCode.getGroupId();
	}

	/**
	* Sets the group ID of this absence code.
	*
	* @param groupId the group ID of this absence code
	*/
	@Override
	public void setGroupId(long groupId) {
		_absenceCode.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this absence code.
	*
	* @return the company ID of this absence code
	*/
	@Override
	public long getCompanyId() {
		return _absenceCode.getCompanyId();
	}

	/**
	* Sets the company ID of this absence code.
	*
	* @param companyId the company ID of this absence code
	*/
	@Override
	public void setCompanyId(long companyId) {
		_absenceCode.setCompanyId(companyId);
	}

	/**
	* Returns the user ID of this absence code.
	*
	* @return the user ID of this absence code
	*/
	@Override
	public long getUserId() {
		return _absenceCode.getUserId();
	}

	/**
	* Sets the user ID of this absence code.
	*
	* @param userId the user ID of this absence code
	*/
	@Override
	public void setUserId(long userId) {
		_absenceCode.setUserId(userId);
	}

	/**
	* Returns the user uuid of this absence code.
	*
	* @return the user uuid of this absence code
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _absenceCode.getUserUuid();
	}

	/**
	* Sets the user uuid of this absence code.
	*
	* @param userUuid the user uuid of this absence code
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_absenceCode.setUserUuid(userUuid);
	}

	/**
	* Returns the user name of this absence code.
	*
	* @return the user name of this absence code
	*/
	@Override
	public java.lang.String getUserName() {
		return _absenceCode.getUserName();
	}

	/**
	* Sets the user name of this absence code.
	*
	* @param userName the user name of this absence code
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_absenceCode.setUserName(userName);
	}

	/**
	* Returns the create date of this absence code.
	*
	* @return the create date of this absence code
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _absenceCode.getCreateDate();
	}

	/**
	* Sets the create date of this absence code.
	*
	* @param createDate the create date of this absence code
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_absenceCode.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this absence code.
	*
	* @return the modified date of this absence code
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _absenceCode.getModifiedDate();
	}

	/**
	* Sets the modified date of this absence code.
	*
	* @param modifiedDate the modified date of this absence code
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_absenceCode.setModifiedDate(modifiedDate);
	}

	/**
	* Returns the assigned code of this absence code.
	*
	* @return the assigned code of this absence code
	*/
	@Override
	public java.lang.String getAssignedCode() {
		return _absenceCode.getAssignedCode();
	}

	/**
	* Sets the assigned code of this absence code.
	*
	* @param assignedCode the assigned code of this absence code
	*/
	@Override
	public void setAssignedCode(java.lang.String assignedCode) {
		_absenceCode.setAssignedCode(assignedCode);
	}

	/**
	* Returns the description of this absence code.
	*
	* @return the description of this absence code
	*/
	@Override
	public java.lang.String getDescription() {
		return _absenceCode.getDescription();
	}

	/**
	* Sets the description of this absence code.
	*
	* @param description the description of this absence code
	*/
	@Override
	public void setDescription(java.lang.String description) {
		_absenceCode.setDescription(description);
	}

	@Override
	public boolean isNew() {
		return _absenceCode.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_absenceCode.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _absenceCode.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_absenceCode.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _absenceCode.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _absenceCode.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_absenceCode.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _absenceCode.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_absenceCode.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_absenceCode.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_absenceCode.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new AbsenceCodeWrapper((AbsenceCode)_absenceCode.clone());
	}

	@Override
	public int compareTo(com.qc.qcsms.model.AbsenceCode absenceCode) {
		return _absenceCode.compareTo(absenceCode);
	}

	@Override
	public int hashCode() {
		return _absenceCode.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.qc.qcsms.model.AbsenceCode> toCacheModel() {
		return _absenceCode.toCacheModel();
	}

	@Override
	public com.qc.qcsms.model.AbsenceCode toEscapedModel() {
		return new AbsenceCodeWrapper(_absenceCode.toEscapedModel());
	}

	@Override
	public com.qc.qcsms.model.AbsenceCode toUnescapedModel() {
		return new AbsenceCodeWrapper(_absenceCode.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _absenceCode.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _absenceCode.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_absenceCode.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof AbsenceCodeWrapper)) {
			return false;
		}

		AbsenceCodeWrapper absenceCodeWrapper = (AbsenceCodeWrapper)obj;

		if (Validator.equals(_absenceCode, absenceCodeWrapper._absenceCode)) {
			return true;
		}

		return false;
	}

	@Override
	public StagedModelType getStagedModelType() {
		return _absenceCode.getStagedModelType();
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public AbsenceCode getWrappedAbsenceCode() {
		return _absenceCode;
	}

	@Override
	public AbsenceCode getWrappedModel() {
		return _absenceCode;
	}

	@Override
	public void resetOriginalValues() {
		_absenceCode.resetOriginalValues();
	}

	private AbsenceCode _absenceCode;
}