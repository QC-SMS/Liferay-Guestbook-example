/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import com.qc.qcsms.service.ClpSerializer;
import com.qc.qcsms.service.PenaltyEventLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author teddyku
 */
public class PenaltyEventClp extends BaseModelImpl<PenaltyEvent>
	implements PenaltyEvent {
	public PenaltyEventClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return PenaltyEvent.class;
	}

	@Override
	public String getModelClassName() {
		return PenaltyEvent.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _penaltyEventId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setPenaltyEventId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _penaltyEventId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("penaltyEventId", getPenaltyEventId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("studentId", getStudentId());
		attributes.put("disciplineEventId", getDisciplineEventId());
		attributes.put("penaltyCodeId", getPenaltyCodeId());
		attributes.put("eventDescription", getEventDescription());
		attributes.put("remarks", getRemarks());
		attributes.put("studentLearningLogInd", getStudentLearningLogInd());
		attributes.put("webSAMSInd", getWebSAMSInd());
		attributes.put("brightFutureCompletedInd", getBrightFutureCompletedInd());
		attributes.put("copyReturnedInd", getCopyReturnedInd());
		attributes.put("eventDate", getEventDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long penaltyEventId = (Long)attributes.get("penaltyEventId");

		if (penaltyEventId != null) {
			setPenaltyEventId(penaltyEventId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		Long studentId = (Long)attributes.get("studentId");

		if (studentId != null) {
			setStudentId(studentId);
		}

		Long disciplineEventId = (Long)attributes.get("disciplineEventId");

		if (disciplineEventId != null) {
			setDisciplineEventId(disciplineEventId);
		}

		Long penaltyCodeId = (Long)attributes.get("penaltyCodeId");

		if (penaltyCodeId != null) {
			setPenaltyCodeId(penaltyCodeId);
		}

		String eventDescription = (String)attributes.get("eventDescription");

		if (eventDescription != null) {
			setEventDescription(eventDescription);
		}

		String remarks = (String)attributes.get("remarks");

		if (remarks != null) {
			setRemarks(remarks);
		}

		String studentLearningLogInd = (String)attributes.get(
				"studentLearningLogInd");

		if (studentLearningLogInd != null) {
			setStudentLearningLogInd(studentLearningLogInd);
		}

		String webSAMSInd = (String)attributes.get("webSAMSInd");

		if (webSAMSInd != null) {
			setWebSAMSInd(webSAMSInd);
		}

		String brightFutureCompletedInd = (String)attributes.get(
				"brightFutureCompletedInd");

		if (brightFutureCompletedInd != null) {
			setBrightFutureCompletedInd(brightFutureCompletedInd);
		}

		String copyReturnedInd = (String)attributes.get("copyReturnedInd");

		if (copyReturnedInd != null) {
			setCopyReturnedInd(copyReturnedInd);
		}

		Date eventDate = (Date)attributes.get("eventDate");

		if (eventDate != null) {
			setEventDate(eventDate);
		}
	}

	@Override
	public String getUuid() {
		return _uuid;
	}

	@Override
	public void setUuid(String uuid) {
		_uuid = uuid;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setUuid", String.class);

				method.invoke(_penaltyEventRemoteModel, uuid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getPenaltyEventId() {
		return _penaltyEventId;
	}

	@Override
	public void setPenaltyEventId(long penaltyEventId) {
		_penaltyEventId = penaltyEventId;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setPenaltyEventId", long.class);

				method.invoke(_penaltyEventRemoteModel, penaltyEventId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getGroupId() {
		return _groupId;
	}

	@Override
	public void setGroupId(long groupId) {
		_groupId = groupId;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setGroupId", long.class);

				method.invoke(_penaltyEventRemoteModel, groupId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCompanyId() {
		return _companyId;
	}

	@Override
	public void setCompanyId(long companyId) {
		_companyId = companyId;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyId", long.class);

				method.invoke(_penaltyEventRemoteModel, companyId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserId() {
		return _userId;
	}

	@Override
	public void setUserId(long userId) {
		_userId = userId;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setUserId", long.class);

				method.invoke(_penaltyEventRemoteModel, userId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
	}

	@Override
	public void setUserUuid(String userUuid) {
		_userUuid = userUuid;
	}

	@Override
	public String getUserName() {
		return _userName;
	}

	@Override
	public void setUserName(String userName) {
		_userName = userName;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setUserName", String.class);

				method.invoke(_penaltyEventRemoteModel, userName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCreateDate() {
		return _createDate;
	}

	@Override
	public void setCreateDate(Date createDate) {
		_createDate = createDate;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setCreateDate", Date.class);

				method.invoke(_penaltyEventRemoteModel, createDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getModifiedDate() {
		return _modifiedDate;
	}

	@Override
	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setModifiedDate", Date.class);

				method.invoke(_penaltyEventRemoteModel, modifiedDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getStudentId() {
		return _studentId;
	}

	@Override
	public void setStudentId(long studentId) {
		_studentId = studentId;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setStudentId", long.class);

				method.invoke(_penaltyEventRemoteModel, studentId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getDisciplineEventId() {
		return _disciplineEventId;
	}

	@Override
	public void setDisciplineEventId(long disciplineEventId) {
		_disciplineEventId = disciplineEventId;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setDisciplineEventId",
						long.class);

				method.invoke(_penaltyEventRemoteModel, disciplineEventId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getPenaltyCodeId() {
		return _penaltyCodeId;
	}

	@Override
	public void setPenaltyCodeId(long penaltyCodeId) {
		_penaltyCodeId = penaltyCodeId;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setPenaltyCodeId", long.class);

				method.invoke(_penaltyEventRemoteModel, penaltyCodeId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEventDescription() {
		return _eventDescription;
	}

	@Override
	public void setEventDescription(String eventDescription) {
		_eventDescription = eventDescription;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setEventDescription",
						String.class);

				method.invoke(_penaltyEventRemoteModel, eventDescription);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRemarks() {
		return _remarks;
	}

	@Override
	public void setRemarks(String remarks) {
		_remarks = remarks;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setRemarks", String.class);

				method.invoke(_penaltyEventRemoteModel, remarks);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStudentLearningLogInd() {
		return _studentLearningLogInd;
	}

	@Override
	public void setStudentLearningLogInd(String studentLearningLogInd) {
		_studentLearningLogInd = studentLearningLogInd;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setStudentLearningLogInd",
						String.class);

				method.invoke(_penaltyEventRemoteModel, studentLearningLogInd);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getWebSAMSInd() {
		return _webSAMSInd;
	}

	@Override
	public void setWebSAMSInd(String webSAMSInd) {
		_webSAMSInd = webSAMSInd;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setWebSAMSInd", String.class);

				method.invoke(_penaltyEventRemoteModel, webSAMSInd);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getBrightFutureCompletedInd() {
		return _brightFutureCompletedInd;
	}

	@Override
	public void setBrightFutureCompletedInd(String brightFutureCompletedInd) {
		_brightFutureCompletedInd = brightFutureCompletedInd;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setBrightFutureCompletedInd",
						String.class);

				method.invoke(_penaltyEventRemoteModel, brightFutureCompletedInd);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCopyReturnedInd() {
		return _copyReturnedInd;
	}

	@Override
	public void setCopyReturnedInd(String copyReturnedInd) {
		_copyReturnedInd = copyReturnedInd;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setCopyReturnedInd",
						String.class);

				method.invoke(_penaltyEventRemoteModel, copyReturnedInd);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getEventDate() {
		return _eventDate;
	}

	@Override
	public void setEventDate(Date eventDate) {
		_eventDate = eventDate;

		if (_penaltyEventRemoteModel != null) {
			try {
				Class<?> clazz = _penaltyEventRemoteModel.getClass();

				Method method = clazz.getMethod("setEventDate", Date.class);

				method.invoke(_penaltyEventRemoteModel, eventDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public StagedModelType getStagedModelType() {
		return new StagedModelType(PortalUtil.getClassNameId(
				PenaltyEvent.class.getName()));
	}

	public BaseModel<?> getPenaltyEventRemoteModel() {
		return _penaltyEventRemoteModel;
	}

	public void setPenaltyEventRemoteModel(BaseModel<?> penaltyEventRemoteModel) {
		_penaltyEventRemoteModel = penaltyEventRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _penaltyEventRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_penaltyEventRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			PenaltyEventLocalServiceUtil.addPenaltyEvent(this);
		}
		else {
			PenaltyEventLocalServiceUtil.updatePenaltyEvent(this);
		}
	}

	@Override
	public PenaltyEvent toEscapedModel() {
		return (PenaltyEvent)ProxyUtil.newProxyInstance(PenaltyEvent.class.getClassLoader(),
			new Class[] { PenaltyEvent.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		PenaltyEventClp clone = new PenaltyEventClp();

		clone.setUuid(getUuid());
		clone.setPenaltyEventId(getPenaltyEventId());
		clone.setGroupId(getGroupId());
		clone.setCompanyId(getCompanyId());
		clone.setUserId(getUserId());
		clone.setUserName(getUserName());
		clone.setCreateDate(getCreateDate());
		clone.setModifiedDate(getModifiedDate());
		clone.setStudentId(getStudentId());
		clone.setDisciplineEventId(getDisciplineEventId());
		clone.setPenaltyCodeId(getPenaltyCodeId());
		clone.setEventDescription(getEventDescription());
		clone.setRemarks(getRemarks());
		clone.setStudentLearningLogInd(getStudentLearningLogInd());
		clone.setWebSAMSInd(getWebSAMSInd());
		clone.setBrightFutureCompletedInd(getBrightFutureCompletedInd());
		clone.setCopyReturnedInd(getCopyReturnedInd());
		clone.setEventDate(getEventDate());

		return clone;
	}

	@Override
	public int compareTo(PenaltyEvent penaltyEvent) {
		int value = 0;

		value = DateUtil.compareTo(getEventDate(), penaltyEvent.getEventDate());

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof PenaltyEventClp)) {
			return false;
		}

		PenaltyEventClp penaltyEvent = (PenaltyEventClp)obj;

		long primaryKey = penaltyEvent.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(37);

		sb.append("{uuid=");
		sb.append(getUuid());
		sb.append(", penaltyEventId=");
		sb.append(getPenaltyEventId());
		sb.append(", groupId=");
		sb.append(getGroupId());
		sb.append(", companyId=");
		sb.append(getCompanyId());
		sb.append(", userId=");
		sb.append(getUserId());
		sb.append(", userName=");
		sb.append(getUserName());
		sb.append(", createDate=");
		sb.append(getCreateDate());
		sb.append(", modifiedDate=");
		sb.append(getModifiedDate());
		sb.append(", studentId=");
		sb.append(getStudentId());
		sb.append(", disciplineEventId=");
		sb.append(getDisciplineEventId());
		sb.append(", penaltyCodeId=");
		sb.append(getPenaltyCodeId());
		sb.append(", eventDescription=");
		sb.append(getEventDescription());
		sb.append(", remarks=");
		sb.append(getRemarks());
		sb.append(", studentLearningLogInd=");
		sb.append(getStudentLearningLogInd());
		sb.append(", webSAMSInd=");
		sb.append(getWebSAMSInd());
		sb.append(", brightFutureCompletedInd=");
		sb.append(getBrightFutureCompletedInd());
		sb.append(", copyReturnedInd=");
		sb.append(getCopyReturnedInd());
		sb.append(", eventDate=");
		sb.append(getEventDate());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(58);

		sb.append("<model><model-name>");
		sb.append("com.qc.qcsms.model.PenaltyEvent");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>uuid</column-name><column-value><![CDATA[");
		sb.append(getUuid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>penaltyEventId</column-name><column-value><![CDATA[");
		sb.append(getPenaltyEventId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>groupId</column-name><column-value><![CDATA[");
		sb.append(getGroupId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyId</column-name><column-value><![CDATA[");
		sb.append(getCompanyId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userId</column-name><column-value><![CDATA[");
		sb.append(getUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userName</column-name><column-value><![CDATA[");
		sb.append(getUserName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createDate</column-name><column-value><![CDATA[");
		sb.append(getCreateDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>modifiedDate</column-name><column-value><![CDATA[");
		sb.append(getModifiedDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>studentId</column-name><column-value><![CDATA[");
		sb.append(getStudentId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>disciplineEventId</column-name><column-value><![CDATA[");
		sb.append(getDisciplineEventId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>penaltyCodeId</column-name><column-value><![CDATA[");
		sb.append(getPenaltyCodeId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>eventDescription</column-name><column-value><![CDATA[");
		sb.append(getEventDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>remarks</column-name><column-value><![CDATA[");
		sb.append(getRemarks());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>studentLearningLogInd</column-name><column-value><![CDATA[");
		sb.append(getStudentLearningLogInd());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>webSAMSInd</column-name><column-value><![CDATA[");
		sb.append(getWebSAMSInd());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>brightFutureCompletedInd</column-name><column-value><![CDATA[");
		sb.append(getBrightFutureCompletedInd());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>copyReturnedInd</column-name><column-value><![CDATA[");
		sb.append(getCopyReturnedInd());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>eventDate</column-name><column-value><![CDATA[");
		sb.append(getEventDate());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private String _uuid;
	private long _penaltyEventId;
	private long _groupId;
	private long _companyId;
	private long _userId;
	private String _userUuid;
	private String _userName;
	private Date _createDate;
	private Date _modifiedDate;
	private long _studentId;
	private long _disciplineEventId;
	private long _penaltyCodeId;
	private String _eventDescription;
	private String _remarks;
	private String _studentLearningLogInd;
	private String _webSAMSInd;
	private String _brightFutureCompletedInd;
	private String _copyReturnedInd;
	private Date _eventDate;
	private BaseModel<?> _penaltyEventRemoteModel;
	private Class<?> _clpSerializerClass = com.qc.qcsms.service.ClpSerializer.class;
}