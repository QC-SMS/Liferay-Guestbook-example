/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.qc.qcsms.model.StudentClass;

/**
 * The persistence interface for the student class service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see StudentClassPersistenceImpl
 * @see StudentClassUtil
 * @generated
 */
public interface StudentClassPersistence extends BasePersistence<StudentClass> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link StudentClassUtil} to access the student class persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the student classes where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the student classes where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the student classes where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first student class in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass findByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the first student class in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last student class in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass findByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the last student class in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the student classes before and after the current student class in the ordered set where uuid = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass[] findByUuid_PrevAndNext(
		long classId, java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Removes all the student classes where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of student classes where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the student class where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchStudentClassException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass findByUUID_G(java.lang.String uuid,
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the student class where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the student class where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByUUID_G(
		java.lang.String uuid, long groupId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the student class where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the student class that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass removeByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the number of student classes where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public int countByUUID_G(java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the student classes where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByUuid_C(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the student classes where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the student classes where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first student class in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass findByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the first student class in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last student class in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass findByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the last student class in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the student classes before and after the current student class in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass[] findByUuid_C_PrevAndNext(
		long classId, java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Removes all the student classes where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of student classes where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public int countByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the student classes where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the student classes where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the student classes where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first student class in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass findByGroupId_First(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the first student class in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByGroupId_First(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last student class in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass findByGroupId_Last(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the last student class in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByGroupId_Last(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the student classes before and after the current student class in the ordered set where groupId = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass[] findByGroupId_PrevAndNext(
		long classId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns all the student classes that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching student classes that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> filterFindByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the student classes that the user has permission to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> filterFindByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the student classes that the user has permissions to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> filterFindByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the student classes before and after the current student class in the ordered set of student classes that the user has permission to view where groupId = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass[] filterFindByGroupId_PrevAndNext(
		long classId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Removes all the student classes where groupId = &#63; from the database.
	*
	* @param groupId the group ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of student classes where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public int countByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of student classes that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching student classes that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public int filterCountByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the student classes where classCode = &#63;.
	*
	* @param classCode the class code
	* @return the matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByClassCode(
		java.lang.String classCode)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the student classes where classCode = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param classCode the class code
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByClassCode(
		java.lang.String classCode, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the student classes where classCode = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param classCode the class code
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findByClassCode(
		java.lang.String classCode, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first student class in the ordered set where classCode = &#63;.
	*
	* @param classCode the class code
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass findByClassCode_First(
		java.lang.String classCode,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the first student class in the ordered set where classCode = &#63;.
	*
	* @param classCode the class code
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByClassCode_First(
		java.lang.String classCode,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last student class in the ordered set where classCode = &#63;.
	*
	* @param classCode the class code
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass findByClassCode_Last(
		java.lang.String classCode,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the last student class in the ordered set where classCode = &#63;.
	*
	* @param classCode the class code
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByClassCode_Last(
		java.lang.String classCode,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the student classes before and after the current student class in the ordered set where classCode = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param classCode the class code
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass[] findByClassCode_PrevAndNext(
		long classId, java.lang.String classCode,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Removes all the student classes where classCode = &#63; from the database.
	*
	* @param classCode the class code
	* @throws SystemException if a system exception occurred
	*/
	public void removeByClassCode(java.lang.String classCode)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of student classes where classCode = &#63;.
	*
	* @param classCode the class code
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public int countByClassCode(java.lang.String classCode)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the student class in the entity cache if it is enabled.
	*
	* @param studentClass the student class
	*/
	public void cacheResult(com.qc.qcsms.model.StudentClass studentClass);

	/**
	* Caches the student classes in the entity cache if it is enabled.
	*
	* @param studentClasses the student classes
	*/
	public void cacheResult(
		java.util.List<com.qc.qcsms.model.StudentClass> studentClasses);

	/**
	* Creates a new student class with the primary key. Does not add the student class to the database.
	*
	* @param classId the primary key for the new student class
	* @return the new student class
	*/
	public com.qc.qcsms.model.StudentClass create(long classId);

	/**
	* Removes the student class with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param classId the primary key of the student class
	* @return the student class that was removed
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass remove(long classId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	public com.qc.qcsms.model.StudentClass updateImpl(
		com.qc.qcsms.model.StudentClass studentClass)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the student class with the primary key or throws a {@link com.qc.qcsms.NoSuchStudentClassException} if it could not be found.
	*
	* @param classId the primary key of the student class
	* @return the student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass findByPrimaryKey(long classId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException;

	/**
	* Returns the student class with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param classId the primary key of the student class
	* @return the student class, or <code>null</code> if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.StudentClass fetchByPrimaryKey(long classId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the student classes.
	*
	* @return the student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the student classes.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findAll(int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the student classes.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of student classes
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.StudentClass> findAll(int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the student classes from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of student classes.
	*
	* @return the number of student classes
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}