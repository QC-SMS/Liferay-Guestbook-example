/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link PenaltyCodeLocalService}.
 *
 * @author teddyku
 * @see PenaltyCodeLocalService
 * @generated
 */
public class PenaltyCodeLocalServiceWrapper implements PenaltyCodeLocalService,
	ServiceWrapper<PenaltyCodeLocalService> {
	public PenaltyCodeLocalServiceWrapper(
		PenaltyCodeLocalService penaltyCodeLocalService) {
		_penaltyCodeLocalService = penaltyCodeLocalService;
	}

	/**
	* Adds the penalty code to the database. Also notifies the appropriate model listeners.
	*
	* @param penaltyCode the penalty code
	* @return the penalty code that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.qc.qcsms.model.PenaltyCode addPenaltyCode(
		com.qc.qcsms.model.PenaltyCode penaltyCode)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.addPenaltyCode(penaltyCode);
	}

	/**
	* Creates a new penalty code with the primary key. Does not add the penalty code to the database.
	*
	* @param penaltyCodeId the primary key for the new penalty code
	* @return the new penalty code
	*/
	@Override
	public com.qc.qcsms.model.PenaltyCode createPenaltyCode(long penaltyCodeId) {
		return _penaltyCodeLocalService.createPenaltyCode(penaltyCodeId);
	}

	/**
	* Deletes the penalty code with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param penaltyCodeId the primary key of the penalty code
	* @return the penalty code that was removed
	* @throws PortalException if a penalty code with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.qc.qcsms.model.PenaltyCode deletePenaltyCode(long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.deletePenaltyCode(penaltyCodeId);
	}

	/**
	* Deletes the penalty code from the database. Also notifies the appropriate model listeners.
	*
	* @param penaltyCode the penalty code
	* @return the penalty code that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.qc.qcsms.model.PenaltyCode deletePenaltyCode(
		com.qc.qcsms.model.PenaltyCode penaltyCode)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.deletePenaltyCode(penaltyCode);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _penaltyCodeLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.dynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.qc.qcsms.model.PenaltyCode fetchPenaltyCode(long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.fetchPenaltyCode(penaltyCodeId);
	}

	/**
	* Returns the penalty code with the matching UUID and company.
	*
	* @param uuid the penalty code's UUID
	* @param companyId the primary key of the company
	* @return the matching penalty code, or <code>null</code> if a matching penalty code could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.qc.qcsms.model.PenaltyCode fetchPenaltyCodeByUuidAndCompanyId(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.fetchPenaltyCodeByUuidAndCompanyId(uuid,
			companyId);
	}

	/**
	* Returns the penalty code matching the UUID and group.
	*
	* @param uuid the penalty code's UUID
	* @param groupId the primary key of the group
	* @return the matching penalty code, or <code>null</code> if a matching penalty code could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.qc.qcsms.model.PenaltyCode fetchPenaltyCodeByUuidAndGroupId(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.fetchPenaltyCodeByUuidAndGroupId(uuid,
			groupId);
	}

	/**
	* Returns the penalty code with the primary key.
	*
	* @param penaltyCodeId the primary key of the penalty code
	* @return the penalty code
	* @throws PortalException if a penalty code with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.qc.qcsms.model.PenaltyCode getPenaltyCode(long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getPenaltyCode(penaltyCodeId);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns the penalty code with the matching UUID and company.
	*
	* @param uuid the penalty code's UUID
	* @param companyId the primary key of the company
	* @return the matching penalty code
	* @throws PortalException if a matching penalty code could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.qc.qcsms.model.PenaltyCode getPenaltyCodeByUuidAndCompanyId(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getPenaltyCodeByUuidAndCompanyId(uuid,
			companyId);
	}

	/**
	* Returns the penalty code matching the UUID and group.
	*
	* @param uuid the penalty code's UUID
	* @param groupId the primary key of the group
	* @return the matching penalty code
	* @throws PortalException if a matching penalty code could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.qc.qcsms.model.PenaltyCode getPenaltyCodeByUuidAndGroupId(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getPenaltyCodeByUuidAndGroupId(uuid,
			groupId);
	}

	/**
	* Returns a range of all the penalty codes.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyCodeModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of penalty codes
	* @param end the upper bound of the range of penalty codes (not inclusive)
	* @return the range of penalty codes
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.qc.qcsms.model.PenaltyCode> getPenaltyCodes(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getPenaltyCodes(start, end);
	}

	/**
	* Returns the number of penalty codes.
	*
	* @return the number of penalty codes
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getPenaltyCodesCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getPenaltyCodesCount();
	}

	/**
	* Updates the penalty code in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param penaltyCode the penalty code
	* @return the penalty code that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.qc.qcsms.model.PenaltyCode updatePenaltyCode(
		com.qc.qcsms.model.PenaltyCode penaltyCode)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.updatePenaltyCode(penaltyCode);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _penaltyCodeLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_penaltyCodeLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _penaltyCodeLocalService.invokeMethod(name, parameterTypes,
			arguments);
	}

	@Override
	public java.util.List<com.qc.qcsms.model.PenaltyCode> getPenaltyCodes(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getPenaltyCodes(groupId);
	}

	@Override
	public java.util.List<com.qc.qcsms.model.PenaltyCode> getPenaltyCodes(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getPenaltyCodes(groupId, start, end);
	}

	@Override
	public com.qc.qcsms.model.PenaltyCode addPenaltyCode(long userId,
		java.lang.String code, java.lang.String description,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.addPenaltyCode(userId, code,
			description, serviceContext);
	}

	@Override
	public com.qc.qcsms.model.PenaltyCode updatePenaltyCode(long userId,
		long penaltyCodeId, java.lang.String code,
		java.lang.String description,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.updatePenaltyCode(userId,
			penaltyCodeId, code, description, serviceContext);
	}

	@Override
	public com.qc.qcsms.model.PenaltyCode deletePenaltyCode(
		long penaltyCodeId,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.deletePenaltyCode(penaltyCodeId,
			serviceContext);
	}

	@Override
	public int getPenaltyCodeCount(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getPenaltyCodeCount(groupId);
	}

	@Override
	public java.util.List getSearchPenaltyCodes(java.lang.String code,
		java.lang.String description, boolean andSearch, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getSearchPenaltyCodes(code,
			description, andSearch, start, end, orderByComparator);
	}

	@Override
	public int getSearchPenaltyCodesCount(java.lang.String code,
		java.lang.String description, boolean andSearch)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCodeLocalService.getSearchPenaltyCodesCount(code,
			description, andSearch);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public PenaltyCodeLocalService getWrappedPenaltyCodeLocalService() {
		return _penaltyCodeLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedPenaltyCodeLocalService(
		PenaltyCodeLocalService penaltyCodeLocalService) {
		_penaltyCodeLocalService = penaltyCodeLocalService;
	}

	@Override
	public PenaltyCodeLocalService getWrappedService() {
		return _penaltyCodeLocalService;
	}

	@Override
	public void setWrappedService(
		PenaltyCodeLocalService penaltyCodeLocalService) {
		_penaltyCodeLocalService = penaltyCodeLocalService;
	}

	private PenaltyCodeLocalService _penaltyCodeLocalService;
}