/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.qc.qcsms.model.AbsenceEvent;

import java.util.List;

/**
 * The persistence utility for the absence event service. This utility wraps {@link AbsenceEventPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see AbsenceEventPersistence
 * @see AbsenceEventPersistenceImpl
 * @generated
 */
public class AbsenceEventUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(AbsenceEvent absenceEvent) {
		getPersistence().clearCache(absenceEvent);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<AbsenceEvent> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<AbsenceEvent> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<AbsenceEvent> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static AbsenceEvent update(AbsenceEvent absenceEvent)
		throws SystemException {
		return getPersistence().update(absenceEvent);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static AbsenceEvent update(AbsenceEvent absenceEvent,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(absenceEvent, serviceContext);
	}

	/**
	* Returns all the absence events where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid);
	}

	/**
	* Returns a range of all the absence events where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	* Returns an ordered range of all the absence events where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the absence events before and after the current absence event in the ordered set where uuid = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent[] findByUuid_PrevAndNext(
		long absenceEventId, java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByUuid_PrevAndNext(absenceEventId, uuid,
			orderByComparator);
	}

	/**
	* Removes all the absence events where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid(uuid);
	}

	/**
	* Returns the number of absence events where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid(uuid);
	}

	/**
	* Returns the absence event where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchAbsenceEventException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence().findByUUID_G(uuid, groupId);
	}

	/**
	* Returns the absence event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUUID_G(uuid, groupId);
	}

	/**
	* Returns the absence event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByUUID_G(
		java.lang.String uuid, long groupId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUUID_G(uuid, groupId, retrieveFromCache);
	}

	/**
	* Removes the absence event where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the absence event that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent removeByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence().removeByUUID_G(uuid, groupId);
	}

	/**
	* Returns the number of absence events where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUUID_G(java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUUID_G(uuid, groupId);
	}

	/**
	* Returns all the absence events where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid_C(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_C(uuid, companyId);
	}

	/**
	* Returns a range of all the absence events where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_C(uuid, companyId, start, end);
	}

	/**
	* Returns an ordered range of all the absence events where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUuid_C(uuid, companyId, start, end, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the absence events before and after the current absence event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent[] findByUuid_C_PrevAndNext(
		long absenceEventId, java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByUuid_C_PrevAndNext(absenceEventId, uuid, companyId,
			orderByComparator);
	}

	/**
	* Removes all the absence events where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid_C(uuid, companyId);
	}

	/**
	* Returns the number of absence events where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid_C(uuid, companyId);
	}

	/**
	* Returns all the absence events where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByGroupId(groupId);
	}

	/**
	* Returns a range of all the absence events where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByGroupId(groupId, start, end);
	}

	/**
	* Returns an ordered range of all the absence events where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByGroupId(groupId, start, end, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByGroupId_First(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence().findByGroupId_First(groupId, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByGroupId_First(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByGroupId_First(groupId, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByGroupId_Last(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence().findByGroupId_Last(groupId, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByGroupId_Last(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByGroupId_Last(groupId, orderByComparator);
	}

	/**
	* Returns the absence events before and after the current absence event in the ordered set where groupId = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent[] findByGroupId_PrevAndNext(
		long absenceEventId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByGroupId_PrevAndNext(absenceEventId, groupId,
			orderByComparator);
	}

	/**
	* Returns all the absence events that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching absence events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> filterFindByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterFindByGroupId(groupId);
	}

	/**
	* Returns a range of all the absence events that the user has permission to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> filterFindByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterFindByGroupId(groupId, start, end);
	}

	/**
	* Returns an ordered range of all the absence events that the user has permissions to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> filterFindByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .filterFindByGroupId(groupId, start, end, orderByComparator);
	}

	/**
	* Returns the absence events before and after the current absence event in the ordered set of absence events that the user has permission to view where groupId = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent[] filterFindByGroupId_PrevAndNext(
		long absenceEventId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .filterFindByGroupId_PrevAndNext(absenceEventId, groupId,
			orderByComparator);
	}

	/**
	* Removes all the absence events where groupId = &#63; from the database.
	*
	* @param groupId the group ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByGroupId(groupId);
	}

	/**
	* Returns the number of absence events where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByGroupId(groupId);
	}

	/**
	* Returns the number of absence events that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching absence events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static int filterCountByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterCountByGroupId(groupId);
	}

	/**
	* Returns all the absence events where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceDate(
		java.util.Date absenceDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAbsenceDate(absenceDate);
	}

	/**
	* Returns a range of all the absence events where absenceDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param absenceDate the absence date
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceDate(
		java.util.Date absenceDate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAbsenceDate(absenceDate, start, end);
	}

	/**
	* Returns an ordered range of all the absence events where absenceDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param absenceDate the absence date
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceDate(
		java.util.Date absenceDate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAbsenceDate(absenceDate, start, end, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByAbsenceDate_First(
		java.util.Date absenceDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByAbsenceDate_First(absenceDate, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByAbsenceDate_First(
		java.util.Date absenceDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAbsenceDate_First(absenceDate, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByAbsenceDate_Last(
		java.util.Date absenceDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByAbsenceDate_Last(absenceDate, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByAbsenceDate_Last(
		java.util.Date absenceDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAbsenceDate_Last(absenceDate, orderByComparator);
	}

	/**
	* Returns the absence events before and after the current absence event in the ordered set where absenceDate = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param absenceDate the absence date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent[] findByAbsenceDate_PrevAndNext(
		long absenceEventId, java.util.Date absenceDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByAbsenceDate_PrevAndNext(absenceEventId, absenceDate,
			orderByComparator);
	}

	/**
	* Removes all the absence events where absenceDate = &#63; from the database.
	*
	* @param absenceDate the absence date
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByAbsenceDate(java.util.Date absenceDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByAbsenceDate(absenceDate);
	}

	/**
	* Returns the number of absence events where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByAbsenceDate(java.util.Date absenceDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByAbsenceDate(absenceDate);
	}

	/**
	* Returns all the absence events where studentId = &#63;.
	*
	* @param studentId the student ID
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByStudentId(
		long studentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByStudentId(studentId);
	}

	/**
	* Returns a range of all the absence events where studentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param studentId the student ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByStudentId(
		long studentId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByStudentId(studentId, start, end);
	}

	/**
	* Returns an ordered range of all the absence events where studentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param studentId the student ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByStudentId(
		long studentId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByStudentId(studentId, start, end, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByStudentId_First(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByStudentId_First(studentId, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByStudentId_First(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByStudentId_First(studentId, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByStudentId_Last(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByStudentId_Last(studentId, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByStudentId_Last(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByStudentId_Last(studentId, orderByComparator);
	}

	/**
	* Returns the absence events before and after the current absence event in the ordered set where studentId = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent[] findByStudentId_PrevAndNext(
		long absenceEventId, long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByStudentId_PrevAndNext(absenceEventId, studentId,
			orderByComparator);
	}

	/**
	* Removes all the absence events where studentId = &#63; from the database.
	*
	* @param studentId the student ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByStudentId(long studentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByStudentId(studentId);
	}

	/**
	* Returns the number of absence events where studentId = &#63;.
	*
	* @param studentId the student ID
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByStudentId(long studentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByStudentId(studentId);
	}

	/**
	* Returns all the absence events where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceCodeId(
		long absenceCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAbsenceCodeId(absenceCodeId);
	}

	/**
	* Returns a range of all the absence events where absenceCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param absenceCodeId the absence code ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceCodeId(
		long absenceCodeId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByAbsenceCodeId(absenceCodeId, start, end);
	}

	/**
	* Returns an ordered range of all the absence events where absenceCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param absenceCodeId the absence code ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceCodeId(
		long absenceCodeId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByAbsenceCodeId(absenceCodeId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByAbsenceCodeId_First(
		long absenceCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByAbsenceCodeId_First(absenceCodeId, orderByComparator);
	}

	/**
	* Returns the first absence event in the ordered set where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByAbsenceCodeId_First(
		long absenceCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAbsenceCodeId_First(absenceCodeId, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByAbsenceCodeId_Last(
		long absenceCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByAbsenceCodeId_Last(absenceCodeId, orderByComparator);
	}

	/**
	* Returns the last absence event in the ordered set where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByAbsenceCodeId_Last(
		long absenceCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByAbsenceCodeId_Last(absenceCodeId, orderByComparator);
	}

	/**
	* Returns the absence events before and after the current absence event in the ordered set where absenceCodeId = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param absenceCodeId the absence code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent[] findByAbsenceCodeId_PrevAndNext(
		long absenceEventId, long absenceCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence()
				   .findByAbsenceCodeId_PrevAndNext(absenceEventId,
			absenceCodeId, orderByComparator);
	}

	/**
	* Removes all the absence events where absenceCodeId = &#63; from the database.
	*
	* @param absenceCodeId the absence code ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByAbsenceCodeId(long absenceCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByAbsenceCodeId(absenceCodeId);
	}

	/**
	* Returns the number of absence events where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByAbsenceCodeId(long absenceCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByAbsenceCodeId(absenceCodeId);
	}

	/**
	* Caches the absence event in the entity cache if it is enabled.
	*
	* @param absenceEvent the absence event
	*/
	public static void cacheResult(com.qc.qcsms.model.AbsenceEvent absenceEvent) {
		getPersistence().cacheResult(absenceEvent);
	}

	/**
	* Caches the absence events in the entity cache if it is enabled.
	*
	* @param absenceEvents the absence events
	*/
	public static void cacheResult(
		java.util.List<com.qc.qcsms.model.AbsenceEvent> absenceEvents) {
		getPersistence().cacheResult(absenceEvents);
	}

	/**
	* Creates a new absence event with the primary key. Does not add the absence event to the database.
	*
	* @param absenceEventId the primary key for the new absence event
	* @return the new absence event
	*/
	public static com.qc.qcsms.model.AbsenceEvent create(long absenceEventId) {
		return getPersistence().create(absenceEventId);
	}

	/**
	* Removes the absence event with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param absenceEventId the primary key of the absence event
	* @return the absence event that was removed
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent remove(long absenceEventId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence().remove(absenceEventId);
	}

	public static com.qc.qcsms.model.AbsenceEvent updateImpl(
		com.qc.qcsms.model.AbsenceEvent absenceEvent)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(absenceEvent);
	}

	/**
	* Returns the absence event with the primary key or throws a {@link com.qc.qcsms.NoSuchAbsenceEventException} if it could not be found.
	*
	* @param absenceEventId the primary key of the absence event
	* @return the absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent findByPrimaryKey(
		long absenceEventId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException {
		return getPersistence().findByPrimaryKey(absenceEventId);
	}

	/**
	* Returns the absence event with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param absenceEventId the primary key of the absence event
	* @return the absence event, or <code>null</code> if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.AbsenceEvent fetchByPrimaryKey(
		long absenceEventId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(absenceEventId);
	}

	/**
	* Returns all the absence events.
	*
	* @return the absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the absence events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the absence events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of absence events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.AbsenceEvent> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the absence events from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of absence events.
	*
	* @return the number of absence events
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static AbsenceEventPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (AbsenceEventPersistence)PortletBeanLocatorUtil.locate(com.qc.qcsms.service.ClpSerializer.getServletContextName(),
					AbsenceEventPersistence.class.getName());

			ReferenceRegistry.registerReference(AbsenceEventUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(AbsenceEventPersistence persistence) {
	}

	private static AbsenceEventPersistence _persistence;
}