/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import com.qc.qcsms.service.ClpSerializer;
import com.qc.qcsms.service.DisciplineCodeLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author teddyku
 */
public class DisciplineCodeClp extends BaseModelImpl<DisciplineCode>
	implements DisciplineCode {
	public DisciplineCodeClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return DisciplineCode.class;
	}

	@Override
	public String getModelClassName() {
		return DisciplineCode.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _disciplineCodeId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setDisciplineCodeId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _disciplineCodeId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("disciplineCodeId", getDisciplineCodeId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("assignedCode", getAssignedCode());
		attributes.put("description", getDescription());
		attributes.put("severity", getSeverity());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long disciplineCodeId = (Long)attributes.get("disciplineCodeId");

		if (disciplineCodeId != null) {
			setDisciplineCodeId(disciplineCodeId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String assignedCode = (String)attributes.get("assignedCode");

		if (assignedCode != null) {
			setAssignedCode(assignedCode);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		String severity = (String)attributes.get("severity");

		if (severity != null) {
			setSeverity(severity);
		}
	}

	@Override
	public String getUuid() {
		return _uuid;
	}

	@Override
	public void setUuid(String uuid) {
		_uuid = uuid;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setUuid", String.class);

				method.invoke(_disciplineCodeRemoteModel, uuid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getDisciplineCodeId() {
		return _disciplineCodeId;
	}

	@Override
	public void setDisciplineCodeId(long disciplineCodeId) {
		_disciplineCodeId = disciplineCodeId;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setDisciplineCodeId",
						long.class);

				method.invoke(_disciplineCodeRemoteModel, disciplineCodeId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getGroupId() {
		return _groupId;
	}

	@Override
	public void setGroupId(long groupId) {
		_groupId = groupId;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setGroupId", long.class);

				method.invoke(_disciplineCodeRemoteModel, groupId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCompanyId() {
		return _companyId;
	}

	@Override
	public void setCompanyId(long companyId) {
		_companyId = companyId;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyId", long.class);

				method.invoke(_disciplineCodeRemoteModel, companyId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserId() {
		return _userId;
	}

	@Override
	public void setUserId(long userId) {
		_userId = userId;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setUserId", long.class);

				method.invoke(_disciplineCodeRemoteModel, userId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
	}

	@Override
	public void setUserUuid(String userUuid) {
		_userUuid = userUuid;
	}

	@Override
	public String getUserName() {
		return _userName;
	}

	@Override
	public void setUserName(String userName) {
		_userName = userName;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setUserName", String.class);

				method.invoke(_disciplineCodeRemoteModel, userName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCreateDate() {
		return _createDate;
	}

	@Override
	public void setCreateDate(Date createDate) {
		_createDate = createDate;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setCreateDate", Date.class);

				method.invoke(_disciplineCodeRemoteModel, createDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getModifiedDate() {
		return _modifiedDate;
	}

	@Override
	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setModifiedDate", Date.class);

				method.invoke(_disciplineCodeRemoteModel, modifiedDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getAssignedCode() {
		return _assignedCode;
	}

	@Override
	public void setAssignedCode(String assignedCode) {
		_assignedCode = assignedCode;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setAssignedCode", String.class);

				method.invoke(_disciplineCodeRemoteModel, assignedCode);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getDescription() {
		return _description;
	}

	@Override
	public void setDescription(String description) {
		_description = description;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setDescription", String.class);

				method.invoke(_disciplineCodeRemoteModel, description);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSeverity() {
		return _severity;
	}

	@Override
	public void setSeverity(String severity) {
		_severity = severity;

		if (_disciplineCodeRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineCodeRemoteModel.getClass();

				Method method = clazz.getMethod("setSeverity", String.class);

				method.invoke(_disciplineCodeRemoteModel, severity);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public StagedModelType getStagedModelType() {
		return new StagedModelType(PortalUtil.getClassNameId(
				DisciplineCode.class.getName()));
	}

	public BaseModel<?> getDisciplineCodeRemoteModel() {
		return _disciplineCodeRemoteModel;
	}

	public void setDisciplineCodeRemoteModel(
		BaseModel<?> disciplineCodeRemoteModel) {
		_disciplineCodeRemoteModel = disciplineCodeRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _disciplineCodeRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_disciplineCodeRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			DisciplineCodeLocalServiceUtil.addDisciplineCode(this);
		}
		else {
			DisciplineCodeLocalServiceUtil.updateDisciplineCode(this);
		}
	}

	@Override
	public DisciplineCode toEscapedModel() {
		return (DisciplineCode)ProxyUtil.newProxyInstance(DisciplineCode.class.getClassLoader(),
			new Class[] { DisciplineCode.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		DisciplineCodeClp clone = new DisciplineCodeClp();

		clone.setUuid(getUuid());
		clone.setDisciplineCodeId(getDisciplineCodeId());
		clone.setGroupId(getGroupId());
		clone.setCompanyId(getCompanyId());
		clone.setUserId(getUserId());
		clone.setUserName(getUserName());
		clone.setCreateDate(getCreateDate());
		clone.setModifiedDate(getModifiedDate());
		clone.setAssignedCode(getAssignedCode());
		clone.setDescription(getDescription());
		clone.setSeverity(getSeverity());

		return clone;
	}

	@Override
	public int compareTo(DisciplineCode disciplineCode) {
		int value = 0;

		value = getAssignedCode().compareTo(disciplineCode.getAssignedCode());

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DisciplineCodeClp)) {
			return false;
		}

		DisciplineCodeClp disciplineCode = (DisciplineCodeClp)obj;

		long primaryKey = disciplineCode.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(23);

		sb.append("{uuid=");
		sb.append(getUuid());
		sb.append(", disciplineCodeId=");
		sb.append(getDisciplineCodeId());
		sb.append(", groupId=");
		sb.append(getGroupId());
		sb.append(", companyId=");
		sb.append(getCompanyId());
		sb.append(", userId=");
		sb.append(getUserId());
		sb.append(", userName=");
		sb.append(getUserName());
		sb.append(", createDate=");
		sb.append(getCreateDate());
		sb.append(", modifiedDate=");
		sb.append(getModifiedDate());
		sb.append(", assignedCode=");
		sb.append(getAssignedCode());
		sb.append(", description=");
		sb.append(getDescription());
		sb.append(", severity=");
		sb.append(getSeverity());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(37);

		sb.append("<model><model-name>");
		sb.append("com.qc.qcsms.model.DisciplineCode");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>uuid</column-name><column-value><![CDATA[");
		sb.append(getUuid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>disciplineCodeId</column-name><column-value><![CDATA[");
		sb.append(getDisciplineCodeId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>groupId</column-name><column-value><![CDATA[");
		sb.append(getGroupId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyId</column-name><column-value><![CDATA[");
		sb.append(getCompanyId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userId</column-name><column-value><![CDATA[");
		sb.append(getUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userName</column-name><column-value><![CDATA[");
		sb.append(getUserName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createDate</column-name><column-value><![CDATA[");
		sb.append(getCreateDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>modifiedDate</column-name><column-value><![CDATA[");
		sb.append(getModifiedDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>assignedCode</column-name><column-value><![CDATA[");
		sb.append(getAssignedCode());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>description</column-name><column-value><![CDATA[");
		sb.append(getDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>severity</column-name><column-value><![CDATA[");
		sb.append(getSeverity());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private String _uuid;
	private long _disciplineCodeId;
	private long _groupId;
	private long _companyId;
	private long _userId;
	private String _userUuid;
	private String _userName;
	private Date _createDate;
	private Date _modifiedDate;
	private String _assignedCode;
	private String _description;
	private String _severity;
	private BaseModel<?> _disciplineCodeRemoteModel;
	private Class<?> _clpSerializerClass = com.qc.qcsms.service.ClpSerializer.class;
}