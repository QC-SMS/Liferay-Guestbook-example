/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.qc.qcsms.model.AbsenceEvent;

/**
 * The persistence interface for the absence event service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see AbsenceEventPersistenceImpl
 * @see AbsenceEventUtil
 * @generated
 */
public interface AbsenceEventPersistence extends BasePersistence<AbsenceEvent> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link AbsenceEventUtil} to access the absence event persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the absence events where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the absence events where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the absence events where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first absence event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the first absence event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last absence event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the last absence event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the absence events before and after the current absence event in the ordered set where uuid = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent[] findByUuid_PrevAndNext(
		long absenceEventId, java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Removes all the absence events where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of absence events where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the absence event where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchAbsenceEventException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByUUID_G(java.lang.String uuid,
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the absence event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the absence event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByUUID_G(
		java.lang.String uuid, long groupId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the absence event where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the absence event that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent removeByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the number of absence events where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public int countByUUID_G(java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the absence events where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid_C(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the absence events where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the absence events where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first absence event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the first absence event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last absence event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the last absence event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the absence events before and after the current absence event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent[] findByUuid_C_PrevAndNext(
		long absenceEventId, java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Removes all the absence events where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of absence events where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public int countByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the absence events where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the absence events where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the absence events where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first absence event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByGroupId_First(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the first absence event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByGroupId_First(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last absence event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByGroupId_Last(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the last absence event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByGroupId_Last(long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the absence events before and after the current absence event in the ordered set where groupId = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent[] findByGroupId_PrevAndNext(
		long absenceEventId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns all the absence events that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching absence events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> filterFindByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the absence events that the user has permission to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> filterFindByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the absence events that the user has permissions to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> filterFindByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the absence events before and after the current absence event in the ordered set of absence events that the user has permission to view where groupId = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent[] filterFindByGroupId_PrevAndNext(
		long absenceEventId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Removes all the absence events where groupId = &#63; from the database.
	*
	* @param groupId the group ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of absence events where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public int countByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of absence events that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching absence events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public int filterCountByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the absence events where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceDate(
		java.util.Date absenceDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the absence events where absenceDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param absenceDate the absence date
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceDate(
		java.util.Date absenceDate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the absence events where absenceDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param absenceDate the absence date
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceDate(
		java.util.Date absenceDate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first absence event in the ordered set where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByAbsenceDate_First(
		java.util.Date absenceDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the first absence event in the ordered set where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByAbsenceDate_First(
		java.util.Date absenceDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last absence event in the ordered set where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByAbsenceDate_Last(
		java.util.Date absenceDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the last absence event in the ordered set where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByAbsenceDate_Last(
		java.util.Date absenceDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the absence events before and after the current absence event in the ordered set where absenceDate = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param absenceDate the absence date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent[] findByAbsenceDate_PrevAndNext(
		long absenceEventId, java.util.Date absenceDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Removes all the absence events where absenceDate = &#63; from the database.
	*
	* @param absenceDate the absence date
	* @throws SystemException if a system exception occurred
	*/
	public void removeByAbsenceDate(java.util.Date absenceDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of absence events where absenceDate = &#63;.
	*
	* @param absenceDate the absence date
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public int countByAbsenceDate(java.util.Date absenceDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the absence events where studentId = &#63;.
	*
	* @param studentId the student ID
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByStudentId(
		long studentId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the absence events where studentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param studentId the student ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByStudentId(
		long studentId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the absence events where studentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param studentId the student ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByStudentId(
		long studentId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first absence event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByStudentId_First(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the first absence event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByStudentId_First(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last absence event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByStudentId_Last(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the last absence event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByStudentId_Last(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the absence events before and after the current absence event in the ordered set where studentId = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent[] findByStudentId_PrevAndNext(
		long absenceEventId, long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Removes all the absence events where studentId = &#63; from the database.
	*
	* @param studentId the student ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByStudentId(long studentId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of absence events where studentId = &#63;.
	*
	* @param studentId the student ID
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public int countByStudentId(long studentId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the absence events where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @return the matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceCodeId(
		long absenceCodeId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the absence events where absenceCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param absenceCodeId the absence code ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceCodeId(
		long absenceCodeId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the absence events where absenceCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param absenceCodeId the absence code ID
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findByAbsenceCodeId(
		long absenceCodeId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first absence event in the ordered set where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByAbsenceCodeId_First(
		long absenceCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the first absence event in the ordered set where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByAbsenceCodeId_First(
		long absenceCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last absence event in the ordered set where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByAbsenceCodeId_Last(
		long absenceCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the last absence event in the ordered set where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching absence event, or <code>null</code> if a matching absence event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByAbsenceCodeId_Last(
		long absenceCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the absence events before and after the current absence event in the ordered set where absenceCodeId = &#63;.
	*
	* @param absenceEventId the primary key of the current absence event
	* @param absenceCodeId the absence code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent[] findByAbsenceCodeId_PrevAndNext(
		long absenceEventId, long absenceCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Removes all the absence events where absenceCodeId = &#63; from the database.
	*
	* @param absenceCodeId the absence code ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByAbsenceCodeId(long absenceCodeId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of absence events where absenceCodeId = &#63;.
	*
	* @param absenceCodeId the absence code ID
	* @return the number of matching absence events
	* @throws SystemException if a system exception occurred
	*/
	public int countByAbsenceCodeId(long absenceCodeId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the absence event in the entity cache if it is enabled.
	*
	* @param absenceEvent the absence event
	*/
	public void cacheResult(com.qc.qcsms.model.AbsenceEvent absenceEvent);

	/**
	* Caches the absence events in the entity cache if it is enabled.
	*
	* @param absenceEvents the absence events
	*/
	public void cacheResult(
		java.util.List<com.qc.qcsms.model.AbsenceEvent> absenceEvents);

	/**
	* Creates a new absence event with the primary key. Does not add the absence event to the database.
	*
	* @param absenceEventId the primary key for the new absence event
	* @return the new absence event
	*/
	public com.qc.qcsms.model.AbsenceEvent create(long absenceEventId);

	/**
	* Removes the absence event with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param absenceEventId the primary key of the absence event
	* @return the absence event that was removed
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent remove(long absenceEventId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	public com.qc.qcsms.model.AbsenceEvent updateImpl(
		com.qc.qcsms.model.AbsenceEvent absenceEvent)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the absence event with the primary key or throws a {@link com.qc.qcsms.NoSuchAbsenceEventException} if it could not be found.
	*
	* @param absenceEventId the primary key of the absence event
	* @return the absence event
	* @throws com.qc.qcsms.NoSuchAbsenceEventException if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent findByPrimaryKey(long absenceEventId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchAbsenceEventException;

	/**
	* Returns the absence event with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param absenceEventId the primary key of the absence event
	* @return the absence event, or <code>null</code> if a absence event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.qc.qcsms.model.AbsenceEvent fetchByPrimaryKey(
		long absenceEventId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the absence events.
	*
	* @return the absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the absence events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @return the range of absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findAll(int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the absence events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.AbsenceEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of absence events
	* @param end the upper bound of the range of absence events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of absence events
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.qc.qcsms.model.AbsenceEvent> findAll(int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the absence events from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of absence events.
	*
	* @return the number of absence events
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}