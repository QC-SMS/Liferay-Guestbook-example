/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link AbsenceEvent}.
 * </p>
 *
 * @author teddyku
 * @see AbsenceEvent
 * @generated
 */
public class AbsenceEventWrapper implements AbsenceEvent,
	ModelWrapper<AbsenceEvent> {
	public AbsenceEventWrapper(AbsenceEvent absenceEvent) {
		_absenceEvent = absenceEvent;
	}

	@Override
	public Class<?> getModelClass() {
		return AbsenceEvent.class;
	}

	@Override
	public String getModelClassName() {
		return AbsenceEvent.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("absenceEventId", getAbsenceEventId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("studentId", getStudentId());
		attributes.put("absenceCodeId", getAbsenceCodeId());
		attributes.put("absenceDescription", getAbsenceDescription());
		attributes.put("absenceDate", getAbsenceDate());
		attributes.put("wholeDayInd", getWholeDayInd());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long absenceEventId = (Long)attributes.get("absenceEventId");

		if (absenceEventId != null) {
			setAbsenceEventId(absenceEventId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		Long studentId = (Long)attributes.get("studentId");

		if (studentId != null) {
			setStudentId(studentId);
		}

		Long absenceCodeId = (Long)attributes.get("absenceCodeId");

		if (absenceCodeId != null) {
			setAbsenceCodeId(absenceCodeId);
		}

		String absenceDescription = (String)attributes.get("absenceDescription");

		if (absenceDescription != null) {
			setAbsenceDescription(absenceDescription);
		}

		Date absenceDate = (Date)attributes.get("absenceDate");

		if (absenceDate != null) {
			setAbsenceDate(absenceDate);
		}

		String wholeDayInd = (String)attributes.get("wholeDayInd");

		if (wholeDayInd != null) {
			setWholeDayInd(wholeDayInd);
		}
	}

	/**
	* Returns the primary key of this absence event.
	*
	* @return the primary key of this absence event
	*/
	@Override
	public long getPrimaryKey() {
		return _absenceEvent.getPrimaryKey();
	}

	/**
	* Sets the primary key of this absence event.
	*
	* @param primaryKey the primary key of this absence event
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_absenceEvent.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this absence event.
	*
	* @return the uuid of this absence event
	*/
	@Override
	public java.lang.String getUuid() {
		return _absenceEvent.getUuid();
	}

	/**
	* Sets the uuid of this absence event.
	*
	* @param uuid the uuid of this absence event
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_absenceEvent.setUuid(uuid);
	}

	/**
	* Returns the absence event ID of this absence event.
	*
	* @return the absence event ID of this absence event
	*/
	@Override
	public long getAbsenceEventId() {
		return _absenceEvent.getAbsenceEventId();
	}

	/**
	* Sets the absence event ID of this absence event.
	*
	* @param absenceEventId the absence event ID of this absence event
	*/
	@Override
	public void setAbsenceEventId(long absenceEventId) {
		_absenceEvent.setAbsenceEventId(absenceEventId);
	}

	/**
	* Returns the group ID of this absence event.
	*
	* @return the group ID of this absence event
	*/
	@Override
	public long getGroupId() {
		return _absenceEvent.getGroupId();
	}

	/**
	* Sets the group ID of this absence event.
	*
	* @param groupId the group ID of this absence event
	*/
	@Override
	public void setGroupId(long groupId) {
		_absenceEvent.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this absence event.
	*
	* @return the company ID of this absence event
	*/
	@Override
	public long getCompanyId() {
		return _absenceEvent.getCompanyId();
	}

	/**
	* Sets the company ID of this absence event.
	*
	* @param companyId the company ID of this absence event
	*/
	@Override
	public void setCompanyId(long companyId) {
		_absenceEvent.setCompanyId(companyId);
	}

	/**
	* Returns the user ID of this absence event.
	*
	* @return the user ID of this absence event
	*/
	@Override
	public long getUserId() {
		return _absenceEvent.getUserId();
	}

	/**
	* Sets the user ID of this absence event.
	*
	* @param userId the user ID of this absence event
	*/
	@Override
	public void setUserId(long userId) {
		_absenceEvent.setUserId(userId);
	}

	/**
	* Returns the user uuid of this absence event.
	*
	* @return the user uuid of this absence event
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _absenceEvent.getUserUuid();
	}

	/**
	* Sets the user uuid of this absence event.
	*
	* @param userUuid the user uuid of this absence event
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_absenceEvent.setUserUuid(userUuid);
	}

	/**
	* Returns the user name of this absence event.
	*
	* @return the user name of this absence event
	*/
	@Override
	public java.lang.String getUserName() {
		return _absenceEvent.getUserName();
	}

	/**
	* Sets the user name of this absence event.
	*
	* @param userName the user name of this absence event
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_absenceEvent.setUserName(userName);
	}

	/**
	* Returns the create date of this absence event.
	*
	* @return the create date of this absence event
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _absenceEvent.getCreateDate();
	}

	/**
	* Sets the create date of this absence event.
	*
	* @param createDate the create date of this absence event
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_absenceEvent.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this absence event.
	*
	* @return the modified date of this absence event
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _absenceEvent.getModifiedDate();
	}

	/**
	* Sets the modified date of this absence event.
	*
	* @param modifiedDate the modified date of this absence event
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_absenceEvent.setModifiedDate(modifiedDate);
	}

	/**
	* Returns the student ID of this absence event.
	*
	* @return the student ID of this absence event
	*/
	@Override
	public long getStudentId() {
		return _absenceEvent.getStudentId();
	}

	/**
	* Sets the student ID of this absence event.
	*
	* @param studentId the student ID of this absence event
	*/
	@Override
	public void setStudentId(long studentId) {
		_absenceEvent.setStudentId(studentId);
	}

	/**
	* Returns the absence code ID of this absence event.
	*
	* @return the absence code ID of this absence event
	*/
	@Override
	public long getAbsenceCodeId() {
		return _absenceEvent.getAbsenceCodeId();
	}

	/**
	* Sets the absence code ID of this absence event.
	*
	* @param absenceCodeId the absence code ID of this absence event
	*/
	@Override
	public void setAbsenceCodeId(long absenceCodeId) {
		_absenceEvent.setAbsenceCodeId(absenceCodeId);
	}

	/**
	* Returns the absence description of this absence event.
	*
	* @return the absence description of this absence event
	*/
	@Override
	public java.lang.String getAbsenceDescription() {
		return _absenceEvent.getAbsenceDescription();
	}

	/**
	* Sets the absence description of this absence event.
	*
	* @param absenceDescription the absence description of this absence event
	*/
	@Override
	public void setAbsenceDescription(java.lang.String absenceDescription) {
		_absenceEvent.setAbsenceDescription(absenceDescription);
	}

	/**
	* Returns the absence date of this absence event.
	*
	* @return the absence date of this absence event
	*/
	@Override
	public java.util.Date getAbsenceDate() {
		return _absenceEvent.getAbsenceDate();
	}

	/**
	* Sets the absence date of this absence event.
	*
	* @param absenceDate the absence date of this absence event
	*/
	@Override
	public void setAbsenceDate(java.util.Date absenceDate) {
		_absenceEvent.setAbsenceDate(absenceDate);
	}

	/**
	* Returns the whole day ind of this absence event.
	*
	* @return the whole day ind of this absence event
	*/
	@Override
	public java.lang.String getWholeDayInd() {
		return _absenceEvent.getWholeDayInd();
	}

	/**
	* Sets the whole day ind of this absence event.
	*
	* @param wholeDayInd the whole day ind of this absence event
	*/
	@Override
	public void setWholeDayInd(java.lang.String wholeDayInd) {
		_absenceEvent.setWholeDayInd(wholeDayInd);
	}

	@Override
	public boolean isNew() {
		return _absenceEvent.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_absenceEvent.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _absenceEvent.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_absenceEvent.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _absenceEvent.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _absenceEvent.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_absenceEvent.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _absenceEvent.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_absenceEvent.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_absenceEvent.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_absenceEvent.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new AbsenceEventWrapper((AbsenceEvent)_absenceEvent.clone());
	}

	@Override
	public int compareTo(com.qc.qcsms.model.AbsenceEvent absenceEvent) {
		return _absenceEvent.compareTo(absenceEvent);
	}

	@Override
	public int hashCode() {
		return _absenceEvent.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.qc.qcsms.model.AbsenceEvent> toCacheModel() {
		return _absenceEvent.toCacheModel();
	}

	@Override
	public com.qc.qcsms.model.AbsenceEvent toEscapedModel() {
		return new AbsenceEventWrapper(_absenceEvent.toEscapedModel());
	}

	@Override
	public com.qc.qcsms.model.AbsenceEvent toUnescapedModel() {
		return new AbsenceEventWrapper(_absenceEvent.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _absenceEvent.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _absenceEvent.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_absenceEvent.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof AbsenceEventWrapper)) {
			return false;
		}

		AbsenceEventWrapper absenceEventWrapper = (AbsenceEventWrapper)obj;

		if (Validator.equals(_absenceEvent, absenceEventWrapper._absenceEvent)) {
			return true;
		}

		return false;
	}

	@Override
	public StagedModelType getStagedModelType() {
		return _absenceEvent.getStagedModelType();
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public AbsenceEvent getWrappedAbsenceEvent() {
		return _absenceEvent;
	}

	@Override
	public AbsenceEvent getWrappedModel() {
		return _absenceEvent;
	}

	@Override
	public void resetOriginalValues() {
		_absenceEvent.resetOriginalValues();
	}

	private AbsenceEvent _absenceEvent;
}