/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for StudentClass. This utility wraps
 * {@link com.qc.qcsms.service.impl.StudentClassLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author teddyku
 * @see StudentClassLocalService
 * @see com.qc.qcsms.service.base.StudentClassLocalServiceBaseImpl
 * @see com.qc.qcsms.service.impl.StudentClassLocalServiceImpl
 * @generated
 */
public class StudentClassLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.qc.qcsms.service.impl.StudentClassLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the student class to the database. Also notifies the appropriate model listeners.
	*
	* @param studentClass the student class
	* @return the student class that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass addStudentClass(
		com.qc.qcsms.model.StudentClass studentClass)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addStudentClass(studentClass);
	}

	/**
	* Creates a new student class with the primary key. Does not add the student class to the database.
	*
	* @param classId the primary key for the new student class
	* @return the new student class
	*/
	public static com.qc.qcsms.model.StudentClass createStudentClass(
		long classId) {
		return getService().createStudentClass(classId);
	}

	/**
	* Deletes the student class with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param classId the primary key of the student class
	* @return the student class that was removed
	* @throws PortalException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass deleteStudentClass(
		long classId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteStudentClass(classId);
	}

	/**
	* Deletes the student class from the database. Also notifies the appropriate model listeners.
	*
	* @param studentClass the student class
	* @return the student class that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass deleteStudentClass(
		com.qc.qcsms.model.StudentClass studentClass)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteStudentClass(studentClass);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.qc.qcsms.model.StudentClass fetchStudentClass(
		long classId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchStudentClass(classId);
	}

	/**
	* Returns the student class with the matching UUID and company.
	*
	* @param uuid the student class's UUID
	* @param companyId the primary key of the company
	* @return the matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchStudentClassByUuidAndCompanyId(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchStudentClassByUuidAndCompanyId(uuid, companyId);
	}

	/**
	* Returns the student class matching the UUID and group.
	*
	* @param uuid the student class's UUID
	* @param groupId the primary key of the group
	* @return the matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchStudentClassByUuidAndGroupId(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchStudentClassByUuidAndGroupId(uuid, groupId);
	}

	/**
	* Returns the student class with the primary key.
	*
	* @param classId the primary key of the student class
	* @return the student class
	* @throws PortalException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass getStudentClass(long classId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getStudentClass(classId);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns the student class with the matching UUID and company.
	*
	* @param uuid the student class's UUID
	* @param companyId the primary key of the company
	* @return the matching student class
	* @throws PortalException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass getStudentClassByUuidAndCompanyId(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getStudentClassByUuidAndCompanyId(uuid, companyId);
	}

	/**
	* Returns the student class matching the UUID and group.
	*
	* @param uuid the student class's UUID
	* @param groupId the primary key of the group
	* @return the matching student class
	* @throws PortalException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass getStudentClassByUuidAndGroupId(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getStudentClassByUuidAndGroupId(uuid, groupId);
	}

	/**
	* Returns a range of all the student classes.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> getStudentClasses(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getStudentClasses(start, end);
	}

	/**
	* Returns the number of student classes.
	*
	* @return the number of student classes
	* @throws SystemException if a system exception occurred
	*/
	public static int getStudentClassesCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getStudentClassesCount();
	}

	/**
	* Updates the student class in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param studentClass the student class
	* @return the student class that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass updateStudentClass(
		com.qc.qcsms.model.StudentClass studentClass)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateStudentClass(studentClass);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static java.util.List<com.qc.qcsms.model.StudentClass> getStudentClasses(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getStudentClasses(groupId);
	}

	public static java.util.List<com.qc.qcsms.model.StudentClass> getStudentClasses(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getStudentClasses(groupId, start, end);
	}

	public static com.qc.qcsms.model.StudentClass addStudentClass(long userId,
		java.lang.String classCode,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().addStudentClass(userId, classCode, serviceContext);
	}

	public static com.qc.qcsms.model.StudentClass updateStudentClass(
		long userId, long studentClassId, java.lang.String classCode,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .updateStudentClass(userId, studentClassId, classCode,
			serviceContext);
	}

	public static com.qc.qcsms.model.StudentClass deleteStudentClass(
		long studentClassId,
		com.liferay.portal.service.ServiceContext serviceContext)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteStudentClass(studentClassId, serviceContext);
	}

	public static int getStudentClassCount(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getStudentClassCount(groupId);
	}

	public static java.util.List getSearchStudentClasses(
		java.lang.String classCode, boolean andSearch, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .getSearchStudentClasses(classCode, andSearch, start, end,
			orderByComparator);
	}

	public static int getSearchStudentClassesCount(java.lang.String classCode,
		boolean andSearch)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getSearchStudentClassesCount(classCode, andSearch);
	}

	public static void clearService() {
		_service = null;
	}

	public static StudentClassLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					StudentClassLocalService.class.getName());

			if (invokableLocalService instanceof StudentClassLocalService) {
				_service = (StudentClassLocalService)invokableLocalService;
			}
			else {
				_service = new StudentClassLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(StudentClassLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(StudentClassLocalService service) {
	}

	private static StudentClassLocalService _service;
}