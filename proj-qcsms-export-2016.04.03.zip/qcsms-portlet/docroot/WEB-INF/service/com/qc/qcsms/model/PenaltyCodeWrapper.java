/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link PenaltyCode}.
 * </p>
 *
 * @author teddyku
 * @see PenaltyCode
 * @generated
 */
public class PenaltyCodeWrapper implements PenaltyCode,
	ModelWrapper<PenaltyCode> {
	public PenaltyCodeWrapper(PenaltyCode penaltyCode) {
		_penaltyCode = penaltyCode;
	}

	@Override
	public Class<?> getModelClass() {
		return PenaltyCode.class;
	}

	@Override
	public String getModelClassName() {
		return PenaltyCode.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("penaltyCodeId", getPenaltyCodeId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("assignedCode", getAssignedCode());
		attributes.put("description", getDescription());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long penaltyCodeId = (Long)attributes.get("penaltyCodeId");

		if (penaltyCodeId != null) {
			setPenaltyCodeId(penaltyCodeId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String assignedCode = (String)attributes.get("assignedCode");

		if (assignedCode != null) {
			setAssignedCode(assignedCode);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}
	}

	/**
	* Returns the primary key of this penalty code.
	*
	* @return the primary key of this penalty code
	*/
	@Override
	public long getPrimaryKey() {
		return _penaltyCode.getPrimaryKey();
	}

	/**
	* Sets the primary key of this penalty code.
	*
	* @param primaryKey the primary key of this penalty code
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_penaltyCode.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this penalty code.
	*
	* @return the uuid of this penalty code
	*/
	@Override
	public java.lang.String getUuid() {
		return _penaltyCode.getUuid();
	}

	/**
	* Sets the uuid of this penalty code.
	*
	* @param uuid the uuid of this penalty code
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_penaltyCode.setUuid(uuid);
	}

	/**
	* Returns the penalty code ID of this penalty code.
	*
	* @return the penalty code ID of this penalty code
	*/
	@Override
	public long getPenaltyCodeId() {
		return _penaltyCode.getPenaltyCodeId();
	}

	/**
	* Sets the penalty code ID of this penalty code.
	*
	* @param penaltyCodeId the penalty code ID of this penalty code
	*/
	@Override
	public void setPenaltyCodeId(long penaltyCodeId) {
		_penaltyCode.setPenaltyCodeId(penaltyCodeId);
	}

	/**
	* Returns the group ID of this penalty code.
	*
	* @return the group ID of this penalty code
	*/
	@Override
	public long getGroupId() {
		return _penaltyCode.getGroupId();
	}

	/**
	* Sets the group ID of this penalty code.
	*
	* @param groupId the group ID of this penalty code
	*/
	@Override
	public void setGroupId(long groupId) {
		_penaltyCode.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this penalty code.
	*
	* @return the company ID of this penalty code
	*/
	@Override
	public long getCompanyId() {
		return _penaltyCode.getCompanyId();
	}

	/**
	* Sets the company ID of this penalty code.
	*
	* @param companyId the company ID of this penalty code
	*/
	@Override
	public void setCompanyId(long companyId) {
		_penaltyCode.setCompanyId(companyId);
	}

	/**
	* Returns the user ID of this penalty code.
	*
	* @return the user ID of this penalty code
	*/
	@Override
	public long getUserId() {
		return _penaltyCode.getUserId();
	}

	/**
	* Sets the user ID of this penalty code.
	*
	* @param userId the user ID of this penalty code
	*/
	@Override
	public void setUserId(long userId) {
		_penaltyCode.setUserId(userId);
	}

	/**
	* Returns the user uuid of this penalty code.
	*
	* @return the user uuid of this penalty code
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyCode.getUserUuid();
	}

	/**
	* Sets the user uuid of this penalty code.
	*
	* @param userUuid the user uuid of this penalty code
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_penaltyCode.setUserUuid(userUuid);
	}

	/**
	* Returns the user name of this penalty code.
	*
	* @return the user name of this penalty code
	*/
	@Override
	public java.lang.String getUserName() {
		return _penaltyCode.getUserName();
	}

	/**
	* Sets the user name of this penalty code.
	*
	* @param userName the user name of this penalty code
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_penaltyCode.setUserName(userName);
	}

	/**
	* Returns the create date of this penalty code.
	*
	* @return the create date of this penalty code
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _penaltyCode.getCreateDate();
	}

	/**
	* Sets the create date of this penalty code.
	*
	* @param createDate the create date of this penalty code
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_penaltyCode.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this penalty code.
	*
	* @return the modified date of this penalty code
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _penaltyCode.getModifiedDate();
	}

	/**
	* Sets the modified date of this penalty code.
	*
	* @param modifiedDate the modified date of this penalty code
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_penaltyCode.setModifiedDate(modifiedDate);
	}

	/**
	* Returns the assigned code of this penalty code.
	*
	* @return the assigned code of this penalty code
	*/
	@Override
	public java.lang.String getAssignedCode() {
		return _penaltyCode.getAssignedCode();
	}

	/**
	* Sets the assigned code of this penalty code.
	*
	* @param assignedCode the assigned code of this penalty code
	*/
	@Override
	public void setAssignedCode(java.lang.String assignedCode) {
		_penaltyCode.setAssignedCode(assignedCode);
	}

	/**
	* Returns the description of this penalty code.
	*
	* @return the description of this penalty code
	*/
	@Override
	public java.lang.String getDescription() {
		return _penaltyCode.getDescription();
	}

	/**
	* Sets the description of this penalty code.
	*
	* @param description the description of this penalty code
	*/
	@Override
	public void setDescription(java.lang.String description) {
		_penaltyCode.setDescription(description);
	}

	@Override
	public boolean isNew() {
		return _penaltyCode.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_penaltyCode.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _penaltyCode.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_penaltyCode.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _penaltyCode.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _penaltyCode.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_penaltyCode.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _penaltyCode.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_penaltyCode.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_penaltyCode.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_penaltyCode.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new PenaltyCodeWrapper((PenaltyCode)_penaltyCode.clone());
	}

	@Override
	public int compareTo(com.qc.qcsms.model.PenaltyCode penaltyCode) {
		return _penaltyCode.compareTo(penaltyCode);
	}

	@Override
	public int hashCode() {
		return _penaltyCode.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.qc.qcsms.model.PenaltyCode> toCacheModel() {
		return _penaltyCode.toCacheModel();
	}

	@Override
	public com.qc.qcsms.model.PenaltyCode toEscapedModel() {
		return new PenaltyCodeWrapper(_penaltyCode.toEscapedModel());
	}

	@Override
	public com.qc.qcsms.model.PenaltyCode toUnescapedModel() {
		return new PenaltyCodeWrapper(_penaltyCode.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _penaltyCode.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _penaltyCode.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_penaltyCode.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof PenaltyCodeWrapper)) {
			return false;
		}

		PenaltyCodeWrapper penaltyCodeWrapper = (PenaltyCodeWrapper)obj;

		if (Validator.equals(_penaltyCode, penaltyCodeWrapper._penaltyCode)) {
			return true;
		}

		return false;
	}

	@Override
	public StagedModelType getStagedModelType() {
		return _penaltyCode.getStagedModelType();
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public PenaltyCode getWrappedPenaltyCode() {
		return _penaltyCode;
	}

	@Override
	public PenaltyCode getWrappedModel() {
		return _penaltyCode;
	}

	@Override
	public void resetOriginalValues() {
		_penaltyCode.resetOriginalValues();
	}

	private PenaltyCode _penaltyCode;
}