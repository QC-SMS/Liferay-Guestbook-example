/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;
import com.liferay.portal.util.PortalUtil;

import com.qc.qcsms.service.ClpSerializer;
import com.qc.qcsms.service.DisciplineEventLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author teddyku
 */
public class DisciplineEventClp extends BaseModelImpl<DisciplineEvent>
	implements DisciplineEvent {
	public DisciplineEventClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return DisciplineEvent.class;
	}

	@Override
	public String getModelClassName() {
		return DisciplineEvent.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _disciplineEventId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setDisciplineEventId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _disciplineEventId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("disciplineEventId", getDisciplineEventId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("studentId", getStudentId());
		attributes.put("disciplineCodeId", getDisciplineCodeId());
		attributes.put("remarks", getRemarks());
		attributes.put("eventDate", getEventDate());
		attributes.put("penaltyCodeId", getPenaltyCodeId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long disciplineEventId = (Long)attributes.get("disciplineEventId");

		if (disciplineEventId != null) {
			setDisciplineEventId(disciplineEventId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		Long studentId = (Long)attributes.get("studentId");

		if (studentId != null) {
			setStudentId(studentId);
		}

		Long disciplineCodeId = (Long)attributes.get("disciplineCodeId");

		if (disciplineCodeId != null) {
			setDisciplineCodeId(disciplineCodeId);
		}

		String remarks = (String)attributes.get("remarks");

		if (remarks != null) {
			setRemarks(remarks);
		}

		Date eventDate = (Date)attributes.get("eventDate");

		if (eventDate != null) {
			setEventDate(eventDate);
		}

		Long penaltyCodeId = (Long)attributes.get("penaltyCodeId");

		if (penaltyCodeId != null) {
			setPenaltyCodeId(penaltyCodeId);
		}
	}

	@Override
	public String getUuid() {
		return _uuid;
	}

	@Override
	public void setUuid(String uuid) {
		_uuid = uuid;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setUuid", String.class);

				method.invoke(_disciplineEventRemoteModel, uuid);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getDisciplineEventId() {
		return _disciplineEventId;
	}

	@Override
	public void setDisciplineEventId(long disciplineEventId) {
		_disciplineEventId = disciplineEventId;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setDisciplineEventId",
						long.class);

				method.invoke(_disciplineEventRemoteModel, disciplineEventId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getGroupId() {
		return _groupId;
	}

	@Override
	public void setGroupId(long groupId) {
		_groupId = groupId;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setGroupId", long.class);

				method.invoke(_disciplineEventRemoteModel, groupId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getCompanyId() {
		return _companyId;
	}

	@Override
	public void setCompanyId(long companyId) {
		_companyId = companyId;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setCompanyId", long.class);

				method.invoke(_disciplineEventRemoteModel, companyId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserId() {
		return _userId;
	}

	@Override
	public void setUserId(long userId) {
		_userId = userId;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setUserId", long.class);

				method.invoke(_disciplineEventRemoteModel, userId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserUuid() throws SystemException {
		return PortalUtil.getUserValue(getUserId(), "uuid", _userUuid);
	}

	@Override
	public void setUserUuid(String userUuid) {
		_userUuid = userUuid;
	}

	@Override
	public String getUserName() {
		return _userName;
	}

	@Override
	public void setUserName(String userName) {
		_userName = userName;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setUserName", String.class);

				method.invoke(_disciplineEventRemoteModel, userName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCreateDate() {
		return _createDate;
	}

	@Override
	public void setCreateDate(Date createDate) {
		_createDate = createDate;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setCreateDate", Date.class);

				method.invoke(_disciplineEventRemoteModel, createDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getModifiedDate() {
		return _modifiedDate;
	}

	@Override
	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setModifiedDate", Date.class);

				method.invoke(_disciplineEventRemoteModel, modifiedDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getStudentId() {
		return _studentId;
	}

	@Override
	public void setStudentId(long studentId) {
		_studentId = studentId;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setStudentId", long.class);

				method.invoke(_disciplineEventRemoteModel, studentId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getDisciplineCodeId() {
		return _disciplineCodeId;
	}

	@Override
	public void setDisciplineCodeId(long disciplineCodeId) {
		_disciplineCodeId = disciplineCodeId;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setDisciplineCodeId",
						long.class);

				method.invoke(_disciplineEventRemoteModel, disciplineCodeId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRemarks() {
		return _remarks;
	}

	@Override
	public void setRemarks(String remarks) {
		_remarks = remarks;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setRemarks", String.class);

				method.invoke(_disciplineEventRemoteModel, remarks);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getEventDate() {
		return _eventDate;
	}

	@Override
	public void setEventDate(Date eventDate) {
		_eventDate = eventDate;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setEventDate", Date.class);

				method.invoke(_disciplineEventRemoteModel, eventDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getPenaltyCodeId() {
		return _penaltyCodeId;
	}

	@Override
	public void setPenaltyCodeId(long penaltyCodeId) {
		_penaltyCodeId = penaltyCodeId;

		if (_disciplineEventRemoteModel != null) {
			try {
				Class<?> clazz = _disciplineEventRemoteModel.getClass();

				Method method = clazz.getMethod("setPenaltyCodeId", long.class);

				method.invoke(_disciplineEventRemoteModel, penaltyCodeId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public StagedModelType getStagedModelType() {
		return new StagedModelType(PortalUtil.getClassNameId(
				DisciplineEvent.class.getName()));
	}

	public BaseModel<?> getDisciplineEventRemoteModel() {
		return _disciplineEventRemoteModel;
	}

	public void setDisciplineEventRemoteModel(
		BaseModel<?> disciplineEventRemoteModel) {
		_disciplineEventRemoteModel = disciplineEventRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _disciplineEventRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_disciplineEventRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			DisciplineEventLocalServiceUtil.addDisciplineEvent(this);
		}
		else {
			DisciplineEventLocalServiceUtil.updateDisciplineEvent(this);
		}
	}

	@Override
	public DisciplineEvent toEscapedModel() {
		return (DisciplineEvent)ProxyUtil.newProxyInstance(DisciplineEvent.class.getClassLoader(),
			new Class[] { DisciplineEvent.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		DisciplineEventClp clone = new DisciplineEventClp();

		clone.setUuid(getUuid());
		clone.setDisciplineEventId(getDisciplineEventId());
		clone.setGroupId(getGroupId());
		clone.setCompanyId(getCompanyId());
		clone.setUserId(getUserId());
		clone.setUserName(getUserName());
		clone.setCreateDate(getCreateDate());
		clone.setModifiedDate(getModifiedDate());
		clone.setStudentId(getStudentId());
		clone.setDisciplineCodeId(getDisciplineCodeId());
		clone.setRemarks(getRemarks());
		clone.setEventDate(getEventDate());
		clone.setPenaltyCodeId(getPenaltyCodeId());

		return clone;
	}

	@Override
	public int compareTo(DisciplineEvent disciplineEvent) {
		int value = 0;

		value = DateUtil.compareTo(getEventDate(),
				disciplineEvent.getEventDate());

		value = value * -1;

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DisciplineEventClp)) {
			return false;
		}

		DisciplineEventClp disciplineEvent = (DisciplineEventClp)obj;

		long primaryKey = disciplineEvent.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(27);

		sb.append("{uuid=");
		sb.append(getUuid());
		sb.append(", disciplineEventId=");
		sb.append(getDisciplineEventId());
		sb.append(", groupId=");
		sb.append(getGroupId());
		sb.append(", companyId=");
		sb.append(getCompanyId());
		sb.append(", userId=");
		sb.append(getUserId());
		sb.append(", userName=");
		sb.append(getUserName());
		sb.append(", createDate=");
		sb.append(getCreateDate());
		sb.append(", modifiedDate=");
		sb.append(getModifiedDate());
		sb.append(", studentId=");
		sb.append(getStudentId());
		sb.append(", disciplineCodeId=");
		sb.append(getDisciplineCodeId());
		sb.append(", remarks=");
		sb.append(getRemarks());
		sb.append(", eventDate=");
		sb.append(getEventDate());
		sb.append(", penaltyCodeId=");
		sb.append(getPenaltyCodeId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(43);

		sb.append("<model><model-name>");
		sb.append("com.qc.qcsms.model.DisciplineEvent");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>uuid</column-name><column-value><![CDATA[");
		sb.append(getUuid());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>disciplineEventId</column-name><column-value><![CDATA[");
		sb.append(getDisciplineEventId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>groupId</column-name><column-value><![CDATA[");
		sb.append(getGroupId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>companyId</column-name><column-value><![CDATA[");
		sb.append(getCompanyId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userId</column-name><column-value><![CDATA[");
		sb.append(getUserId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userName</column-name><column-value><![CDATA[");
		sb.append(getUserName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>createDate</column-name><column-value><![CDATA[");
		sb.append(getCreateDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>modifiedDate</column-name><column-value><![CDATA[");
		sb.append(getModifiedDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>studentId</column-name><column-value><![CDATA[");
		sb.append(getStudentId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>disciplineCodeId</column-name><column-value><![CDATA[");
		sb.append(getDisciplineCodeId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>remarks</column-name><column-value><![CDATA[");
		sb.append(getRemarks());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>eventDate</column-name><column-value><![CDATA[");
		sb.append(getEventDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>penaltyCodeId</column-name><column-value><![CDATA[");
		sb.append(getPenaltyCodeId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private String _uuid;
	private long _disciplineEventId;
	private long _groupId;
	private long _companyId;
	private long _userId;
	private String _userUuid;
	private String _userName;
	private Date _createDate;
	private Date _modifiedDate;
	private long _studentId;
	private long _disciplineCodeId;
	private String _remarks;
	private Date _eventDate;
	private long _penaltyCodeId;
	private BaseModel<?> _disciplineEventRemoteModel;
	private Class<?> _clpSerializerClass = com.qc.qcsms.service.ClpSerializer.class;
}