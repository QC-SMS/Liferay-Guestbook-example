/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link PenaltyEvent}.
 * </p>
 *
 * @author teddyku
 * @see PenaltyEvent
 * @generated
 */
public class PenaltyEventWrapper implements PenaltyEvent,
	ModelWrapper<PenaltyEvent> {
	public PenaltyEventWrapper(PenaltyEvent penaltyEvent) {
		_penaltyEvent = penaltyEvent;
	}

	@Override
	public Class<?> getModelClass() {
		return PenaltyEvent.class;
	}

	@Override
	public String getModelClassName() {
		return PenaltyEvent.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("penaltyEventId", getPenaltyEventId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("studentId", getStudentId());
		attributes.put("disciplineEventId", getDisciplineEventId());
		attributes.put("penaltyCodeId", getPenaltyCodeId());
		attributes.put("eventDescription", getEventDescription());
		attributes.put("remarks", getRemarks());
		attributes.put("studentLearningLogInd", getStudentLearningLogInd());
		attributes.put("webSAMSInd", getWebSAMSInd());
		attributes.put("brightFutureCompletedInd", getBrightFutureCompletedInd());
		attributes.put("copyReturnedInd", getCopyReturnedInd());
		attributes.put("eventDate", getEventDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long penaltyEventId = (Long)attributes.get("penaltyEventId");

		if (penaltyEventId != null) {
			setPenaltyEventId(penaltyEventId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		Long studentId = (Long)attributes.get("studentId");

		if (studentId != null) {
			setStudentId(studentId);
		}

		Long disciplineEventId = (Long)attributes.get("disciplineEventId");

		if (disciplineEventId != null) {
			setDisciplineEventId(disciplineEventId);
		}

		Long penaltyCodeId = (Long)attributes.get("penaltyCodeId");

		if (penaltyCodeId != null) {
			setPenaltyCodeId(penaltyCodeId);
		}

		String eventDescription = (String)attributes.get("eventDescription");

		if (eventDescription != null) {
			setEventDescription(eventDescription);
		}

		String remarks = (String)attributes.get("remarks");

		if (remarks != null) {
			setRemarks(remarks);
		}

		String studentLearningLogInd = (String)attributes.get(
				"studentLearningLogInd");

		if (studentLearningLogInd != null) {
			setStudentLearningLogInd(studentLearningLogInd);
		}

		String webSAMSInd = (String)attributes.get("webSAMSInd");

		if (webSAMSInd != null) {
			setWebSAMSInd(webSAMSInd);
		}

		String brightFutureCompletedInd = (String)attributes.get(
				"brightFutureCompletedInd");

		if (brightFutureCompletedInd != null) {
			setBrightFutureCompletedInd(brightFutureCompletedInd);
		}

		String copyReturnedInd = (String)attributes.get("copyReturnedInd");

		if (copyReturnedInd != null) {
			setCopyReturnedInd(copyReturnedInd);
		}

		Date eventDate = (Date)attributes.get("eventDate");

		if (eventDate != null) {
			setEventDate(eventDate);
		}
	}

	/**
	* Returns the primary key of this penalty event.
	*
	* @return the primary key of this penalty event
	*/
	@Override
	public long getPrimaryKey() {
		return _penaltyEvent.getPrimaryKey();
	}

	/**
	* Sets the primary key of this penalty event.
	*
	* @param primaryKey the primary key of this penalty event
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_penaltyEvent.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this penalty event.
	*
	* @return the uuid of this penalty event
	*/
	@Override
	public java.lang.String getUuid() {
		return _penaltyEvent.getUuid();
	}

	/**
	* Sets the uuid of this penalty event.
	*
	* @param uuid the uuid of this penalty event
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_penaltyEvent.setUuid(uuid);
	}

	/**
	* Returns the penalty event ID of this penalty event.
	*
	* @return the penalty event ID of this penalty event
	*/
	@Override
	public long getPenaltyEventId() {
		return _penaltyEvent.getPenaltyEventId();
	}

	/**
	* Sets the penalty event ID of this penalty event.
	*
	* @param penaltyEventId the penalty event ID of this penalty event
	*/
	@Override
	public void setPenaltyEventId(long penaltyEventId) {
		_penaltyEvent.setPenaltyEventId(penaltyEventId);
	}

	/**
	* Returns the group ID of this penalty event.
	*
	* @return the group ID of this penalty event
	*/
	@Override
	public long getGroupId() {
		return _penaltyEvent.getGroupId();
	}

	/**
	* Sets the group ID of this penalty event.
	*
	* @param groupId the group ID of this penalty event
	*/
	@Override
	public void setGroupId(long groupId) {
		_penaltyEvent.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this penalty event.
	*
	* @return the company ID of this penalty event
	*/
	@Override
	public long getCompanyId() {
		return _penaltyEvent.getCompanyId();
	}

	/**
	* Sets the company ID of this penalty event.
	*
	* @param companyId the company ID of this penalty event
	*/
	@Override
	public void setCompanyId(long companyId) {
		_penaltyEvent.setCompanyId(companyId);
	}

	/**
	* Returns the user ID of this penalty event.
	*
	* @return the user ID of this penalty event
	*/
	@Override
	public long getUserId() {
		return _penaltyEvent.getUserId();
	}

	/**
	* Sets the user ID of this penalty event.
	*
	* @param userId the user ID of this penalty event
	*/
	@Override
	public void setUserId(long userId) {
		_penaltyEvent.setUserId(userId);
	}

	/**
	* Returns the user uuid of this penalty event.
	*
	* @return the user uuid of this penalty event
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _penaltyEvent.getUserUuid();
	}

	/**
	* Sets the user uuid of this penalty event.
	*
	* @param userUuid the user uuid of this penalty event
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_penaltyEvent.setUserUuid(userUuid);
	}

	/**
	* Returns the user name of this penalty event.
	*
	* @return the user name of this penalty event
	*/
	@Override
	public java.lang.String getUserName() {
		return _penaltyEvent.getUserName();
	}

	/**
	* Sets the user name of this penalty event.
	*
	* @param userName the user name of this penalty event
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_penaltyEvent.setUserName(userName);
	}

	/**
	* Returns the create date of this penalty event.
	*
	* @return the create date of this penalty event
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _penaltyEvent.getCreateDate();
	}

	/**
	* Sets the create date of this penalty event.
	*
	* @param createDate the create date of this penalty event
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_penaltyEvent.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this penalty event.
	*
	* @return the modified date of this penalty event
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _penaltyEvent.getModifiedDate();
	}

	/**
	* Sets the modified date of this penalty event.
	*
	* @param modifiedDate the modified date of this penalty event
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_penaltyEvent.setModifiedDate(modifiedDate);
	}

	/**
	* Returns the student ID of this penalty event.
	*
	* @return the student ID of this penalty event
	*/
	@Override
	public long getStudentId() {
		return _penaltyEvent.getStudentId();
	}

	/**
	* Sets the student ID of this penalty event.
	*
	* @param studentId the student ID of this penalty event
	*/
	@Override
	public void setStudentId(long studentId) {
		_penaltyEvent.setStudentId(studentId);
	}

	/**
	* Returns the discipline event ID of this penalty event.
	*
	* @return the discipline event ID of this penalty event
	*/
	@Override
	public long getDisciplineEventId() {
		return _penaltyEvent.getDisciplineEventId();
	}

	/**
	* Sets the discipline event ID of this penalty event.
	*
	* @param disciplineEventId the discipline event ID of this penalty event
	*/
	@Override
	public void setDisciplineEventId(long disciplineEventId) {
		_penaltyEvent.setDisciplineEventId(disciplineEventId);
	}

	/**
	* Returns the penalty code ID of this penalty event.
	*
	* @return the penalty code ID of this penalty event
	*/
	@Override
	public long getPenaltyCodeId() {
		return _penaltyEvent.getPenaltyCodeId();
	}

	/**
	* Sets the penalty code ID of this penalty event.
	*
	* @param penaltyCodeId the penalty code ID of this penalty event
	*/
	@Override
	public void setPenaltyCodeId(long penaltyCodeId) {
		_penaltyEvent.setPenaltyCodeId(penaltyCodeId);
	}

	/**
	* Returns the event description of this penalty event.
	*
	* @return the event description of this penalty event
	*/
	@Override
	public java.lang.String getEventDescription() {
		return _penaltyEvent.getEventDescription();
	}

	/**
	* Sets the event description of this penalty event.
	*
	* @param eventDescription the event description of this penalty event
	*/
	@Override
	public void setEventDescription(java.lang.String eventDescription) {
		_penaltyEvent.setEventDescription(eventDescription);
	}

	/**
	* Returns the remarks of this penalty event.
	*
	* @return the remarks of this penalty event
	*/
	@Override
	public java.lang.String getRemarks() {
		return _penaltyEvent.getRemarks();
	}

	/**
	* Sets the remarks of this penalty event.
	*
	* @param remarks the remarks of this penalty event
	*/
	@Override
	public void setRemarks(java.lang.String remarks) {
		_penaltyEvent.setRemarks(remarks);
	}

	/**
	* Returns the student learning log ind of this penalty event.
	*
	* @return the student learning log ind of this penalty event
	*/
	@Override
	public java.lang.String getStudentLearningLogInd() {
		return _penaltyEvent.getStudentLearningLogInd();
	}

	/**
	* Sets the student learning log ind of this penalty event.
	*
	* @param studentLearningLogInd the student learning log ind of this penalty event
	*/
	@Override
	public void setStudentLearningLogInd(java.lang.String studentLearningLogInd) {
		_penaltyEvent.setStudentLearningLogInd(studentLearningLogInd);
	}

	/**
	* Returns the web s a m s ind of this penalty event.
	*
	* @return the web s a m s ind of this penalty event
	*/
	@Override
	public java.lang.String getWebSAMSInd() {
		return _penaltyEvent.getWebSAMSInd();
	}

	/**
	* Sets the web s a m s ind of this penalty event.
	*
	* @param webSAMSInd the web s a m s ind of this penalty event
	*/
	@Override
	public void setWebSAMSInd(java.lang.String webSAMSInd) {
		_penaltyEvent.setWebSAMSInd(webSAMSInd);
	}

	/**
	* Returns the bright future completed ind of this penalty event.
	*
	* @return the bright future completed ind of this penalty event
	*/
	@Override
	public java.lang.String getBrightFutureCompletedInd() {
		return _penaltyEvent.getBrightFutureCompletedInd();
	}

	/**
	* Sets the bright future completed ind of this penalty event.
	*
	* @param brightFutureCompletedInd the bright future completed ind of this penalty event
	*/
	@Override
	public void setBrightFutureCompletedInd(
		java.lang.String brightFutureCompletedInd) {
		_penaltyEvent.setBrightFutureCompletedInd(brightFutureCompletedInd);
	}

	/**
	* Returns the copy returned ind of this penalty event.
	*
	* @return the copy returned ind of this penalty event
	*/
	@Override
	public java.lang.String getCopyReturnedInd() {
		return _penaltyEvent.getCopyReturnedInd();
	}

	/**
	* Sets the copy returned ind of this penalty event.
	*
	* @param copyReturnedInd the copy returned ind of this penalty event
	*/
	@Override
	public void setCopyReturnedInd(java.lang.String copyReturnedInd) {
		_penaltyEvent.setCopyReturnedInd(copyReturnedInd);
	}

	/**
	* Returns the event date of this penalty event.
	*
	* @return the event date of this penalty event
	*/
	@Override
	public java.util.Date getEventDate() {
		return _penaltyEvent.getEventDate();
	}

	/**
	* Sets the event date of this penalty event.
	*
	* @param eventDate the event date of this penalty event
	*/
	@Override
	public void setEventDate(java.util.Date eventDate) {
		_penaltyEvent.setEventDate(eventDate);
	}

	@Override
	public boolean isNew() {
		return _penaltyEvent.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_penaltyEvent.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _penaltyEvent.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_penaltyEvent.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _penaltyEvent.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _penaltyEvent.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_penaltyEvent.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _penaltyEvent.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_penaltyEvent.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_penaltyEvent.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_penaltyEvent.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new PenaltyEventWrapper((PenaltyEvent)_penaltyEvent.clone());
	}

	@Override
	public int compareTo(com.qc.qcsms.model.PenaltyEvent penaltyEvent) {
		return _penaltyEvent.compareTo(penaltyEvent);
	}

	@Override
	public int hashCode() {
		return _penaltyEvent.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.qc.qcsms.model.PenaltyEvent> toCacheModel() {
		return _penaltyEvent.toCacheModel();
	}

	@Override
	public com.qc.qcsms.model.PenaltyEvent toEscapedModel() {
		return new PenaltyEventWrapper(_penaltyEvent.toEscapedModel());
	}

	@Override
	public com.qc.qcsms.model.PenaltyEvent toUnescapedModel() {
		return new PenaltyEventWrapper(_penaltyEvent.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _penaltyEvent.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _penaltyEvent.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_penaltyEvent.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof PenaltyEventWrapper)) {
			return false;
		}

		PenaltyEventWrapper penaltyEventWrapper = (PenaltyEventWrapper)obj;

		if (Validator.equals(_penaltyEvent, penaltyEventWrapper._penaltyEvent)) {
			return true;
		}

		return false;
	}

	@Override
	public StagedModelType getStagedModelType() {
		return _penaltyEvent.getStagedModelType();
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public PenaltyEvent getWrappedPenaltyEvent() {
		return _penaltyEvent;
	}

	@Override
	public PenaltyEvent getWrappedModel() {
		return _penaltyEvent;
	}

	@Override
	public void resetOriginalValues() {
		_penaltyEvent.resetOriginalValues();
	}

	private PenaltyEvent _penaltyEvent;
}