/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.qc.qcsms.model.PenaltyEvent;

import java.util.List;

/**
 * The persistence utility for the penalty event service. This utility wraps {@link PenaltyEventPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see PenaltyEventPersistence
 * @see PenaltyEventPersistenceImpl
 * @generated
 */
public class PenaltyEventUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(PenaltyEvent penaltyEvent) {
		getPersistence().clearCache(penaltyEvent);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<PenaltyEvent> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<PenaltyEvent> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<PenaltyEvent> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static PenaltyEvent update(PenaltyEvent penaltyEvent)
		throws SystemException {
		return getPersistence().update(penaltyEvent);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static PenaltyEvent update(PenaltyEvent penaltyEvent,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(penaltyEvent, serviceContext);
	}

	/**
	* Returns all the penalty events where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid);
	}

	/**
	* Returns a range of all the penalty events where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	* Returns an ordered range of all the penalty events where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where uuid = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent[] findByUuid_PrevAndNext(
		long penaltyEventId, java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByUuid_PrevAndNext(penaltyEventId, uuid,
			orderByComparator);
	}

	/**
	* Removes all the penalty events where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid(uuid);
	}

	/**
	* Returns the number of penalty events where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid(uuid);
	}

	/**
	* Returns the penalty event where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchPenaltyEventException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence().findByUUID_G(uuid, groupId);
	}

	/**
	* Returns the penalty event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUUID_G(uuid, groupId);
	}

	/**
	* Returns the penalty event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByUUID_G(
		java.lang.String uuid, long groupId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUUID_G(uuid, groupId, retrieveFromCache);
	}

	/**
	* Removes the penalty event where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the penalty event that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent removeByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence().removeByUUID_G(uuid, groupId);
	}

	/**
	* Returns the number of penalty events where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUUID_G(java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUUID_G(uuid, groupId);
	}

	/**
	* Returns all the penalty events where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid_C(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_C(uuid, companyId);
	}

	/**
	* Returns a range of all the penalty events where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_C(uuid, companyId, start, end);
	}

	/**
	* Returns an ordered range of all the penalty events where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUuid_C(uuid, companyId, start, end, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent[] findByUuid_C_PrevAndNext(
		long penaltyEventId, java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByUuid_C_PrevAndNext(penaltyEventId, uuid, companyId,
			orderByComparator);
	}

	/**
	* Removes all the penalty events where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid_C(uuid, companyId);
	}

	/**
	* Returns the number of penalty events where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid_C(uuid, companyId);
	}

	/**
	* Returns all the penalty events where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByGroupId(groupId);
	}

	/**
	* Returns a range of all the penalty events where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByGroupId(groupId, start, end);
	}

	/**
	* Returns an ordered range of all the penalty events where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByGroupId(groupId, start, end, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByGroupId_First(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence().findByGroupId_First(groupId, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByGroupId_First(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByGroupId_First(groupId, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByGroupId_Last(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence().findByGroupId_Last(groupId, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByGroupId_Last(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByGroupId_Last(groupId, orderByComparator);
	}

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where groupId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent[] findByGroupId_PrevAndNext(
		long penaltyEventId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByGroupId_PrevAndNext(penaltyEventId, groupId,
			orderByComparator);
	}

	/**
	* Returns all the penalty events that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching penalty events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> filterFindByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterFindByGroupId(groupId);
	}

	/**
	* Returns a range of all the penalty events that the user has permission to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> filterFindByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterFindByGroupId(groupId, start, end);
	}

	/**
	* Returns an ordered range of all the penalty events that the user has permissions to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> filterFindByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .filterFindByGroupId(groupId, start, end, orderByComparator);
	}

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set of penalty events that the user has permission to view where groupId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent[] filterFindByGroupId_PrevAndNext(
		long penaltyEventId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .filterFindByGroupId_PrevAndNext(penaltyEventId, groupId,
			orderByComparator);
	}

	/**
	* Removes all the penalty events where groupId = &#63; from the database.
	*
	* @param groupId the group ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByGroupId(groupId);
	}

	/**
	* Returns the number of penalty events where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByGroupId(groupId);
	}

	/**
	* Returns the number of penalty events that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching penalty events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static int filterCountByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterCountByGroupId(groupId);
	}

	/**
	* Returns all the penalty events where studentId = &#63;.
	*
	* @param studentId the student ID
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByStudentId(
		long studentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByStudentId(studentId);
	}

	/**
	* Returns a range of all the penalty events where studentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param studentId the student ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByStudentId(
		long studentId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByStudentId(studentId, start, end);
	}

	/**
	* Returns an ordered range of all the penalty events where studentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param studentId the student ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByStudentId(
		long studentId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByStudentId(studentId, start, end, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByStudentId_First(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByStudentId_First(studentId, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByStudentId_First(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByStudentId_First(studentId, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByStudentId_Last(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByStudentId_Last(studentId, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByStudentId_Last(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByStudentId_Last(studentId, orderByComparator);
	}

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where studentId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent[] findByStudentId_PrevAndNext(
		long penaltyEventId, long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByStudentId_PrevAndNext(penaltyEventId, studentId,
			orderByComparator);
	}

	/**
	* Removes all the penalty events where studentId = &#63; from the database.
	*
	* @param studentId the student ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByStudentId(long studentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByStudentId(studentId);
	}

	/**
	* Returns the number of penalty events where studentId = &#63;.
	*
	* @param studentId the student ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByStudentId(long studentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByStudentId(studentId);
	}

	/**
	* Returns all the penalty events where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByPenaltyCodeId(
		long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPenaltyCodeId(penaltyCodeId);
	}

	/**
	* Returns a range of all the penalty events where penaltyCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param penaltyCodeId the penalty code ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByPenaltyCodeId(
		long penaltyCodeId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPenaltyCodeId(penaltyCodeId, start, end);
	}

	/**
	* Returns an ordered range of all the penalty events where penaltyCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param penaltyCodeId the penalty code ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByPenaltyCodeId(
		long penaltyCodeId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByPenaltyCodeId(penaltyCodeId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByPenaltyCodeId_First(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByPenaltyCodeId_First(penaltyCodeId, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByPenaltyCodeId_First(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByPenaltyCodeId_First(penaltyCodeId, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByPenaltyCodeId_Last(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByPenaltyCodeId_Last(penaltyCodeId, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByPenaltyCodeId_Last(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByPenaltyCodeId_Last(penaltyCodeId, orderByComparator);
	}

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent[] findByPenaltyCodeId_PrevAndNext(
		long penaltyEventId, long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByPenaltyCodeId_PrevAndNext(penaltyEventId,
			penaltyCodeId, orderByComparator);
	}

	/**
	* Removes all the penalty events where penaltyCodeId = &#63; from the database.
	*
	* @param penaltyCodeId the penalty code ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByPenaltyCodeId(long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByPenaltyCodeId(penaltyCodeId);
	}

	/**
	* Returns the number of penalty events where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByPenaltyCodeId(long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByPenaltyCodeId(penaltyCodeId);
	}

	/**
	* Returns all the penalty events where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByDisciplineEventId(
		long disciplineEventId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByDisciplineEventId(disciplineEventId);
	}

	/**
	* Returns a range of all the penalty events where disciplineEventId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param disciplineEventId the discipline event ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByDisciplineEventId(
		long disciplineEventId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByDisciplineEventId(disciplineEventId, start, end);
	}

	/**
	* Returns an ordered range of all the penalty events where disciplineEventId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param disciplineEventId the discipline event ID
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByDisciplineEventId(
		long disciplineEventId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByDisciplineEventId(disciplineEventId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByDisciplineEventId_First(
		long disciplineEventId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByDisciplineEventId_First(disciplineEventId,
			orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByDisciplineEventId_First(
		long disciplineEventId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByDisciplineEventId_First(disciplineEventId,
			orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByDisciplineEventId_Last(
		long disciplineEventId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByDisciplineEventId_Last(disciplineEventId,
			orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByDisciplineEventId_Last(
		long disciplineEventId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByDisciplineEventId_Last(disciplineEventId,
			orderByComparator);
	}

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where disciplineEventId = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param disciplineEventId the discipline event ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent[] findByDisciplineEventId_PrevAndNext(
		long penaltyEventId, long disciplineEventId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByDisciplineEventId_PrevAndNext(penaltyEventId,
			disciplineEventId, orderByComparator);
	}

	/**
	* Removes all the penalty events where disciplineEventId = &#63; from the database.
	*
	* @param disciplineEventId the discipline event ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByDisciplineEventId(long disciplineEventId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByDisciplineEventId(disciplineEventId);
	}

	/**
	* Returns the number of penalty events where disciplineEventId = &#63;.
	*
	* @param disciplineEventId the discipline event ID
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByDisciplineEventId(long disciplineEventId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByDisciplineEventId(disciplineEventId);
	}

	/**
	* Returns all the penalty events where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @return the matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByEventDate(
		java.util.Date eventDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEventDate(eventDate);
	}

	/**
	* Returns a range of all the penalty events where eventDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param eventDate the event date
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByEventDate(
		java.util.Date eventDate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEventDate(eventDate, start, end);
	}

	/**
	* Returns an ordered range of all the penalty events where eventDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param eventDate the event date
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findByEventDate(
		java.util.Date eventDate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByEventDate(eventDate, start, end, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByEventDate_First(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByEventDate_First(eventDate, orderByComparator);
	}

	/**
	* Returns the first penalty event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByEventDate_First(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByEventDate_First(eventDate, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByEventDate_Last(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByEventDate_Last(eventDate, orderByComparator);
	}

	/**
	* Returns the last penalty event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching penalty event, or <code>null</code> if a matching penalty event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByEventDate_Last(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByEventDate_Last(eventDate, orderByComparator);
	}

	/**
	* Returns the penalty events before and after the current penalty event in the ordered set where eventDate = &#63;.
	*
	* @param penaltyEventId the primary key of the current penalty event
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent[] findByEventDate_PrevAndNext(
		long penaltyEventId, java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence()
				   .findByEventDate_PrevAndNext(penaltyEventId, eventDate,
			orderByComparator);
	}

	/**
	* Removes all the penalty events where eventDate = &#63; from the database.
	*
	* @param eventDate the event date
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByEventDate(java.util.Date eventDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByEventDate(eventDate);
	}

	/**
	* Returns the number of penalty events where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @return the number of matching penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByEventDate(java.util.Date eventDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByEventDate(eventDate);
	}

	/**
	* Caches the penalty event in the entity cache if it is enabled.
	*
	* @param penaltyEvent the penalty event
	*/
	public static void cacheResult(com.qc.qcsms.model.PenaltyEvent penaltyEvent) {
		getPersistence().cacheResult(penaltyEvent);
	}

	/**
	* Caches the penalty events in the entity cache if it is enabled.
	*
	* @param penaltyEvents the penalty events
	*/
	public static void cacheResult(
		java.util.List<com.qc.qcsms.model.PenaltyEvent> penaltyEvents) {
		getPersistence().cacheResult(penaltyEvents);
	}

	/**
	* Creates a new penalty event with the primary key. Does not add the penalty event to the database.
	*
	* @param penaltyEventId the primary key for the new penalty event
	* @return the new penalty event
	*/
	public static com.qc.qcsms.model.PenaltyEvent create(long penaltyEventId) {
		return getPersistence().create(penaltyEventId);
	}

	/**
	* Removes the penalty event with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param penaltyEventId the primary key of the penalty event
	* @return the penalty event that was removed
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent remove(long penaltyEventId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence().remove(penaltyEventId);
	}

	public static com.qc.qcsms.model.PenaltyEvent updateImpl(
		com.qc.qcsms.model.PenaltyEvent penaltyEvent)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(penaltyEvent);
	}

	/**
	* Returns the penalty event with the primary key or throws a {@link com.qc.qcsms.NoSuchPenaltyEventException} if it could not be found.
	*
	* @param penaltyEventId the primary key of the penalty event
	* @return the penalty event
	* @throws com.qc.qcsms.NoSuchPenaltyEventException if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent findByPrimaryKey(
		long penaltyEventId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchPenaltyEventException {
		return getPersistence().findByPrimaryKey(penaltyEventId);
	}

	/**
	* Returns the penalty event with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param penaltyEventId the primary key of the penalty event
	* @return the penalty event, or <code>null</code> if a penalty event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.PenaltyEvent fetchByPrimaryKey(
		long penaltyEventId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(penaltyEventId);
	}

	/**
	* Returns all the penalty events.
	*
	* @return the penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the penalty events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @return the range of penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the penalty events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.PenaltyEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of penalty events
	* @param end the upper bound of the range of penalty events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.PenaltyEvent> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the penalty events from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of penalty events.
	*
	* @return the number of penalty events
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static PenaltyEventPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (PenaltyEventPersistence)PortletBeanLocatorUtil.locate(com.qc.qcsms.service.ClpSerializer.getServletContextName(),
					PenaltyEventPersistence.class.getName());

			ReferenceRegistry.registerReference(PenaltyEventUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(PenaltyEventPersistence persistence) {
	}

	private static PenaltyEventPersistence _persistence;
}