/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services.
 *
 * @author teddyku
 * @generated
 */
public class PenaltyEventSoap implements Serializable {
	public static PenaltyEventSoap toSoapModel(PenaltyEvent model) {
		PenaltyEventSoap soapModel = new PenaltyEventSoap();

		soapModel.setUuid(model.getUuid());
		soapModel.setPenaltyEventId(model.getPenaltyEventId());
		soapModel.setGroupId(model.getGroupId());
		soapModel.setCompanyId(model.getCompanyId());
		soapModel.setUserId(model.getUserId());
		soapModel.setUserName(model.getUserName());
		soapModel.setCreateDate(model.getCreateDate());
		soapModel.setModifiedDate(model.getModifiedDate());
		soapModel.setStudentId(model.getStudentId());
		soapModel.setDisciplineEventId(model.getDisciplineEventId());
		soapModel.setPenaltyCodeId(model.getPenaltyCodeId());
		soapModel.setEventDescription(model.getEventDescription());
		soapModel.setRemarks(model.getRemarks());
		soapModel.setStudentLearningLogInd(model.getStudentLearningLogInd());
		soapModel.setWebSAMSInd(model.getWebSAMSInd());
		soapModel.setBrightFutureCompletedInd(model.getBrightFutureCompletedInd());
		soapModel.setCopyReturnedInd(model.getCopyReturnedInd());
		soapModel.setEventDate(model.getEventDate());

		return soapModel;
	}

	public static PenaltyEventSoap[] toSoapModels(PenaltyEvent[] models) {
		PenaltyEventSoap[] soapModels = new PenaltyEventSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static PenaltyEventSoap[][] toSoapModels(PenaltyEvent[][] models) {
		PenaltyEventSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new PenaltyEventSoap[models.length][models[0].length];
		}
		else {
			soapModels = new PenaltyEventSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static PenaltyEventSoap[] toSoapModels(List<PenaltyEvent> models) {
		List<PenaltyEventSoap> soapModels = new ArrayList<PenaltyEventSoap>(models.size());

		for (PenaltyEvent model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new PenaltyEventSoap[soapModels.size()]);
	}

	public PenaltyEventSoap() {
	}

	public long getPrimaryKey() {
		return _penaltyEventId;
	}

	public void setPrimaryKey(long pk) {
		setPenaltyEventId(pk);
	}

	public String getUuid() {
		return _uuid;
	}

	public void setUuid(String uuid) {
		_uuid = uuid;
	}

	public long getPenaltyEventId() {
		return _penaltyEventId;
	}

	public void setPenaltyEventId(long penaltyEventId) {
		_penaltyEventId = penaltyEventId;
	}

	public long getGroupId() {
		return _groupId;
	}

	public void setGroupId(long groupId) {
		_groupId = groupId;
	}

	public long getCompanyId() {
		return _companyId;
	}

	public void setCompanyId(long companyId) {
		_companyId = companyId;
	}

	public long getUserId() {
		return _userId;
	}

	public void setUserId(long userId) {
		_userId = userId;
	}

	public String getUserName() {
		return _userName;
	}

	public void setUserName(String userName) {
		_userName = userName;
	}

	public Date getCreateDate() {
		return _createDate;
	}

	public void setCreateDate(Date createDate) {
		_createDate = createDate;
	}

	public Date getModifiedDate() {
		return _modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		_modifiedDate = modifiedDate;
	}

	public long getStudentId() {
		return _studentId;
	}

	public void setStudentId(long studentId) {
		_studentId = studentId;
	}

	public long getDisciplineEventId() {
		return _disciplineEventId;
	}

	public void setDisciplineEventId(long disciplineEventId) {
		_disciplineEventId = disciplineEventId;
	}

	public long getPenaltyCodeId() {
		return _penaltyCodeId;
	}

	public void setPenaltyCodeId(long penaltyCodeId) {
		_penaltyCodeId = penaltyCodeId;
	}

	public String getEventDescription() {
		return _eventDescription;
	}

	public void setEventDescription(String eventDescription) {
		_eventDescription = eventDescription;
	}

	public String getRemarks() {
		return _remarks;
	}

	public void setRemarks(String remarks) {
		_remarks = remarks;
	}

	public String getStudentLearningLogInd() {
		return _studentLearningLogInd;
	}

	public void setStudentLearningLogInd(String studentLearningLogInd) {
		_studentLearningLogInd = studentLearningLogInd;
	}

	public String getWebSAMSInd() {
		return _webSAMSInd;
	}

	public void setWebSAMSInd(String webSAMSInd) {
		_webSAMSInd = webSAMSInd;
	}

	public String getBrightFutureCompletedInd() {
		return _brightFutureCompletedInd;
	}

	public void setBrightFutureCompletedInd(String brightFutureCompletedInd) {
		_brightFutureCompletedInd = brightFutureCompletedInd;
	}

	public String getCopyReturnedInd() {
		return _copyReturnedInd;
	}

	public void setCopyReturnedInd(String copyReturnedInd) {
		_copyReturnedInd = copyReturnedInd;
	}

	public Date getEventDate() {
		return _eventDate;
	}

	public void setEventDate(Date eventDate) {
		_eventDate = eventDate;
	}

	private String _uuid;
	private long _penaltyEventId;
	private long _groupId;
	private long _companyId;
	private long _userId;
	private String _userName;
	private Date _createDate;
	private Date _modifiedDate;
	private long _studentId;
	private long _disciplineEventId;
	private long _penaltyCodeId;
	private String _eventDescription;
	private String _remarks;
	private String _studentLearningLogInd;
	private String _webSAMSInd;
	private String _brightFutureCompletedInd;
	private String _copyReturnedInd;
	private Date _eventDate;
}