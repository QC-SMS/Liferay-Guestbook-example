/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link DisciplineEvent}.
 * </p>
 *
 * @author teddyku
 * @see DisciplineEvent
 * @generated
 */
public class DisciplineEventWrapper implements DisciplineEvent,
	ModelWrapper<DisciplineEvent> {
	public DisciplineEventWrapper(DisciplineEvent disciplineEvent) {
		_disciplineEvent = disciplineEvent;
	}

	@Override
	public Class<?> getModelClass() {
		return DisciplineEvent.class;
	}

	@Override
	public String getModelClassName() {
		return DisciplineEvent.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("disciplineEventId", getDisciplineEventId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("studentId", getStudentId());
		attributes.put("disciplineCodeId", getDisciplineCodeId());
		attributes.put("remarks", getRemarks());
		attributes.put("eventDate", getEventDate());
		attributes.put("penaltyCodeId", getPenaltyCodeId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long disciplineEventId = (Long)attributes.get("disciplineEventId");

		if (disciplineEventId != null) {
			setDisciplineEventId(disciplineEventId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		Long studentId = (Long)attributes.get("studentId");

		if (studentId != null) {
			setStudentId(studentId);
		}

		Long disciplineCodeId = (Long)attributes.get("disciplineCodeId");

		if (disciplineCodeId != null) {
			setDisciplineCodeId(disciplineCodeId);
		}

		String remarks = (String)attributes.get("remarks");

		if (remarks != null) {
			setRemarks(remarks);
		}

		Date eventDate = (Date)attributes.get("eventDate");

		if (eventDate != null) {
			setEventDate(eventDate);
		}

		Long penaltyCodeId = (Long)attributes.get("penaltyCodeId");

		if (penaltyCodeId != null) {
			setPenaltyCodeId(penaltyCodeId);
		}
	}

	/**
	* Returns the primary key of this discipline event.
	*
	* @return the primary key of this discipline event
	*/
	@Override
	public long getPrimaryKey() {
		return _disciplineEvent.getPrimaryKey();
	}

	/**
	* Sets the primary key of this discipline event.
	*
	* @param primaryKey the primary key of this discipline event
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_disciplineEvent.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this discipline event.
	*
	* @return the uuid of this discipline event
	*/
	@Override
	public java.lang.String getUuid() {
		return _disciplineEvent.getUuid();
	}

	/**
	* Sets the uuid of this discipline event.
	*
	* @param uuid the uuid of this discipline event
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_disciplineEvent.setUuid(uuid);
	}

	/**
	* Returns the discipline event ID of this discipline event.
	*
	* @return the discipline event ID of this discipline event
	*/
	@Override
	public long getDisciplineEventId() {
		return _disciplineEvent.getDisciplineEventId();
	}

	/**
	* Sets the discipline event ID of this discipline event.
	*
	* @param disciplineEventId the discipline event ID of this discipline event
	*/
	@Override
	public void setDisciplineEventId(long disciplineEventId) {
		_disciplineEvent.setDisciplineEventId(disciplineEventId);
	}

	/**
	* Returns the group ID of this discipline event.
	*
	* @return the group ID of this discipline event
	*/
	@Override
	public long getGroupId() {
		return _disciplineEvent.getGroupId();
	}

	/**
	* Sets the group ID of this discipline event.
	*
	* @param groupId the group ID of this discipline event
	*/
	@Override
	public void setGroupId(long groupId) {
		_disciplineEvent.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this discipline event.
	*
	* @return the company ID of this discipline event
	*/
	@Override
	public long getCompanyId() {
		return _disciplineEvent.getCompanyId();
	}

	/**
	* Sets the company ID of this discipline event.
	*
	* @param companyId the company ID of this discipline event
	*/
	@Override
	public void setCompanyId(long companyId) {
		_disciplineEvent.setCompanyId(companyId);
	}

	/**
	* Returns the user ID of this discipline event.
	*
	* @return the user ID of this discipline event
	*/
	@Override
	public long getUserId() {
		return _disciplineEvent.getUserId();
	}

	/**
	* Sets the user ID of this discipline event.
	*
	* @param userId the user ID of this discipline event
	*/
	@Override
	public void setUserId(long userId) {
		_disciplineEvent.setUserId(userId);
	}

	/**
	* Returns the user uuid of this discipline event.
	*
	* @return the user uuid of this discipline event
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _disciplineEvent.getUserUuid();
	}

	/**
	* Sets the user uuid of this discipline event.
	*
	* @param userUuid the user uuid of this discipline event
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_disciplineEvent.setUserUuid(userUuid);
	}

	/**
	* Returns the user name of this discipline event.
	*
	* @return the user name of this discipline event
	*/
	@Override
	public java.lang.String getUserName() {
		return _disciplineEvent.getUserName();
	}

	/**
	* Sets the user name of this discipline event.
	*
	* @param userName the user name of this discipline event
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_disciplineEvent.setUserName(userName);
	}

	/**
	* Returns the create date of this discipline event.
	*
	* @return the create date of this discipline event
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _disciplineEvent.getCreateDate();
	}

	/**
	* Sets the create date of this discipline event.
	*
	* @param createDate the create date of this discipline event
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_disciplineEvent.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this discipline event.
	*
	* @return the modified date of this discipline event
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _disciplineEvent.getModifiedDate();
	}

	/**
	* Sets the modified date of this discipline event.
	*
	* @param modifiedDate the modified date of this discipline event
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_disciplineEvent.setModifiedDate(modifiedDate);
	}

	/**
	* Returns the student ID of this discipline event.
	*
	* @return the student ID of this discipline event
	*/
	@Override
	public long getStudentId() {
		return _disciplineEvent.getStudentId();
	}

	/**
	* Sets the student ID of this discipline event.
	*
	* @param studentId the student ID of this discipline event
	*/
	@Override
	public void setStudentId(long studentId) {
		_disciplineEvent.setStudentId(studentId);
	}

	/**
	* Returns the discipline code ID of this discipline event.
	*
	* @return the discipline code ID of this discipline event
	*/
	@Override
	public long getDisciplineCodeId() {
		return _disciplineEvent.getDisciplineCodeId();
	}

	/**
	* Sets the discipline code ID of this discipline event.
	*
	* @param disciplineCodeId the discipline code ID of this discipline event
	*/
	@Override
	public void setDisciplineCodeId(long disciplineCodeId) {
		_disciplineEvent.setDisciplineCodeId(disciplineCodeId);
	}

	/**
	* Returns the remarks of this discipline event.
	*
	* @return the remarks of this discipline event
	*/
	@Override
	public java.lang.String getRemarks() {
		return _disciplineEvent.getRemarks();
	}

	/**
	* Sets the remarks of this discipline event.
	*
	* @param remarks the remarks of this discipline event
	*/
	@Override
	public void setRemarks(java.lang.String remarks) {
		_disciplineEvent.setRemarks(remarks);
	}

	/**
	* Returns the event date of this discipline event.
	*
	* @return the event date of this discipline event
	*/
	@Override
	public java.util.Date getEventDate() {
		return _disciplineEvent.getEventDate();
	}

	/**
	* Sets the event date of this discipline event.
	*
	* @param eventDate the event date of this discipline event
	*/
	@Override
	public void setEventDate(java.util.Date eventDate) {
		_disciplineEvent.setEventDate(eventDate);
	}

	/**
	* Returns the penalty code ID of this discipline event.
	*
	* @return the penalty code ID of this discipline event
	*/
	@Override
	public long getPenaltyCodeId() {
		return _disciplineEvent.getPenaltyCodeId();
	}

	/**
	* Sets the penalty code ID of this discipline event.
	*
	* @param penaltyCodeId the penalty code ID of this discipline event
	*/
	@Override
	public void setPenaltyCodeId(long penaltyCodeId) {
		_disciplineEvent.setPenaltyCodeId(penaltyCodeId);
	}

	@Override
	public boolean isNew() {
		return _disciplineEvent.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_disciplineEvent.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _disciplineEvent.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_disciplineEvent.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _disciplineEvent.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _disciplineEvent.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_disciplineEvent.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _disciplineEvent.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_disciplineEvent.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_disciplineEvent.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_disciplineEvent.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new DisciplineEventWrapper((DisciplineEvent)_disciplineEvent.clone());
	}

	@Override
	public int compareTo(com.qc.qcsms.model.DisciplineEvent disciplineEvent) {
		return _disciplineEvent.compareTo(disciplineEvent);
	}

	@Override
	public int hashCode() {
		return _disciplineEvent.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.qc.qcsms.model.DisciplineEvent> toCacheModel() {
		return _disciplineEvent.toCacheModel();
	}

	@Override
	public com.qc.qcsms.model.DisciplineEvent toEscapedModel() {
		return new DisciplineEventWrapper(_disciplineEvent.toEscapedModel());
	}

	@Override
	public com.qc.qcsms.model.DisciplineEvent toUnescapedModel() {
		return new DisciplineEventWrapper(_disciplineEvent.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _disciplineEvent.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _disciplineEvent.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_disciplineEvent.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DisciplineEventWrapper)) {
			return false;
		}

		DisciplineEventWrapper disciplineEventWrapper = (DisciplineEventWrapper)obj;

		if (Validator.equals(_disciplineEvent,
					disciplineEventWrapper._disciplineEvent)) {
			return true;
		}

		return false;
	}

	@Override
	public StagedModelType getStagedModelType() {
		return _disciplineEvent.getStagedModelType();
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public DisciplineEvent getWrappedDisciplineEvent() {
		return _disciplineEvent;
	}

	@Override
	public DisciplineEvent getWrappedModel() {
		return _disciplineEvent;
	}

	@Override
	public void resetOriginalValues() {
		_disciplineEvent.resetOriginalValues();
	}

	private DisciplineEvent _disciplineEvent;
}