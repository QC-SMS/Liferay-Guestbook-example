/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.qc.qcsms.model.DisciplineEvent;

import java.util.List;

/**
 * The persistence utility for the discipline event service. This utility wraps {@link DisciplineEventPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see DisciplineEventPersistence
 * @see DisciplineEventPersistenceImpl
 * @generated
 */
public class DisciplineEventUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(DisciplineEvent disciplineEvent) {
		getPersistence().clearCache(disciplineEvent);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<DisciplineEvent> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<DisciplineEvent> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<DisciplineEvent> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static DisciplineEvent update(DisciplineEvent disciplineEvent)
		throws SystemException {
		return getPersistence().update(disciplineEvent);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static DisciplineEvent update(DisciplineEvent disciplineEvent,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(disciplineEvent, serviceContext);
	}

	/**
	* Returns all the discipline events where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid);
	}

	/**
	* Returns a range of all the discipline events where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @return the range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	* Returns an ordered range of all the discipline events where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the discipline events before and after the current discipline event in the ordered set where uuid = &#63;.
	*
	* @param disciplineEventId the primary key of the current discipline event
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent[] findByUuid_PrevAndNext(
		long disciplineEventId, java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByUuid_PrevAndNext(disciplineEventId, uuid,
			orderByComparator);
	}

	/**
	* Removes all the discipline events where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid(uuid);
	}

	/**
	* Returns the number of discipline events where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid(uuid);
	}

	/**
	* Returns the discipline event where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchDisciplineEventException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence().findByUUID_G(uuid, groupId);
	}

	/**
	* Returns the discipline event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUUID_G(uuid, groupId);
	}

	/**
	* Returns the discipline event where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByUUID_G(
		java.lang.String uuid, long groupId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUUID_G(uuid, groupId, retrieveFromCache);
	}

	/**
	* Removes the discipline event where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the discipline event that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent removeByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence().removeByUUID_G(uuid, groupId);
	}

	/**
	* Returns the number of discipline events where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUUID_G(java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUUID_G(uuid, groupId);
	}

	/**
	* Returns all the discipline events where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByUuid_C(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_C(uuid, companyId);
	}

	/**
	* Returns a range of all the discipline events where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @return the range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_C(uuid, companyId, start, end);
	}

	/**
	* Returns an ordered range of all the discipline events where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUuid_C(uuid, companyId, start, end, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the discipline events before and after the current discipline event in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param disciplineEventId the primary key of the current discipline event
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent[] findByUuid_C_PrevAndNext(
		long disciplineEventId, java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByUuid_C_PrevAndNext(disciplineEventId, uuid,
			companyId, orderByComparator);
	}

	/**
	* Removes all the discipline events where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid_C(uuid, companyId);
	}

	/**
	* Returns the number of discipline events where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid_C(uuid, companyId);
	}

	/**
	* Returns all the discipline events where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByGroupId(groupId);
	}

	/**
	* Returns a range of all the discipline events where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @return the range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByGroupId(groupId, start, end);
	}

	/**
	* Returns an ordered range of all the discipline events where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByGroupId(groupId, start, end, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByGroupId_First(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence().findByGroupId_First(groupId, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByGroupId_First(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByGroupId_First(groupId, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByGroupId_Last(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence().findByGroupId_Last(groupId, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByGroupId_Last(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByGroupId_Last(groupId, orderByComparator);
	}

	/**
	* Returns the discipline events before and after the current discipline event in the ordered set where groupId = &#63;.
	*
	* @param disciplineEventId the primary key of the current discipline event
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent[] findByGroupId_PrevAndNext(
		long disciplineEventId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByGroupId_PrevAndNext(disciplineEventId, groupId,
			orderByComparator);
	}

	/**
	* Returns all the discipline events that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching discipline events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> filterFindByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterFindByGroupId(groupId);
	}

	/**
	* Returns a range of all the discipline events that the user has permission to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @return the range of matching discipline events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> filterFindByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterFindByGroupId(groupId, start, end);
	}

	/**
	* Returns an ordered range of all the discipline events that the user has permissions to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discipline events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> filterFindByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .filterFindByGroupId(groupId, start, end, orderByComparator);
	}

	/**
	* Returns the discipline events before and after the current discipline event in the ordered set of discipline events that the user has permission to view where groupId = &#63;.
	*
	* @param disciplineEventId the primary key of the current discipline event
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent[] filterFindByGroupId_PrevAndNext(
		long disciplineEventId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .filterFindByGroupId_PrevAndNext(disciplineEventId, groupId,
			orderByComparator);
	}

	/**
	* Removes all the discipline events where groupId = &#63; from the database.
	*
	* @param groupId the group ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByGroupId(groupId);
	}

	/**
	* Returns the number of discipline events where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByGroupId(groupId);
	}

	/**
	* Returns the number of discipline events that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching discipline events that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static int filterCountByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterCountByGroupId(groupId);
	}

	/**
	* Returns all the discipline events where studentId = &#63;.
	*
	* @param studentId the student ID
	* @return the matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByStudentId(
		long studentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByStudentId(studentId);
	}

	/**
	* Returns a range of all the discipline events where studentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param studentId the student ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @return the range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByStudentId(
		long studentId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByStudentId(studentId, start, end);
	}

	/**
	* Returns an ordered range of all the discipline events where studentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param studentId the student ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByStudentId(
		long studentId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByStudentId(studentId, start, end, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByStudentId_First(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByStudentId_First(studentId, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByStudentId_First(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByStudentId_First(studentId, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByStudentId_Last(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByStudentId_Last(studentId, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where studentId = &#63;.
	*
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByStudentId_Last(
		long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByStudentId_Last(studentId, orderByComparator);
	}

	/**
	* Returns the discipline events before and after the current discipline event in the ordered set where studentId = &#63;.
	*
	* @param disciplineEventId the primary key of the current discipline event
	* @param studentId the student ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent[] findByStudentId_PrevAndNext(
		long disciplineEventId, long studentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByStudentId_PrevAndNext(disciplineEventId, studentId,
			orderByComparator);
	}

	/**
	* Removes all the discipline events where studentId = &#63; from the database.
	*
	* @param studentId the student ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByStudentId(long studentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByStudentId(studentId);
	}

	/**
	* Returns the number of discipline events where studentId = &#63;.
	*
	* @param studentId the student ID
	* @return the number of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByStudentId(long studentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByStudentId(studentId);
	}

	/**
	* Returns all the discipline events where disciplineCodeId = &#63;.
	*
	* @param disciplineCodeId the discipline code ID
	* @return the matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByDisciplineCode(
		long disciplineCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByDisciplineCode(disciplineCodeId);
	}

	/**
	* Returns a range of all the discipline events where disciplineCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param disciplineCodeId the discipline code ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @return the range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByDisciplineCode(
		long disciplineCodeId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByDisciplineCode(disciplineCodeId, start, end);
	}

	/**
	* Returns an ordered range of all the discipline events where disciplineCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param disciplineCodeId the discipline code ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByDisciplineCode(
		long disciplineCodeId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByDisciplineCode(disciplineCodeId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where disciplineCodeId = &#63;.
	*
	* @param disciplineCodeId the discipline code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByDisciplineCode_First(
		long disciplineCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByDisciplineCode_First(disciplineCodeId,
			orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where disciplineCodeId = &#63;.
	*
	* @param disciplineCodeId the discipline code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByDisciplineCode_First(
		long disciplineCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByDisciplineCode_First(disciplineCodeId,
			orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where disciplineCodeId = &#63;.
	*
	* @param disciplineCodeId the discipline code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByDisciplineCode_Last(
		long disciplineCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByDisciplineCode_Last(disciplineCodeId,
			orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where disciplineCodeId = &#63;.
	*
	* @param disciplineCodeId the discipline code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByDisciplineCode_Last(
		long disciplineCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByDisciplineCode_Last(disciplineCodeId,
			orderByComparator);
	}

	/**
	* Returns the discipline events before and after the current discipline event in the ordered set where disciplineCodeId = &#63;.
	*
	* @param disciplineEventId the primary key of the current discipline event
	* @param disciplineCodeId the discipline code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent[] findByDisciplineCode_PrevAndNext(
		long disciplineEventId, long disciplineCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByDisciplineCode_PrevAndNext(disciplineEventId,
			disciplineCodeId, orderByComparator);
	}

	/**
	* Removes all the discipline events where disciplineCodeId = &#63; from the database.
	*
	* @param disciplineCodeId the discipline code ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByDisciplineCode(long disciplineCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByDisciplineCode(disciplineCodeId);
	}

	/**
	* Returns the number of discipline events where disciplineCodeId = &#63;.
	*
	* @param disciplineCodeId the discipline code ID
	* @return the number of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByDisciplineCode(long disciplineCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByDisciplineCode(disciplineCodeId);
	}

	/**
	* Returns all the discipline events where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @return the matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByEventDate(
		java.util.Date eventDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEventDate(eventDate);
	}

	/**
	* Returns a range of all the discipline events where eventDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param eventDate the event date
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @return the range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByEventDate(
		java.util.Date eventDate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEventDate(eventDate, start, end);
	}

	/**
	* Returns an ordered range of all the discipline events where eventDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param eventDate the event date
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByEventDate(
		java.util.Date eventDate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByEventDate(eventDate, start, end, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByEventDate_First(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByEventDate_First(eventDate, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByEventDate_First(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByEventDate_First(eventDate, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByEventDate_Last(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByEventDate_Last(eventDate, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByEventDate_Last(
		java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByEventDate_Last(eventDate, orderByComparator);
	}

	/**
	* Returns the discipline events before and after the current discipline event in the ordered set where eventDate = &#63;.
	*
	* @param disciplineEventId the primary key of the current discipline event
	* @param eventDate the event date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent[] findByEventDate_PrevAndNext(
		long disciplineEventId, java.util.Date eventDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByEventDate_PrevAndNext(disciplineEventId, eventDate,
			orderByComparator);
	}

	/**
	* Removes all the discipline events where eventDate = &#63; from the database.
	*
	* @param eventDate the event date
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByEventDate(java.util.Date eventDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByEventDate(eventDate);
	}

	/**
	* Returns the number of discipline events where eventDate = &#63;.
	*
	* @param eventDate the event date
	* @return the number of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByEventDate(java.util.Date eventDate)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByEventDate(eventDate);
	}

	/**
	* Returns all the discipline events where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @return the matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByPenaltyCode(
		long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPenaltyCode(penaltyCodeId);
	}

	/**
	* Returns a range of all the discipline events where penaltyCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param penaltyCodeId the penalty code ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @return the range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByPenaltyCode(
		long penaltyCodeId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByPenaltyCode(penaltyCodeId, start, end);
	}

	/**
	* Returns an ordered range of all the discipline events where penaltyCodeId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param penaltyCodeId the penalty code ID
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findByPenaltyCode(
		long penaltyCodeId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByPenaltyCode(penaltyCodeId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByPenaltyCode_First(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByPenaltyCode_First(penaltyCodeId, orderByComparator);
	}

	/**
	* Returns the first discipline event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByPenaltyCode_First(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByPenaltyCode_First(penaltyCodeId, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByPenaltyCode_Last(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByPenaltyCode_Last(penaltyCodeId, orderByComparator);
	}

	/**
	* Returns the last discipline event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching discipline event, or <code>null</code> if a matching discipline event could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByPenaltyCode_Last(
		long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByPenaltyCode_Last(penaltyCodeId, orderByComparator);
	}

	/**
	* Returns the discipline events before and after the current discipline event in the ordered set where penaltyCodeId = &#63;.
	*
	* @param disciplineEventId the primary key of the current discipline event
	* @param penaltyCodeId the penalty code ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent[] findByPenaltyCode_PrevAndNext(
		long disciplineEventId, long penaltyCodeId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence()
				   .findByPenaltyCode_PrevAndNext(disciplineEventId,
			penaltyCodeId, orderByComparator);
	}

	/**
	* Removes all the discipline events where penaltyCodeId = &#63; from the database.
	*
	* @param penaltyCodeId the penalty code ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByPenaltyCode(long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByPenaltyCode(penaltyCodeId);
	}

	/**
	* Returns the number of discipline events where penaltyCodeId = &#63;.
	*
	* @param penaltyCodeId the penalty code ID
	* @return the number of matching discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static int countByPenaltyCode(long penaltyCodeId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByPenaltyCode(penaltyCodeId);
	}

	/**
	* Caches the discipline event in the entity cache if it is enabled.
	*
	* @param disciplineEvent the discipline event
	*/
	public static void cacheResult(
		com.qc.qcsms.model.DisciplineEvent disciplineEvent) {
		getPersistence().cacheResult(disciplineEvent);
	}

	/**
	* Caches the discipline events in the entity cache if it is enabled.
	*
	* @param disciplineEvents the discipline events
	*/
	public static void cacheResult(
		java.util.List<com.qc.qcsms.model.DisciplineEvent> disciplineEvents) {
		getPersistence().cacheResult(disciplineEvents);
	}

	/**
	* Creates a new discipline event with the primary key. Does not add the discipline event to the database.
	*
	* @param disciplineEventId the primary key for the new discipline event
	* @return the new discipline event
	*/
	public static com.qc.qcsms.model.DisciplineEvent create(
		long disciplineEventId) {
		return getPersistence().create(disciplineEventId);
	}

	/**
	* Removes the discipline event with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param disciplineEventId the primary key of the discipline event
	* @return the discipline event that was removed
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent remove(
		long disciplineEventId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence().remove(disciplineEventId);
	}

	public static com.qc.qcsms.model.DisciplineEvent updateImpl(
		com.qc.qcsms.model.DisciplineEvent disciplineEvent)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(disciplineEvent);
	}

	/**
	* Returns the discipline event with the primary key or throws a {@link com.qc.qcsms.NoSuchDisciplineEventException} if it could not be found.
	*
	* @param disciplineEventId the primary key of the discipline event
	* @return the discipline event
	* @throws com.qc.qcsms.NoSuchDisciplineEventException if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent findByPrimaryKey(
		long disciplineEventId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchDisciplineEventException {
		return getPersistence().findByPrimaryKey(disciplineEventId);
	}

	/**
	* Returns the discipline event with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param disciplineEventId the primary key of the discipline event
	* @return the discipline event, or <code>null</code> if a discipline event with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.DisciplineEvent fetchByPrimaryKey(
		long disciplineEventId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(disciplineEventId);
	}

	/**
	* Returns all the discipline events.
	*
	* @return the discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the discipline events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @return the range of discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the discipline events.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.DisciplineEventModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of discipline events
	* @param end the upper bound of the range of discipline events (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.DisciplineEvent> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the discipline events from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of discipline events.
	*
	* @return the number of discipline events
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static DisciplineEventPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (DisciplineEventPersistence)PortletBeanLocatorUtil.locate(com.qc.qcsms.service.ClpSerializer.getServletContextName(),
					DisciplineEventPersistence.class.getName());

			ReferenceRegistry.registerReference(DisciplineEventUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(DisciplineEventPersistence persistence) {
	}

	private static DisciplineEventPersistence _persistence;
}