package com.qc.qcsms.service.permission;

import com.qc.qcsms.model.DisciplineCode;
import com.qc.qcsms.service.DisciplineCodeLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.security.permission.PermissionChecker;

public class DisciplineCodePermission {
    public static void check(PermissionChecker permissionChecker,
            long disciplineCodeId, String actionId) throws PortalException,
            SystemException {

        if (!contains(permissionChecker, disciplineCodeId, actionId)) {
            throw new PrincipalException();
        }
    }

    public static boolean contains(PermissionChecker permissionChecker,
            long disciplineCodeId, String actionId) throws PortalException,
            SystemException {
        DisciplineCode disciplineCode = DisciplineCodeLocalServiceUtil
                .getDisciplineCode(disciplineCodeId);
        return permissionChecker
                .hasPermission(disciplineCode.getGroupId(),
                        DisciplineCode.class.getName(), disciplineCode.getDisciplineCodeId(),
                        actionId);
    }
}
