/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.impl;

import java.util.Date;
import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.qc.qcsms.ClassCodeException;
import com.qc.qcsms.DisciplineCodeException;
import com.qc.qcsms.DisciplineCodeLengthException;
import com.qc.qcsms.DisciplineCodeUniqueException;
import com.qc.qcsms.DisciplineDescriptionException;
import com.qc.qcsms.DisciplineDescriptionLengthException;
import com.qc.qcsms.FormClassException;
import com.qc.qcsms.FormNoException;
import com.qc.qcsms.NoSuchDisciplineCodeException;
import com.qc.qcsms.model.DisciplineCode;
import com.qc.qcsms.model.StudentClass;
import com.qc.qcsms.service.DisciplineCodeLocalServiceUtil;
import com.qc.qcsms.service.StudentClassLocalServiceUtil;
import com.qc.qcsms.service.base.DisciplineCodeLocalServiceBaseImpl;

/**
 * The implementation of the discipline code local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.qc.qcsms.service.DisciplineCodeLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author teddyku
 * @see com.qc.qcsms.service.base.DisciplineCodeLocalServiceBaseImpl
 * @see com.qc.qcsms.service.DisciplineCodeLocalServiceUtil
 */
public class DisciplineCodeLocalServiceImpl
	extends DisciplineCodeLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.qc.qcsms.service.DisciplineCodeLocalServiceUtil} to access the discipline code local service.
	 */
	public List<DisciplineCode> getDisciplineCodes(long groupId) throws SystemException {
	    return disciplineCodePersistence.findByGroupId(groupId);
	}

	public List<DisciplineCode> getDisciplineCodes(long groupId, int start, int end)
	   throws SystemException {
	    return disciplineCodePersistence.findByGroupId(groupId, start, end);
	}
	
	protected void validate (String code, String description, String severity) throws PortalException, SystemException {
	    if (Validator.isNull(code)) {
	    	throw new DisciplineCodeException();
	    }
	    if (code.length() > 3) {
	    	throw new DisciplineCodeLengthException();
	    }
	    if (Validator.isNull(description)) {
	    	throw new DisciplineDescriptionException();
	    }
	    if (description.length() > 255) {
	    	throw new DisciplineDescriptionLengthException();
	    }
	    try {
	    	DisciplineCode disciplineCode = disciplineCodePersistence.findByAssignedCode(code);
	    	throw new DisciplineCodeUniqueException();
	    }
	    catch(NoSuchDisciplineCodeException ex) {
	    	// Expected no record found
	    }
	}
	
	public DisciplineCode addDisciplineCode(long userId, String code, String description, String severity,
		    ServiceContext serviceContext) throws SystemException, PortalException {
		long groupId = serviceContext.getScopeGroupId();
		User user = userPersistence.findByPrimaryKey(userId);
		Date now = new Date();
		validate(code, description, severity);

		long disciplineCodeId = counterLocalService.increment();
		DisciplineCode disciplineCode = disciplineCodePersistence.create(disciplineCodeId);

		disciplineCode.setUuid(serviceContext.getUuid());
		disciplineCode.setUserId(userId);
		disciplineCode.setGroupId(groupId);
		disciplineCode.setCompanyId(user.getCompanyId());
		disciplineCode.setUserName(user.getFullName());
		disciplineCode.setCreateDate(serviceContext.getCreateDate(now));
		disciplineCode.setModifiedDate(serviceContext.getModifiedDate(now));
		disciplineCode.setAssignedCode(code);
		disciplineCode.setDescription(description);
		disciplineCode.setSeverity(severity);
		disciplineCode.setExpandoBridgeAttributes(serviceContext);
		disciplineCodePersistence.update(disciplineCode);

		resourceLocalService.addResources(user.getCompanyId(), groupId, userId,
			       DisciplineCode.class.getName(), disciplineCodeId, false, true, true);
		return disciplineCode;
	}

	public DisciplineCode updateDisciplineCode(long userId, long disciplineCodeId,
		String code, String description, String severity, ServiceContext serviceContext) throws PortalException, SystemException {
		Date now = new Date();
		validate(code, description, severity);
		DisciplineCode disciplineCode = getDisciplineCode(disciplineCodeId);
		
		User user = UserLocalServiceUtil.getUser(userId);
		disciplineCode.setUserId(userId);
		disciplineCode.setUserName(user.getFullName());
		disciplineCode.setModifiedDate(serviceContext.getModifiedDate(now));
		disciplineCode.setAssignedCode(code);
		disciplineCode.setDescription(description);
		disciplineCode.setSeverity(severity);
		disciplineCode.setExpandoBridgeAttributes(serviceContext);
		disciplineCodePersistence.update(disciplineCode);
		resourceLocalService.updateResources(serviceContext.getCompanyId(),
		                serviceContext.getScopeGroupId(), DisciplineCode.class.getName(), disciplineCodeId,
		                serviceContext.getGroupPermissions(),
		                serviceContext.getGuestPermissions());
		return disciplineCode;
	}
	
	public DisciplineCode deleteDisciplineCode(long disciplineCodeId,
            ServiceContext serviceContext) throws PortalException, SystemException {
	    DisciplineCode disciplineCode = getDisciplineCode(disciplineCodeId);
	    resourceLocalService.deleteResource(serviceContext.getCompanyId(),
	                    DisciplineCode.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL,
	                    disciplineCodeId);
	    disciplineCode = deleteDisciplineCode(disciplineCode);
	    return disciplineCode;
	}
	
	public int getDisciplineCodeCount(long groupId) throws SystemException {
        return disciplineCodePersistence.countByGroupId(groupId);
	}

	public List getSearchDisciplineCodes(String code, String description, String severity, boolean andSearch, int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		DynamicQuery dynamicQuery = buildStudentDynamicQuery(code, description, severity, andSearch);
		return DisciplineCodeLocalServiceUtil.dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	public int getSearchDisciplineCodesCount(String code, String description, String severity, boolean andSearch) 
		throws SystemException {
		DynamicQuery dynamicQuery = buildStudentDynamicQuery(code, description, severity, andSearch);
		return (int)DisciplineCodeLocalServiceUtil.dynamicQueryCount(dynamicQuery);
	}

	protected DynamicQuery buildStudentDynamicQuery(String code, String description, String severity, boolean andSearch) {
		Junction junction = null;
		if(andSearch) {
			junction = RestrictionsFactoryUtil.conjunction();
		} else {
			junction = RestrictionsFactoryUtil.disjunction();
		}
		if(Validator.isNotNull(code)) {
			Property property = PropertyFactoryUtil.forName("code");
			String value = (new StringBuilder("%")).append(code).append("%").toString();
			junction.add(property.like(value));
		}
		if(Validator.isNotNull(description)) {
			Property property = PropertyFactoryUtil.forName("description");
			String value = (new StringBuilder("%")).append(description).append("%").toString();
			junction.add(property.like(value));
		}
		if(Validator.isNotNull(severity)) {
			Property property = PropertyFactoryUtil.forName("severity");
			String value = (new StringBuilder("%")).append(severity).append("%").toString();
			junction.add(property.like(value));
		}
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(DisciplineCode.class, getClassLoader());
		return dynamicQuery.add(junction);
	}
}