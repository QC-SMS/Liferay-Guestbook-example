package com.qc.qcsms.service.permission;

import com.qc.qcsms.model.StudentClass;
import com.qc.qcsms.service.StudentClassLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.security.auth.PrincipalException;
import com.liferay.portal.security.permission.PermissionChecker;

public class StudentClassPermission {
    public static void check(PermissionChecker permissionChecker,
            long studentClassId, String actionId) throws PortalException,
            SystemException {

        if (!contains(permissionChecker, studentClassId, actionId)) {
            throw new PrincipalException();
        }
    }

    public static boolean contains(PermissionChecker permissionChecker,
            long studentClassId, String actionId) throws PortalException,
            SystemException {
        StudentClass studentClass = StudentClassLocalServiceUtil
                .getStudentClass(studentClassId);
        return permissionChecker
                .hasPermission(studentClass.getGroupId(),
                        StudentClass.class.getName(), studentClass.getClassId(),
                        actionId);
    }
}
