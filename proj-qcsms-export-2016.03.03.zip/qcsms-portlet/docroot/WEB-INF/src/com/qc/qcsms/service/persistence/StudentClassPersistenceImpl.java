/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.kernel.cache.CacheRegistryUtil;
import com.liferay.portal.kernel.dao.orm.EntityCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderCacheUtil;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.InstanceFactory;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.UnmodifiableList;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.uuid.PortalUUIDUtil;
import com.liferay.portal.model.CacheModel;
import com.liferay.portal.model.ModelListener;
import com.liferay.portal.security.permission.InlineSQLHelperUtil;
import com.liferay.portal.service.persistence.impl.BasePersistenceImpl;

import com.qc.qcsms.NoSuchStudentClassException;
import com.qc.qcsms.model.StudentClass;
import com.qc.qcsms.model.impl.StudentClassImpl;
import com.qc.qcsms.model.impl.StudentClassModelImpl;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * The persistence implementation for the student class service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see StudentClassPersistence
 * @see StudentClassUtil
 * @generated
 */
public class StudentClassPersistenceImpl extends BasePersistenceImpl<StudentClass>
	implements StudentClassPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link StudentClassUtil} to access the student class persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = StudentClassImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid",
			new String[] {
				String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid",
			new String[] { String.class.getName() },
			StudentClassModelImpl.UUID_COLUMN_BITMASK |
			StudentClassModelImpl.FORMNO_COLUMN_BITMASK |
			StudentClassModelImpl.CLASSCODE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid",
			new String[] { String.class.getName() });

	/**
	 * Returns all the student classes where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByUuid(String uuid) throws SystemException {
		return findByUuid(uuid, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the student classes where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @return the range of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByUuid(String uuid, int start, int end)
		throws SystemException {
		return findByUuid(uuid, start, end, null);
	}

	/**
	 * Returns an ordered range of all the student classes where uuid = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByUuid(String uuid, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID;
			finderArgs = new Object[] { uuid, start, end, orderByComparator };
		}

		List<StudentClass> list = (List<StudentClass>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (StudentClass studentClass : list) {
				if (!Validator.equals(uuid, studentClass.getUuid())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(StudentClassModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				if (!pagination) {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<StudentClass>(list);
				}
				else {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first student class in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByUuid_First(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByUuid_First(uuid, orderByComparator);

		if (studentClass != null) {
			return studentClass;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchStudentClassException(msg.toString());
	}

	/**
	 * Returns the first student class in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByUuid_First(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		List<StudentClass> list = findByUuid(uuid, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last student class in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByUuid_Last(String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByUuid_Last(uuid, orderByComparator);

		if (studentClass != null) {
			return studentClass;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchStudentClassException(msg.toString());
	}

	/**
	 * Returns the last student class in the ordered set where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByUuid_Last(String uuid,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid(uuid);

		if (count == 0) {
			return null;
		}

		List<StudentClass> list = findByUuid(uuid, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the student classes before and after the current student class in the ordered set where uuid = &#63;.
	 *
	 * @param classId the primary key of the current student class
	 * @param uuid the uuid
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass[] findByUuid_PrevAndNext(long classId, String uuid,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = findByPrimaryKey(classId);

		Session session = null;

		try {
			session = openSession();

			StudentClass[] array = new StudentClassImpl[3];

			array[0] = getByUuid_PrevAndNext(session, studentClass, uuid,
					orderByComparator, true);

			array[1] = studentClass;

			array[2] = getByUuid_PrevAndNext(session, studentClass, uuid,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected StudentClass getByUuid_PrevAndNext(Session session,
		StudentClass studentClass, String uuid,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_UUID_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(StudentClassModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(studentClass);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<StudentClass> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the student classes where uuid = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid(String uuid) throws SystemException {
		for (StudentClass studentClass : findByUuid(uuid, QueryUtil.ALL_POS,
				QueryUtil.ALL_POS, null)) {
			remove(studentClass);
		}
	}

	/**
	 * Returns the number of student classes where uuid = &#63;.
	 *
	 * @param uuid the uuid
	 * @return the number of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid(String uuid) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID;

		Object[] finderArgs = new Object[] { uuid };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_STUDENTCLASS_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_UUID_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_UUID_1 = "studentClass.uuid IS NULL";
	private static final String _FINDER_COLUMN_UUID_UUID_2 = "studentClass.uuid = ?";
	private static final String _FINDER_COLUMN_UUID_UUID_3 = "(studentClass.uuid IS NULL OR studentClass.uuid = '')";
	public static final FinderPath FINDER_PATH_FETCH_BY_UUID_G = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_ENTITY, "fetchByUUID_G",
			new String[] { String.class.getName(), Long.class.getName() },
			StudentClassModelImpl.UUID_COLUMN_BITMASK |
			StudentClassModelImpl.GROUPID_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID_G = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUUID_G",
			new String[] { String.class.getName(), Long.class.getName() });

	/**
	 * Returns the student class where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchStudentClassException} if it could not be found.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByUUID_G(String uuid, long groupId)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByUUID_G(uuid, groupId);

		if (studentClass == null) {
			StringBundler msg = new StringBundler(6);

			msg.append(_NO_SUCH_ENTITY_WITH_KEY);

			msg.append("uuid=");
			msg.append(uuid);

			msg.append(", groupId=");
			msg.append(groupId);

			msg.append(StringPool.CLOSE_CURLY_BRACE);

			if (_log.isWarnEnabled()) {
				_log.warn(msg.toString());
			}

			throw new NoSuchStudentClassException(msg.toString());
		}

		return studentClass;
	}

	/**
	 * Returns the student class where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByUUID_G(String uuid, long groupId)
		throws SystemException {
		return fetchByUUID_G(uuid, groupId, true);
	}

	/**
	 * Returns the student class where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @param retrieveFromCache whether to use the finder cache
	 * @return the matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByUUID_G(String uuid, long groupId,
		boolean retrieveFromCache) throws SystemException {
		Object[] finderArgs = new Object[] { uuid, groupId };

		Object result = null;

		if (retrieveFromCache) {
			result = FinderCacheUtil.getResult(FINDER_PATH_FETCH_BY_UUID_G,
					finderArgs, this);
		}

		if (result instanceof StudentClass) {
			StudentClass studentClass = (StudentClass)result;

			if (!Validator.equals(uuid, studentClass.getUuid()) ||
					(groupId != studentClass.getGroupId())) {
				result = null;
			}
		}

		if (result == null) {
			StringBundler query = new StringBundler(4);

			query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_G_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(groupId);

				List<StudentClass> list = q.list();

				if (list.isEmpty()) {
					FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
						finderArgs, list);
				}
				else {
					StudentClass studentClass = list.get(0);

					result = studentClass;

					cacheResult(studentClass);

					if ((studentClass.getUuid() == null) ||
							!studentClass.getUuid().equals(uuid) ||
							(studentClass.getGroupId() != groupId)) {
						FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
							finderArgs, studentClass);
					}
				}
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G,
					finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		if (result instanceof List<?>) {
			return null;
		}
		else {
			return (StudentClass)result;
		}
	}

	/**
	 * Removes the student class where uuid = &#63; and groupId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the student class that was removed
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass removeByUUID_G(String uuid, long groupId)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = findByUUID_G(uuid, groupId);

		return remove(studentClass);
	}

	/**
	 * Returns the number of student classes where uuid = &#63; and groupId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param groupId the group ID
	 * @return the number of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUUID_G(String uuid, long groupId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_G;

		Object[] finderArgs = new Object[] { uuid, groupId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_STUDENTCLASS_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_G_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_G_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_G_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(groupId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_G_UUID_1 = "studentClass.uuid IS NULL AND ";
	private static final String _FINDER_COLUMN_UUID_G_UUID_2 = "studentClass.uuid = ? AND ";
	private static final String _FINDER_COLUMN_UUID_G_UUID_3 = "(studentClass.uuid IS NULL OR studentClass.uuid = '') AND ";
	private static final String _FINDER_COLUMN_UUID_G_GROUPID_2 = "studentClass.groupId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByUuid_C",
			new String[] {
				String.class.getName(), Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C =
		new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByUuid_C",
			new String[] { String.class.getName(), Long.class.getName() },
			StudentClassModelImpl.UUID_COLUMN_BITMASK |
			StudentClassModelImpl.COMPANYID_COLUMN_BITMASK |
			StudentClassModelImpl.FORMNO_COLUMN_BITMASK |
			StudentClassModelImpl.CLASSCODE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_UUID_C = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByUuid_C",
			new String[] { String.class.getName(), Long.class.getName() });

	/**
	 * Returns all the student classes where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByUuid_C(String uuid, long companyId)
		throws SystemException {
		return findByUuid_C(uuid, companyId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the student classes where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @return the range of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByUuid_C(String uuid, long companyId,
		int start, int end) throws SystemException {
		return findByUuid_C(uuid, companyId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the student classes where uuid = &#63; and companyId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByUuid_C(String uuid, long companyId,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C;
			finderArgs = new Object[] { uuid, companyId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_UUID_C;
			finderArgs = new Object[] {
					uuid, companyId,
					
					start, end, orderByComparator
				};
		}

		List<StudentClass> list = (List<StudentClass>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (StudentClass studentClass : list) {
				if (!Validator.equals(uuid, studentClass.getUuid()) ||
						(companyId != studentClass.getCompanyId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_C_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(StudentClassModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(companyId);

				if (!pagination) {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<StudentClass>(list);
				}
				else {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first student class in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByUuid_C_First(String uuid, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByUuid_C_First(uuid, companyId,
				orderByComparator);

		if (studentClass != null) {
			return studentClass;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchStudentClassException(msg.toString());
	}

	/**
	 * Returns the first student class in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByUuid_C_First(String uuid, long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		List<StudentClass> list = findByUuid_C(uuid, companyId, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last student class in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByUuid_C_Last(String uuid, long companyId,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByUuid_C_Last(uuid, companyId,
				orderByComparator);

		if (studentClass != null) {
			return studentClass;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("uuid=");
		msg.append(uuid);

		msg.append(", companyId=");
		msg.append(companyId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchStudentClassException(msg.toString());
	}

	/**
	 * Returns the last student class in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByUuid_C_Last(String uuid, long companyId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByUuid_C(uuid, companyId);

		if (count == 0) {
			return null;
		}

		List<StudentClass> list = findByUuid_C(uuid, companyId, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the student classes before and after the current student class in the ordered set where uuid = &#63; and companyId = &#63;.
	 *
	 * @param classId the primary key of the current student class
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass[] findByUuid_C_PrevAndNext(long classId, String uuid,
		long companyId, OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = findByPrimaryKey(classId);

		Session session = null;

		try {
			session = openSession();

			StudentClass[] array = new StudentClassImpl[3];

			array[0] = getByUuid_C_PrevAndNext(session, studentClass, uuid,
					companyId, orderByComparator, true);

			array[1] = studentClass;

			array[2] = getByUuid_C_PrevAndNext(session, studentClass, uuid,
					companyId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected StudentClass getByUuid_C_PrevAndNext(Session session,
		StudentClass studentClass, String uuid, long companyId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

		boolean bindUuid = false;

		if (uuid == null) {
			query.append(_FINDER_COLUMN_UUID_C_UUID_1);
		}
		else if (uuid.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_UUID_C_UUID_3);
		}
		else {
			bindUuid = true;

			query.append(_FINDER_COLUMN_UUID_C_UUID_2);
		}

		query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(StudentClassModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		if (bindUuid) {
			qPos.add(uuid);
		}

		qPos.add(companyId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(studentClass);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<StudentClass> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the student classes where uuid = &#63; and companyId = &#63; from the database.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByUuid_C(String uuid, long companyId)
		throws SystemException {
		for (StudentClass studentClass : findByUuid_C(uuid, companyId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(studentClass);
		}
	}

	/**
	 * Returns the number of student classes where uuid = &#63; and companyId = &#63;.
	 *
	 * @param uuid the uuid
	 * @param companyId the company ID
	 * @return the number of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByUuid_C(String uuid, long companyId)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_UUID_C;

		Object[] finderArgs = new Object[] { uuid, companyId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_STUDENTCLASS_WHERE);

			boolean bindUuid = false;

			if (uuid == null) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_1);
			}
			else if (uuid.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_UUID_C_UUID_3);
			}
			else {
				bindUuid = true;

				query.append(_FINDER_COLUMN_UUID_C_UUID_2);
			}

			query.append(_FINDER_COLUMN_UUID_C_COMPANYID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				if (bindUuid) {
					qPos.add(uuid);
				}

				qPos.add(companyId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_UUID_C_UUID_1 = "studentClass.uuid IS NULL AND ";
	private static final String _FINDER_COLUMN_UUID_C_UUID_2 = "studentClass.uuid = ? AND ";
	private static final String _FINDER_COLUMN_UUID_C_UUID_3 = "(studentClass.uuid IS NULL OR studentClass.uuid = '') AND ";
	private static final String _FINDER_COLUMN_UUID_C_COMPANYID_2 = "studentClass.companyId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_GROUPID = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByGroupId",
			new String[] {
				Long.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID =
		new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByGroupId",
			new String[] { Long.class.getName() },
			StudentClassModelImpl.GROUPID_COLUMN_BITMASK |
			StudentClassModelImpl.FORMNO_COLUMN_BITMASK |
			StudentClassModelImpl.CLASSCODE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_GROUPID = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByGroupId",
			new String[] { Long.class.getName() });

	/**
	 * Returns all the student classes where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByGroupId(long groupId)
		throws SystemException {
		return findByGroupId(groupId, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the student classes where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @return the range of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByGroupId(long groupId, int start, int end)
		throws SystemException {
		return findByGroupId(groupId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the student classes where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByGroupId(long groupId, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID;
			finderArgs = new Object[] { groupId };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_GROUPID;
			finderArgs = new Object[] { groupId, start, end, orderByComparator };
		}

		List<StudentClass> list = (List<StudentClass>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (StudentClass studentClass : list) {
				if ((groupId != studentClass.getGroupId())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

			query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(StudentClassModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				if (!pagination) {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<StudentClass>(list);
				}
				else {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first student class in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByGroupId_First(long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByGroupId_First(groupId,
				orderByComparator);

		if (studentClass != null) {
			return studentClass;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchStudentClassException(msg.toString());
	}

	/**
	 * Returns the first student class in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByGroupId_First(long groupId,
		OrderByComparator orderByComparator) throws SystemException {
		List<StudentClass> list = findByGroupId(groupId, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last student class in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByGroupId_Last(long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByGroupId_Last(groupId,
				orderByComparator);

		if (studentClass != null) {
			return studentClass;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("groupId=");
		msg.append(groupId);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchStudentClassException(msg.toString());
	}

	/**
	 * Returns the last student class in the ordered set where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByGroupId_Last(long groupId,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByGroupId(groupId);

		if (count == 0) {
			return null;
		}

		List<StudentClass> list = findByGroupId(groupId, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the student classes before and after the current student class in the ordered set where groupId = &#63;.
	 *
	 * @param classId the primary key of the current student class
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass[] findByGroupId_PrevAndNext(long classId, long groupId,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = findByPrimaryKey(classId);

		Session session = null;

		try {
			session = openSession();

			StudentClass[] array = new StudentClassImpl[3];

			array[0] = getByGroupId_PrevAndNext(session, studentClass, groupId,
					orderByComparator, true);

			array[1] = studentClass;

			array[2] = getByGroupId_PrevAndNext(session, studentClass, groupId,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected StudentClass getByGroupId_PrevAndNext(Session session,
		StudentClass studentClass, long groupId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(StudentClassModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(groupId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(studentClass);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<StudentClass> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Returns all the student classes that the user has permission to view where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the matching student classes that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> filterFindByGroupId(long groupId)
		throws SystemException {
		return filterFindByGroupId(groupId, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the student classes that the user has permission to view where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @return the range of matching student classes that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> filterFindByGroupId(long groupId, int start,
		int end) throws SystemException {
		return filterFindByGroupId(groupId, start, end, null);
	}

	/**
	 * Returns an ordered range of all the student classes that the user has permissions to view where groupId = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param groupId the group ID
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching student classes that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> filterFindByGroupId(long groupId, int start,
		int end, OrderByComparator orderByComparator) throws SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return findByGroupId(groupId, start, end, orderByComparator);
		}

		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(3 +
					(orderByComparator.getOrderByFields().length * 3));
		}
		else {
			query = new StringBundler(3);
		}

		if (getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_STUDENTCLASS_WHERE);
		}
		else {
			query.append(_FILTER_SQL_SELECT_STUDENTCLASS_NO_INLINE_DISTINCT_WHERE_1);
		}

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (!getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_STUDENTCLASS_NO_INLINE_DISTINCT_WHERE_2);
		}

		if (orderByComparator != null) {
			if (getDB().isSupportsInlineDistinct()) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator, true);
			}
			else {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_TABLE,
					orderByComparator, true);
			}
		}
		else {
			if (getDB().isSupportsInlineDistinct()) {
				query.append(StudentClassModelImpl.ORDER_BY_JPQL);
			}
			else {
				query.append(StudentClassModelImpl.ORDER_BY_SQL);
			}
		}

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				StudentClass.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		Session session = null;

		try {
			session = openSession();

			SQLQuery q = session.createSQLQuery(sql);

			if (getDB().isSupportsInlineDistinct()) {
				q.addEntity(_FILTER_ENTITY_ALIAS, StudentClassImpl.class);
			}
			else {
				q.addEntity(_FILTER_ENTITY_TABLE, StudentClassImpl.class);
			}

			QueryPos qPos = QueryPos.getInstance(q);

			qPos.add(groupId);

			return (List<StudentClass>)QueryUtil.list(q, getDialect(), start,
				end);
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	/**
	 * Returns the student classes before and after the current student class in the ordered set of student classes that the user has permission to view where groupId = &#63;.
	 *
	 * @param classId the primary key of the current student class
	 * @param groupId the group ID
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass[] filterFindByGroupId_PrevAndNext(long classId,
		long groupId, OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return findByGroupId_PrevAndNext(classId, groupId, orderByComparator);
		}

		StudentClass studentClass = findByPrimaryKey(classId);

		Session session = null;

		try {
			session = openSession();

			StudentClass[] array = new StudentClassImpl[3];

			array[0] = filterGetByGroupId_PrevAndNext(session, studentClass,
					groupId, orderByComparator, true);

			array[1] = studentClass;

			array[2] = filterGetByGroupId_PrevAndNext(session, studentClass,
					groupId, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected StudentClass filterGetByGroupId_PrevAndNext(Session session,
		StudentClass studentClass, long groupId,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		if (getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_STUDENTCLASS_WHERE);
		}
		else {
			query.append(_FILTER_SQL_SELECT_STUDENTCLASS_NO_INLINE_DISTINCT_WHERE_1);
		}

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		if (!getDB().isSupportsInlineDistinct()) {
			query.append(_FILTER_SQL_SELECT_STUDENTCLASS_NO_INLINE_DISTINCT_WHERE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				if (getDB().isSupportsInlineDistinct()) {
					query.append(_ORDER_BY_ENTITY_ALIAS);
				}
				else {
					query.append(_ORDER_BY_ENTITY_TABLE);
				}

				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				if (getDB().isSupportsInlineDistinct()) {
					query.append(_ORDER_BY_ENTITY_ALIAS);
				}
				else {
					query.append(_ORDER_BY_ENTITY_TABLE);
				}

				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			if (getDB().isSupportsInlineDistinct()) {
				query.append(StudentClassModelImpl.ORDER_BY_JPQL);
			}
			else {
				query.append(StudentClassModelImpl.ORDER_BY_SQL);
			}
		}

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				StudentClass.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		SQLQuery q = session.createSQLQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		if (getDB().isSupportsInlineDistinct()) {
			q.addEntity(_FILTER_ENTITY_ALIAS, StudentClassImpl.class);
		}
		else {
			q.addEntity(_FILTER_ENTITY_TABLE, StudentClassImpl.class);
		}

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(groupId);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(studentClass);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<StudentClass> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the student classes where groupId = &#63; from the database.
	 *
	 * @param groupId the group ID
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByGroupId(long groupId) throws SystemException {
		for (StudentClass studentClass : findByGroupId(groupId,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(studentClass);
		}
	}

	/**
	 * Returns the number of student classes where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the number of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByGroupId(long groupId) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_GROUPID;

		Object[] finderArgs = new Object[] { groupId };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_STUDENTCLASS_WHERE);

			query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(groupId);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	/**
	 * Returns the number of student classes that the user has permission to view where groupId = &#63;.
	 *
	 * @param groupId the group ID
	 * @return the number of matching student classes that the user has permission to view
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int filterCountByGroupId(long groupId) throws SystemException {
		if (!InlineSQLHelperUtil.isEnabled(groupId)) {
			return countByGroupId(groupId);
		}

		StringBundler query = new StringBundler(2);

		query.append(_FILTER_SQL_COUNT_STUDENTCLASS_WHERE);

		query.append(_FINDER_COLUMN_GROUPID_GROUPID_2);

		String sql = InlineSQLHelperUtil.replacePermissionCheck(query.toString(),
				StudentClass.class.getName(),
				_FILTER_ENTITY_TABLE_FILTER_PK_COLUMN, groupId);

		Session session = null;

		try {
			session = openSession();

			SQLQuery q = session.createSQLQuery(sql);

			q.addScalar(COUNT_COLUMN_NAME,
				com.liferay.portal.kernel.dao.orm.Type.LONG);

			QueryPos qPos = QueryPos.getInstance(q);

			qPos.add(groupId);

			Long count = (Long)q.uniqueResult();

			return count.intValue();
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	private static final String _FINDER_COLUMN_GROUPID_GROUPID_2 = "studentClass.groupId = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_FORMNO = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByFormNo",
			new String[] {
				Integer.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORMNO =
		new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByFormNo",
			new String[] { Integer.class.getName() },
			StudentClassModelImpl.FORMNO_COLUMN_BITMASK |
			StudentClassModelImpl.CLASSCODE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_FORMNO = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByFormNo",
			new String[] { Integer.class.getName() });

	/**
	 * Returns all the student classes where formNo = &#63;.
	 *
	 * @param formNo the form no
	 * @return the matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByFormNo(int formNo)
		throws SystemException {
		return findByFormNo(formNo, QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the student classes where formNo = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param formNo the form no
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @return the range of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByFormNo(int formNo, int start, int end)
		throws SystemException {
		return findByFormNo(formNo, start, end, null);
	}

	/**
	 * Returns an ordered range of all the student classes where formNo = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param formNo the form no
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByFormNo(int formNo, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORMNO;
			finderArgs = new Object[] { formNo };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_FORMNO;
			finderArgs = new Object[] { formNo, start, end, orderByComparator };
		}

		List<StudentClass> list = (List<StudentClass>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (StudentClass studentClass : list) {
				if ((formNo != studentClass.getFormNo())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(3 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(3);
			}

			query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

			query.append(_FINDER_COLUMN_FORMNO_FORMNO_2);

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(StudentClassModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(formNo);

				if (!pagination) {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<StudentClass>(list);
				}
				else {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first student class in the ordered set where formNo = &#63;.
	 *
	 * @param formNo the form no
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByFormNo_First(int formNo,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByFormNo_First(formNo,
				orderByComparator);

		if (studentClass != null) {
			return studentClass;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("formNo=");
		msg.append(formNo);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchStudentClassException(msg.toString());
	}

	/**
	 * Returns the first student class in the ordered set where formNo = &#63;.
	 *
	 * @param formNo the form no
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByFormNo_First(int formNo,
		OrderByComparator orderByComparator) throws SystemException {
		List<StudentClass> list = findByFormNo(formNo, 0, 1, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last student class in the ordered set where formNo = &#63;.
	 *
	 * @param formNo the form no
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByFormNo_Last(int formNo,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByFormNo_Last(formNo, orderByComparator);

		if (studentClass != null) {
			return studentClass;
		}

		StringBundler msg = new StringBundler(4);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("formNo=");
		msg.append(formNo);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchStudentClassException(msg.toString());
	}

	/**
	 * Returns the last student class in the ordered set where formNo = &#63;.
	 *
	 * @param formNo the form no
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByFormNo_Last(int formNo,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByFormNo(formNo);

		if (count == 0) {
			return null;
		}

		List<StudentClass> list = findByFormNo(formNo, count - 1, count,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the student classes before and after the current student class in the ordered set where formNo = &#63;.
	 *
	 * @param classId the primary key of the current student class
	 * @param formNo the form no
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass[] findByFormNo_PrevAndNext(long classId, int formNo,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = findByPrimaryKey(classId);

		Session session = null;

		try {
			session = openSession();

			StudentClass[] array = new StudentClassImpl[3];

			array[0] = getByFormNo_PrevAndNext(session, studentClass, formNo,
					orderByComparator, true);

			array[1] = studentClass;

			array[2] = getByFormNo_PrevAndNext(session, studentClass, formNo,
					orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected StudentClass getByFormNo_PrevAndNext(Session session,
		StudentClass studentClass, int formNo,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

		query.append(_FINDER_COLUMN_FORMNO_FORMNO_2);

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(StudentClassModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(formNo);

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(studentClass);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<StudentClass> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the student classes where formNo = &#63; from the database.
	 *
	 * @param formNo the form no
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByFormNo(int formNo) throws SystemException {
		for (StudentClass studentClass : findByFormNo(formNo,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(studentClass);
		}
	}

	/**
	 * Returns the number of student classes where formNo = &#63;.
	 *
	 * @param formNo the form no
	 * @return the number of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByFormNo(int formNo) throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_FORMNO;

		Object[] finderArgs = new Object[] { formNo };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(2);

			query.append(_SQL_COUNT_STUDENTCLASS_WHERE);

			query.append(_FINDER_COLUMN_FORMNO_FORMNO_2);

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(formNo);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_FORMNO_FORMNO_2 = "studentClass.formNo = ?";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_BY_FORMCLASS =
		new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findByFormClass",
			new String[] {
				Integer.class.getName(), String.class.getName(),
				
			Integer.class.getName(), Integer.class.getName(),
				OrderByComparator.class.getName()
			});
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORMCLASS =
		new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, StudentClassImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findByFormClass",
			new String[] { Integer.class.getName(), String.class.getName() },
			StudentClassModelImpl.FORMNO_COLUMN_BITMASK |
			StudentClassModelImpl.CLASSCODE_COLUMN_BITMASK);
	public static final FinderPath FINDER_PATH_COUNT_BY_FORMCLASS = new FinderPath(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countByFormClass",
			new String[] { Integer.class.getName(), String.class.getName() });

	/**
	 * Returns all the student classes where formNo = &#63; and classCode = &#63;.
	 *
	 * @param formNo the form no
	 * @param classCode the class code
	 * @return the matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByFormClass(int formNo, String classCode)
		throws SystemException {
		return findByFormClass(formNo, classCode, QueryUtil.ALL_POS,
			QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the student classes where formNo = &#63; and classCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param formNo the form no
	 * @param classCode the class code
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @return the range of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByFormClass(int formNo, String classCode,
		int start, int end) throws SystemException {
		return findByFormClass(formNo, classCode, start, end, null);
	}

	/**
	 * Returns an ordered range of all the student classes where formNo = &#63; and classCode = &#63;.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param formNo the form no
	 * @param classCode the class code
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findByFormClass(int formNo, String classCode,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORMCLASS;
			finderArgs = new Object[] { formNo, classCode };
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_BY_FORMCLASS;
			finderArgs = new Object[] {
					formNo, classCode,
					
					start, end, orderByComparator
				};
		}

		List<StudentClass> list = (List<StudentClass>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if ((list != null) && !list.isEmpty()) {
			for (StudentClass studentClass : list) {
				if ((formNo != studentClass.getFormNo()) ||
						!Validator.equals(classCode, studentClass.getClassCode())) {
					list = null;

					break;
				}
			}
		}

		if (list == null) {
			StringBundler query = null;

			if (orderByComparator != null) {
				query = new StringBundler(4 +
						(orderByComparator.getOrderByFields().length * 3));
			}
			else {
				query = new StringBundler(4);
			}

			query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

			query.append(_FINDER_COLUMN_FORMCLASS_FORMNO_2);

			boolean bindClassCode = false;

			if (classCode == null) {
				query.append(_FINDER_COLUMN_FORMCLASS_CLASSCODE_1);
			}
			else if (classCode.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FORMCLASS_CLASSCODE_3);
			}
			else {
				bindClassCode = true;

				query.append(_FINDER_COLUMN_FORMCLASS_CLASSCODE_2);
			}

			if (orderByComparator != null) {
				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);
			}
			else
			 if (pagination) {
				query.append(StudentClassModelImpl.ORDER_BY_JPQL);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(formNo);

				if (bindClassCode) {
					qPos.add(classCode);
				}

				if (!pagination) {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<StudentClass>(list);
				}
				else {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Returns the first student class in the ordered set where formNo = &#63; and classCode = &#63;.
	 *
	 * @param formNo the form no
	 * @param classCode the class code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByFormClass_First(int formNo, String classCode,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByFormClass_First(formNo, classCode,
				orderByComparator);

		if (studentClass != null) {
			return studentClass;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("formNo=");
		msg.append(formNo);

		msg.append(", classCode=");
		msg.append(classCode);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchStudentClassException(msg.toString());
	}

	/**
	 * Returns the first student class in the ordered set where formNo = &#63; and classCode = &#63;.
	 *
	 * @param formNo the form no
	 * @param classCode the class code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the first matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByFormClass_First(int formNo, String classCode,
		OrderByComparator orderByComparator) throws SystemException {
		List<StudentClass> list = findByFormClass(formNo, classCode, 0, 1,
				orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the last student class in the ordered set where formNo = &#63; and classCode = &#63;.
	 *
	 * @param formNo the form no
	 * @param classCode the class code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByFormClass_Last(int formNo, String classCode,
		OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByFormClass_Last(formNo, classCode,
				orderByComparator);

		if (studentClass != null) {
			return studentClass;
		}

		StringBundler msg = new StringBundler(6);

		msg.append(_NO_SUCH_ENTITY_WITH_KEY);

		msg.append("formNo=");
		msg.append(formNo);

		msg.append(", classCode=");
		msg.append(classCode);

		msg.append(StringPool.CLOSE_CURLY_BRACE);

		throw new NoSuchStudentClassException(msg.toString());
	}

	/**
	 * Returns the last student class in the ordered set where formNo = &#63; and classCode = &#63;.
	 *
	 * @param formNo the form no
	 * @param classCode the class code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the last matching student class, or <code>null</code> if a matching student class could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByFormClass_Last(int formNo, String classCode,
		OrderByComparator orderByComparator) throws SystemException {
		int count = countByFormClass(formNo, classCode);

		if (count == 0) {
			return null;
		}

		List<StudentClass> list = findByFormClass(formNo, classCode, count - 1,
				count, orderByComparator);

		if (!list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	/**
	 * Returns the student classes before and after the current student class in the ordered set where formNo = &#63; and classCode = &#63;.
	 *
	 * @param classId the primary key of the current student class
	 * @param formNo the form no
	 * @param classCode the class code
	 * @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	 * @return the previous, current, and next student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass[] findByFormClass_PrevAndNext(long classId, int formNo,
		String classCode, OrderByComparator orderByComparator)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = findByPrimaryKey(classId);

		Session session = null;

		try {
			session = openSession();

			StudentClass[] array = new StudentClassImpl[3];

			array[0] = getByFormClass_PrevAndNext(session, studentClass,
					formNo, classCode, orderByComparator, true);

			array[1] = studentClass;

			array[2] = getByFormClass_PrevAndNext(session, studentClass,
					formNo, classCode, orderByComparator, false);

			return array;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	protected StudentClass getByFormClass_PrevAndNext(Session session,
		StudentClass studentClass, int formNo, String classCode,
		OrderByComparator orderByComparator, boolean previous) {
		StringBundler query = null;

		if (orderByComparator != null) {
			query = new StringBundler(6 +
					(orderByComparator.getOrderByFields().length * 6));
		}
		else {
			query = new StringBundler(3);
		}

		query.append(_SQL_SELECT_STUDENTCLASS_WHERE);

		query.append(_FINDER_COLUMN_FORMCLASS_FORMNO_2);

		boolean bindClassCode = false;

		if (classCode == null) {
			query.append(_FINDER_COLUMN_FORMCLASS_CLASSCODE_1);
		}
		else if (classCode.equals(StringPool.BLANK)) {
			query.append(_FINDER_COLUMN_FORMCLASS_CLASSCODE_3);
		}
		else {
			bindClassCode = true;

			query.append(_FINDER_COLUMN_FORMCLASS_CLASSCODE_2);
		}

		if (orderByComparator != null) {
			String[] orderByConditionFields = orderByComparator.getOrderByConditionFields();

			if (orderByConditionFields.length > 0) {
				query.append(WHERE_AND);
			}

			for (int i = 0; i < orderByConditionFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByConditionFields[i]);

				if ((i + 1) < orderByConditionFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN_HAS_NEXT);
					}
					else {
						query.append(WHERE_LESSER_THAN_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(WHERE_GREATER_THAN);
					}
					else {
						query.append(WHERE_LESSER_THAN);
					}
				}
			}

			query.append(ORDER_BY_CLAUSE);

			String[] orderByFields = orderByComparator.getOrderByFields();

			for (int i = 0; i < orderByFields.length; i++) {
				query.append(_ORDER_BY_ENTITY_ALIAS);
				query.append(orderByFields[i]);

				if ((i + 1) < orderByFields.length) {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC_HAS_NEXT);
					}
					else {
						query.append(ORDER_BY_DESC_HAS_NEXT);
					}
				}
				else {
					if (orderByComparator.isAscending() ^ previous) {
						query.append(ORDER_BY_ASC);
					}
					else {
						query.append(ORDER_BY_DESC);
					}
				}
			}
		}
		else {
			query.append(StudentClassModelImpl.ORDER_BY_JPQL);
		}

		String sql = query.toString();

		Query q = session.createQuery(sql);

		q.setFirstResult(0);
		q.setMaxResults(2);

		QueryPos qPos = QueryPos.getInstance(q);

		qPos.add(formNo);

		if (bindClassCode) {
			qPos.add(classCode);
		}

		if (orderByComparator != null) {
			Object[] values = orderByComparator.getOrderByConditionValues(studentClass);

			for (Object value : values) {
				qPos.add(value);
			}
		}

		List<StudentClass> list = q.list();

		if (list.size() == 2) {
			return list.get(1);
		}
		else {
			return null;
		}
	}

	/**
	 * Removes all the student classes where formNo = &#63; and classCode = &#63; from the database.
	 *
	 * @param formNo the form no
	 * @param classCode the class code
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeByFormClass(int formNo, String classCode)
		throws SystemException {
		for (StudentClass studentClass : findByFormClass(formNo, classCode,
				QueryUtil.ALL_POS, QueryUtil.ALL_POS, null)) {
			remove(studentClass);
		}
	}

	/**
	 * Returns the number of student classes where formNo = &#63; and classCode = &#63;.
	 *
	 * @param formNo the form no
	 * @param classCode the class code
	 * @return the number of matching student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countByFormClass(int formNo, String classCode)
		throws SystemException {
		FinderPath finderPath = FINDER_PATH_COUNT_BY_FORMCLASS;

		Object[] finderArgs = new Object[] { formNo, classCode };

		Long count = (Long)FinderCacheUtil.getResult(finderPath, finderArgs,
				this);

		if (count == null) {
			StringBundler query = new StringBundler(3);

			query.append(_SQL_COUNT_STUDENTCLASS_WHERE);

			query.append(_FINDER_COLUMN_FORMCLASS_FORMNO_2);

			boolean bindClassCode = false;

			if (classCode == null) {
				query.append(_FINDER_COLUMN_FORMCLASS_CLASSCODE_1);
			}
			else if (classCode.equals(StringPool.BLANK)) {
				query.append(_FINDER_COLUMN_FORMCLASS_CLASSCODE_3);
			}
			else {
				bindClassCode = true;

				query.append(_FINDER_COLUMN_FORMCLASS_CLASSCODE_2);
			}

			String sql = query.toString();

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				QueryPos qPos = QueryPos.getInstance(q);

				qPos.add(formNo);

				if (bindClassCode) {
					qPos.add(classCode);
				}

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(finderPath, finderArgs, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	private static final String _FINDER_COLUMN_FORMCLASS_FORMNO_2 = "studentClass.formNo = ? AND ";
	private static final String _FINDER_COLUMN_FORMCLASS_CLASSCODE_1 = "studentClass.classCode IS NULL";
	private static final String _FINDER_COLUMN_FORMCLASS_CLASSCODE_2 = "studentClass.classCode = ?";
	private static final String _FINDER_COLUMN_FORMCLASS_CLASSCODE_3 = "(studentClass.classCode IS NULL OR studentClass.classCode = '')";

	public StudentClassPersistenceImpl() {
		setModelClass(StudentClass.class);
	}

	/**
	 * Caches the student class in the entity cache if it is enabled.
	 *
	 * @param studentClass the student class
	 */
	@Override
	public void cacheResult(StudentClass studentClass) {
		EntityCacheUtil.putResult(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassImpl.class, studentClass.getPrimaryKey(), studentClass);

		FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G,
			new Object[] { studentClass.getUuid(), studentClass.getGroupId() },
			studentClass);

		studentClass.resetOriginalValues();
	}

	/**
	 * Caches the student classes in the entity cache if it is enabled.
	 *
	 * @param studentClasses the student classes
	 */
	@Override
	public void cacheResult(List<StudentClass> studentClasses) {
		for (StudentClass studentClass : studentClasses) {
			if (EntityCacheUtil.getResult(
						StudentClassModelImpl.ENTITY_CACHE_ENABLED,
						StudentClassImpl.class, studentClass.getPrimaryKey()) == null) {
				cacheResult(studentClass);
			}
			else {
				studentClass.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all student classes.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		if (_HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE) {
			CacheRegistryUtil.clear(StudentClassImpl.class.getName());
		}

		EntityCacheUtil.clearCache(StudentClassImpl.class.getName());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the student class.
	 *
	 * <p>
	 * The {@link com.liferay.portal.kernel.dao.orm.EntityCache} and {@link com.liferay.portal.kernel.dao.orm.FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(StudentClass studentClass) {
		EntityCacheUtil.removeResult(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassImpl.class, studentClass.getPrimaryKey());

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		clearUniqueFindersCache(studentClass);
	}

	@Override
	public void clearCache(List<StudentClass> studentClasses) {
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (StudentClass studentClass : studentClasses) {
			EntityCacheUtil.removeResult(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
				StudentClassImpl.class, studentClass.getPrimaryKey());

			clearUniqueFindersCache(studentClass);
		}
	}

	protected void cacheUniqueFindersCache(StudentClass studentClass) {
		if (studentClass.isNew()) {
			Object[] args = new Object[] {
					studentClass.getUuid(), studentClass.getGroupId()
				};

			FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
				Long.valueOf(1));
			FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
				studentClass);
		}
		else {
			StudentClassModelImpl studentClassModelImpl = (StudentClassModelImpl)studentClass;

			if ((studentClassModelImpl.getColumnBitmask() &
					FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						studentClass.getUuid(), studentClass.getGroupId()
					};

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_BY_UUID_G, args,
					Long.valueOf(1));
				FinderCacheUtil.putResult(FINDER_PATH_FETCH_BY_UUID_G, args,
					studentClass);
			}
		}
	}

	protected void clearUniqueFindersCache(StudentClass studentClass) {
		StudentClassModelImpl studentClassModelImpl = (StudentClassModelImpl)studentClass;

		Object[] args = new Object[] {
				studentClass.getUuid(), studentClass.getGroupId()
			};

		FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
		FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);

		if ((studentClassModelImpl.getColumnBitmask() &
				FINDER_PATH_FETCH_BY_UUID_G.getColumnBitmask()) != 0) {
			args = new Object[] {
					studentClassModelImpl.getOriginalUuid(),
					studentClassModelImpl.getOriginalGroupId()
				};

			FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_G, args);
			FinderCacheUtil.removeResult(FINDER_PATH_FETCH_BY_UUID_G, args);
		}
	}

	/**
	 * Creates a new student class with the primary key. Does not add the student class to the database.
	 *
	 * @param classId the primary key for the new student class
	 * @return the new student class
	 */
	@Override
	public StudentClass create(long classId) {
		StudentClass studentClass = new StudentClassImpl();

		studentClass.setNew(true);
		studentClass.setPrimaryKey(classId);

		String uuid = PortalUUIDUtil.generate();

		studentClass.setUuid(uuid);

		return studentClass;
	}

	/**
	 * Removes the student class with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param classId the primary key of the student class
	 * @return the student class that was removed
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass remove(long classId)
		throws NoSuchStudentClassException, SystemException {
		return remove((Serializable)classId);
	}

	/**
	 * Removes the student class with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the student class
	 * @return the student class that was removed
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass remove(Serializable primaryKey)
		throws NoSuchStudentClassException, SystemException {
		Session session = null;

		try {
			session = openSession();

			StudentClass studentClass = (StudentClass)session.get(StudentClassImpl.class,
					primaryKey);

			if (studentClass == null) {
				if (_log.isWarnEnabled()) {
					_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchStudentClassException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(studentClass);
		}
		catch (NoSuchStudentClassException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected StudentClass removeImpl(StudentClass studentClass)
		throws SystemException {
		studentClass = toUnwrappedModel(studentClass);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(studentClass)) {
				studentClass = (StudentClass)session.get(StudentClassImpl.class,
						studentClass.getPrimaryKeyObj());
			}

			if (studentClass != null) {
				session.delete(studentClass);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (studentClass != null) {
			clearCache(studentClass);
		}

		return studentClass;
	}

	@Override
	public StudentClass updateImpl(com.qc.qcsms.model.StudentClass studentClass)
		throws SystemException {
		studentClass = toUnwrappedModel(studentClass);

		boolean isNew = studentClass.isNew();

		StudentClassModelImpl studentClassModelImpl = (StudentClassModelImpl)studentClass;

		if (Validator.isNull(studentClass.getUuid())) {
			String uuid = PortalUUIDUtil.generate();

			studentClass.setUuid(uuid);
		}

		Session session = null;

		try {
			session = openSession();

			if (studentClass.isNew()) {
				session.save(studentClass);

				studentClass.setNew(false);
			}
			else {
				session.merge(studentClass);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew || !StudentClassModelImpl.COLUMN_BITMASK_ENABLED) {
			FinderCacheUtil.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
		}

		else {
			if ((studentClassModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						studentClassModelImpl.getOriginalUuid()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);

				args = new Object[] { studentClassModelImpl.getUuid() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID,
					args);
			}

			if ((studentClassModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						studentClassModelImpl.getOriginalUuid(),
						studentClassModelImpl.getOriginalCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
					args);

				args = new Object[] {
						studentClassModelImpl.getUuid(),
						studentClassModelImpl.getCompanyId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_UUID_C, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_UUID_C,
					args);
			}

			if ((studentClassModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						studentClassModelImpl.getOriginalGroupId()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_GROUPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID,
					args);

				args = new Object[] { studentClassModelImpl.getGroupId() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_GROUPID, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_GROUPID,
					args);
			}

			if ((studentClassModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORMNO.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						studentClassModelImpl.getOriginalFormNo()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_FORMNO, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORMNO,
					args);

				args = new Object[] { studentClassModelImpl.getFormNo() };

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_FORMNO, args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORMNO,
					args);
			}

			if ((studentClassModelImpl.getColumnBitmask() &
					FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORMCLASS.getColumnBitmask()) != 0) {
				Object[] args = new Object[] {
						studentClassModelImpl.getOriginalFormNo(),
						studentClassModelImpl.getOriginalClassCode()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_FORMCLASS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORMCLASS,
					args);

				args = new Object[] {
						studentClassModelImpl.getFormNo(),
						studentClassModelImpl.getClassCode()
					};

				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_BY_FORMCLASS,
					args);
				FinderCacheUtil.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_BY_FORMCLASS,
					args);
			}
		}

		EntityCacheUtil.putResult(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
			StudentClassImpl.class, studentClass.getPrimaryKey(), studentClass);

		clearUniqueFindersCache(studentClass);
		cacheUniqueFindersCache(studentClass);

		return studentClass;
	}

	protected StudentClass toUnwrappedModel(StudentClass studentClass) {
		if (studentClass instanceof StudentClassImpl) {
			return studentClass;
		}

		StudentClassImpl studentClassImpl = new StudentClassImpl();

		studentClassImpl.setNew(studentClass.isNew());
		studentClassImpl.setPrimaryKey(studentClass.getPrimaryKey());

		studentClassImpl.setUuid(studentClass.getUuid());
		studentClassImpl.setClassId(studentClass.getClassId());
		studentClassImpl.setFormNo(studentClass.getFormNo());
		studentClassImpl.setClassCode(studentClass.getClassCode());
		studentClassImpl.setGroupId(studentClass.getGroupId());
		studentClassImpl.setCompanyId(studentClass.getCompanyId());
		studentClassImpl.setUserId(studentClass.getUserId());
		studentClassImpl.setUserName(studentClass.getUserName());
		studentClassImpl.setCreateDate(studentClass.getCreateDate());
		studentClassImpl.setModifiedDate(studentClass.getModifiedDate());

		return studentClassImpl;
	}

	/**
	 * Returns the student class with the primary key or throws a {@link com.liferay.portal.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the student class
	 * @return the student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByPrimaryKey(Serializable primaryKey)
		throws NoSuchStudentClassException, SystemException {
		StudentClass studentClass = fetchByPrimaryKey(primaryKey);

		if (studentClass == null) {
			if (_log.isWarnEnabled()) {
				_log.warn(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchStudentClassException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return studentClass;
	}

	/**
	 * Returns the student class with the primary key or throws a {@link com.qc.qcsms.NoSuchStudentClassException} if it could not be found.
	 *
	 * @param classId the primary key of the student class
	 * @return the student class
	 * @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass findByPrimaryKey(long classId)
		throws NoSuchStudentClassException, SystemException {
		return findByPrimaryKey((Serializable)classId);
	}

	/**
	 * Returns the student class with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the student class
	 * @return the student class, or <code>null</code> if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByPrimaryKey(Serializable primaryKey)
		throws SystemException {
		StudentClass studentClass = (StudentClass)EntityCacheUtil.getResult(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
				StudentClassImpl.class, primaryKey);

		if (studentClass == _nullStudentClass) {
			return null;
		}

		if (studentClass == null) {
			Session session = null;

			try {
				session = openSession();

				studentClass = (StudentClass)session.get(StudentClassImpl.class,
						primaryKey);

				if (studentClass != null) {
					cacheResult(studentClass);
				}
				else {
					EntityCacheUtil.putResult(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
						StudentClassImpl.class, primaryKey, _nullStudentClass);
				}
			}
			catch (Exception e) {
				EntityCacheUtil.removeResult(StudentClassModelImpl.ENTITY_CACHE_ENABLED,
					StudentClassImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return studentClass;
	}

	/**
	 * Returns the student class with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param classId the primary key of the student class
	 * @return the student class, or <code>null</code> if a student class with the primary key could not be found
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public StudentClass fetchByPrimaryKey(long classId)
		throws SystemException {
		return fetchByPrimaryKey((Serializable)classId);
	}

	/**
	 * Returns all the student classes.
	 *
	 * @return the student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findAll() throws SystemException {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the student classes.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @return the range of student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findAll(int start, int end)
		throws SystemException {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the student classes.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of student classes
	 * @param end the upper bound of the range of student classes (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public List<StudentClass> findAll(int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<StudentClass> list = (List<StudentClass>)FinderCacheUtil.getResult(finderPath,
				finderArgs, this);

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 3));

				query.append(_SQL_SELECT_STUDENTCLASS);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_STUDENTCLASS;

				if (pagination) {
					sql = sql.concat(StudentClassModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = new UnmodifiableList<StudentClass>(list);
				}
				else {
					list = (List<StudentClass>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				FinderCacheUtil.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the student classes from the database.
	 *
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public void removeAll() throws SystemException {
		for (StudentClass studentClass : findAll()) {
			remove(studentClass);
		}
	}

	/**
	 * Returns the number of student classes.
	 *
	 * @return the number of student classes
	 * @throws SystemException if a system exception occurred
	 */
	@Override
	public int countAll() throws SystemException {
		Long count = (Long)FinderCacheUtil.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_STUDENTCLASS);

				count = (Long)q.uniqueResult();

				FinderCacheUtil.putResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY, count);
			}
			catch (Exception e) {
				FinderCacheUtil.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	/**
	 * Initializes the student class persistence.
	 */
	public void afterPropertiesSet() {
		String[] listenerClassNames = StringUtil.split(GetterUtil.getString(
					com.liferay.util.service.ServiceProps.get(
						"value.object.listener.com.qc.qcsms.model.StudentClass")));

		if (listenerClassNames.length > 0) {
			try {
				List<ModelListener<StudentClass>> listenersList = new ArrayList<ModelListener<StudentClass>>();

				for (String listenerClassName : listenerClassNames) {
					listenersList.add((ModelListener<StudentClass>)InstanceFactory.newInstance(
							getClassLoader(), listenerClassName));
				}

				listeners = listenersList.toArray(new ModelListener[listenersList.size()]);
			}
			catch (Exception e) {
				_log.error(e);
			}
		}
	}

	public void destroy() {
		EntityCacheUtil.removeCache(StudentClassImpl.class.getName());
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_ENTITY);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		FinderCacheUtil.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	private static final String _SQL_SELECT_STUDENTCLASS = "SELECT studentClass FROM StudentClass studentClass";
	private static final String _SQL_SELECT_STUDENTCLASS_WHERE = "SELECT studentClass FROM StudentClass studentClass WHERE ";
	private static final String _SQL_COUNT_STUDENTCLASS = "SELECT COUNT(studentClass) FROM StudentClass studentClass";
	private static final String _SQL_COUNT_STUDENTCLASS_WHERE = "SELECT COUNT(studentClass) FROM StudentClass studentClass WHERE ";
	private static final String _FILTER_ENTITY_TABLE_FILTER_PK_COLUMN = "studentClass.classId";
	private static final String _FILTER_SQL_SELECT_STUDENTCLASS_WHERE = "SELECT DISTINCT {studentClass.*} FROM QC_StudentClass studentClass WHERE ";
	private static final String _FILTER_SQL_SELECT_STUDENTCLASS_NO_INLINE_DISTINCT_WHERE_1 =
		"SELECT {QC_StudentClass.*} FROM (SELECT DISTINCT studentClass.classId FROM QC_StudentClass studentClass WHERE ";
	private static final String _FILTER_SQL_SELECT_STUDENTCLASS_NO_INLINE_DISTINCT_WHERE_2 =
		") TEMP_TABLE INNER JOIN QC_StudentClass ON TEMP_TABLE.classId = QC_StudentClass.classId";
	private static final String _FILTER_SQL_COUNT_STUDENTCLASS_WHERE = "SELECT COUNT(DISTINCT studentClass.classId) AS COUNT_VALUE FROM QC_StudentClass studentClass WHERE ";
	private static final String _FILTER_ENTITY_ALIAS = "studentClass";
	private static final String _FILTER_ENTITY_TABLE = "QC_StudentClass";
	private static final String _ORDER_BY_ENTITY_ALIAS = "studentClass.";
	private static final String _ORDER_BY_ENTITY_TABLE = "QC_StudentClass.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No StudentClass exists with the primary key ";
	private static final String _NO_SUCH_ENTITY_WITH_KEY = "No StudentClass exists with the key {";
	private static final boolean _HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = GetterUtil.getBoolean(PropsUtil.get(
				PropsKeys.HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE));
	private static Log _log = LogFactoryUtil.getLog(StudentClassPersistenceImpl.class);
	private static Set<String> _badColumnNames = SetUtil.fromArray(new String[] {
				"uuid"
			});
	private static StudentClass _nullStudentClass = new StudentClassImpl() {
			@Override
			public Object clone() {
				return this;
			}

			@Override
			public CacheModel<StudentClass> toCacheModel() {
				return _nullStudentClassCacheModel;
			}
		};

	private static CacheModel<StudentClass> _nullStudentClassCacheModel = new CacheModel<StudentClass>() {
			@Override
			public StudentClass toEntityModel() {
				return _nullStudentClass;
			}
		};
}