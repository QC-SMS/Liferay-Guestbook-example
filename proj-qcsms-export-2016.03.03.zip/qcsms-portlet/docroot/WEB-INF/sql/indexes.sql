create index IX_CED624BF on QC_DisciplineCode (assignedCode);
create index IX_B9C9E392 on QC_DisciplineCode (code_);
create index IX_F3A2DC61 on QC_DisciplineCode (disciplineCode);
create index IX_59C559FA on QC_DisciplineCode (groupId);
create index IX_58D72761 on QC_DisciplineCode (severity);
create index IX_7C7D2304 on QC_DisciplineCode (uuid_);
create index IX_93F96A4 on QC_DisciplineCode (uuid_, companyId);
create unique index IX_BE457626 on QC_DisciplineCode (uuid_, groupId);

create index IX_4463046F on QC_Student (classId);
create index IX_6F1FABA on QC_Student (classId, classNo);
create index IX_446FF722 on QC_Student (classes);
create index IX_EC9275F6 on QC_Student (groupId);
create index IX_26990E00 on QC_Student (uuid_);
create index IX_844C3628 on QC_Student (uuid_, companyId);
create unique index IX_DC3C26AA on QC_Student (uuid_, groupId);

create index IX_98323A49 on QC_StudentClass (formNo);
create index IX_D908D80C on QC_StudentClass (formNo, classCode);
create index IX_AABFCC3A on QC_StudentClass (groupId);
create index IX_61EF2544 on QC_StudentClass (uuid_);
create index IX_F841AC64 on QC_StudentClass (uuid_, companyId);
create unique index IX_7E51FBE6 on QC_StudentClass (uuid_, groupId);