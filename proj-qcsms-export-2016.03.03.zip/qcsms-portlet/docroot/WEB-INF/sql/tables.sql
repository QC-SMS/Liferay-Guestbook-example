create table QC_DisciplineCode (
	uuid_ VARCHAR(75) null,
	disciplineCodeId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	assignedCode VARCHAR(75) null,
	description VARCHAR(75) null,
	severity VARCHAR(75) null
);

create table QC_Student (
	uuid_ VARCHAR(75) null,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null,
	studentId LONG not null primary key,
	classId LONG,
	studentName VARCHAR(75) null,
	classNo INTEGER
);

create table QC_StudentClass (
	uuid_ VARCHAR(75) null,
	classId LONG not null primary key,
	formNo INTEGER,
	classCode VARCHAR(75) null,
	groupId LONG,
	companyId LONG,
	userId LONG,
	userName VARCHAR(75) null,
	createDate DATE null,
	modifiedDate DATE null
);