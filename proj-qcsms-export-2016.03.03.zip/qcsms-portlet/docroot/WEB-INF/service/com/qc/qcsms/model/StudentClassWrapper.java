/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link StudentClass}.
 * </p>
 *
 * @author teddyku
 * @see StudentClass
 * @generated
 */
public class StudentClassWrapper implements StudentClass,
	ModelWrapper<StudentClass> {
	public StudentClassWrapper(StudentClass studentClass) {
		_studentClass = studentClass;
	}

	@Override
	public Class<?> getModelClass() {
		return StudentClass.class;
	}

	@Override
	public String getModelClassName() {
		return StudentClass.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("classId", getClassId());
		attributes.put("formNo", getFormNo());
		attributes.put("classCode", getClassCode());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long classId = (Long)attributes.get("classId");

		if (classId != null) {
			setClassId(classId);
		}

		Integer formNo = (Integer)attributes.get("formNo");

		if (formNo != null) {
			setFormNo(formNo);
		}

		String classCode = (String)attributes.get("classCode");

		if (classCode != null) {
			setClassCode(classCode);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}
	}

	/**
	* Returns the primary key of this student class.
	*
	* @return the primary key of this student class
	*/
	@Override
	public long getPrimaryKey() {
		return _studentClass.getPrimaryKey();
	}

	/**
	* Sets the primary key of this student class.
	*
	* @param primaryKey the primary key of this student class
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_studentClass.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this student class.
	*
	* @return the uuid of this student class
	*/
	@Override
	public java.lang.String getUuid() {
		return _studentClass.getUuid();
	}

	/**
	* Sets the uuid of this student class.
	*
	* @param uuid the uuid of this student class
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_studentClass.setUuid(uuid);
	}

	/**
	* Returns the class ID of this student class.
	*
	* @return the class ID of this student class
	*/
	@Override
	public long getClassId() {
		return _studentClass.getClassId();
	}

	/**
	* Sets the class ID of this student class.
	*
	* @param classId the class ID of this student class
	*/
	@Override
	public void setClassId(long classId) {
		_studentClass.setClassId(classId);
	}

	/**
	* Returns the form no of this student class.
	*
	* @return the form no of this student class
	*/
	@Override
	public int getFormNo() {
		return _studentClass.getFormNo();
	}

	/**
	* Sets the form no of this student class.
	*
	* @param formNo the form no of this student class
	*/
	@Override
	public void setFormNo(int formNo) {
		_studentClass.setFormNo(formNo);
	}

	/**
	* Returns the class code of this student class.
	*
	* @return the class code of this student class
	*/
	@Override
	public java.lang.String getClassCode() {
		return _studentClass.getClassCode();
	}

	/**
	* Sets the class code of this student class.
	*
	* @param classCode the class code of this student class
	*/
	@Override
	public void setClassCode(java.lang.String classCode) {
		_studentClass.setClassCode(classCode);
	}

	/**
	* Returns the group ID of this student class.
	*
	* @return the group ID of this student class
	*/
	@Override
	public long getGroupId() {
		return _studentClass.getGroupId();
	}

	/**
	* Sets the group ID of this student class.
	*
	* @param groupId the group ID of this student class
	*/
	@Override
	public void setGroupId(long groupId) {
		_studentClass.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this student class.
	*
	* @return the company ID of this student class
	*/
	@Override
	public long getCompanyId() {
		return _studentClass.getCompanyId();
	}

	/**
	* Sets the company ID of this student class.
	*
	* @param companyId the company ID of this student class
	*/
	@Override
	public void setCompanyId(long companyId) {
		_studentClass.setCompanyId(companyId);
	}

	/**
	* Returns the user ID of this student class.
	*
	* @return the user ID of this student class
	*/
	@Override
	public long getUserId() {
		return _studentClass.getUserId();
	}

	/**
	* Sets the user ID of this student class.
	*
	* @param userId the user ID of this student class
	*/
	@Override
	public void setUserId(long userId) {
		_studentClass.setUserId(userId);
	}

	/**
	* Returns the user uuid of this student class.
	*
	* @return the user uuid of this student class
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _studentClass.getUserUuid();
	}

	/**
	* Sets the user uuid of this student class.
	*
	* @param userUuid the user uuid of this student class
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_studentClass.setUserUuid(userUuid);
	}

	/**
	* Returns the user name of this student class.
	*
	* @return the user name of this student class
	*/
	@Override
	public java.lang.String getUserName() {
		return _studentClass.getUserName();
	}

	/**
	* Sets the user name of this student class.
	*
	* @param userName the user name of this student class
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_studentClass.setUserName(userName);
	}

	/**
	* Returns the create date of this student class.
	*
	* @return the create date of this student class
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _studentClass.getCreateDate();
	}

	/**
	* Sets the create date of this student class.
	*
	* @param createDate the create date of this student class
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_studentClass.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this student class.
	*
	* @return the modified date of this student class
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _studentClass.getModifiedDate();
	}

	/**
	* Sets the modified date of this student class.
	*
	* @param modifiedDate the modified date of this student class
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_studentClass.setModifiedDate(modifiedDate);
	}

	@Override
	public boolean isNew() {
		return _studentClass.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_studentClass.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _studentClass.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_studentClass.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _studentClass.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _studentClass.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_studentClass.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _studentClass.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_studentClass.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_studentClass.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_studentClass.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new StudentClassWrapper((StudentClass)_studentClass.clone());
	}

	@Override
	public int compareTo(com.qc.qcsms.model.StudentClass studentClass) {
		return _studentClass.compareTo(studentClass);
	}

	@Override
	public int hashCode() {
		return _studentClass.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.qc.qcsms.model.StudentClass> toCacheModel() {
		return _studentClass.toCacheModel();
	}

	@Override
	public com.qc.qcsms.model.StudentClass toEscapedModel() {
		return new StudentClassWrapper(_studentClass.toEscapedModel());
	}

	@Override
	public com.qc.qcsms.model.StudentClass toUnescapedModel() {
		return new StudentClassWrapper(_studentClass.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _studentClass.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _studentClass.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_studentClass.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof StudentClassWrapper)) {
			return false;
		}

		StudentClassWrapper studentClassWrapper = (StudentClassWrapper)obj;

		if (Validator.equals(_studentClass, studentClassWrapper._studentClass)) {
			return true;
		}

		return false;
	}

	@Override
	public StagedModelType getStagedModelType() {
		return _studentClass.getStagedModelType();
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public StudentClass getWrappedStudentClass() {
		return _studentClass;
	}

	@Override
	public StudentClass getWrappedModel() {
		return _studentClass;
	}

	@Override
	public void resetOriginalValues() {
		_studentClass.resetOriginalValues();
	}

	private StudentClass _studentClass;
}