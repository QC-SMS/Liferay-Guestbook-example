/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.model;

import com.liferay.portal.kernel.lar.StagedModelType;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link DisciplineCode}.
 * </p>
 *
 * @author teddyku
 * @see DisciplineCode
 * @generated
 */
public class DisciplineCodeWrapper implements DisciplineCode,
	ModelWrapper<DisciplineCode> {
	public DisciplineCodeWrapper(DisciplineCode disciplineCode) {
		_disciplineCode = disciplineCode;
	}

	@Override
	public Class<?> getModelClass() {
		return DisciplineCode.class;
	}

	@Override
	public String getModelClassName() {
		return DisciplineCode.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("disciplineCodeId", getDisciplineCodeId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("userName", getUserName());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("assignedCode", getAssignedCode());
		attributes.put("description", getDescription());
		attributes.put("severity", getSeverity());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long disciplineCodeId = (Long)attributes.get("disciplineCodeId");

		if (disciplineCodeId != null) {
			setDisciplineCodeId(disciplineCodeId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		String userName = (String)attributes.get("userName");

		if (userName != null) {
			setUserName(userName);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String assignedCode = (String)attributes.get("assignedCode");

		if (assignedCode != null) {
			setAssignedCode(assignedCode);
		}

		String description = (String)attributes.get("description");

		if (description != null) {
			setDescription(description);
		}

		String severity = (String)attributes.get("severity");

		if (severity != null) {
			setSeverity(severity);
		}
	}

	/**
	* Returns the primary key of this discipline code.
	*
	* @return the primary key of this discipline code
	*/
	@Override
	public long getPrimaryKey() {
		return _disciplineCode.getPrimaryKey();
	}

	/**
	* Sets the primary key of this discipline code.
	*
	* @param primaryKey the primary key of this discipline code
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_disciplineCode.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the uuid of this discipline code.
	*
	* @return the uuid of this discipline code
	*/
	@Override
	public java.lang.String getUuid() {
		return _disciplineCode.getUuid();
	}

	/**
	* Sets the uuid of this discipline code.
	*
	* @param uuid the uuid of this discipline code
	*/
	@Override
	public void setUuid(java.lang.String uuid) {
		_disciplineCode.setUuid(uuid);
	}

	/**
	* Returns the discipline code ID of this discipline code.
	*
	* @return the discipline code ID of this discipline code
	*/
	@Override
	public long getDisciplineCodeId() {
		return _disciplineCode.getDisciplineCodeId();
	}

	/**
	* Sets the discipline code ID of this discipline code.
	*
	* @param disciplineCodeId the discipline code ID of this discipline code
	*/
	@Override
	public void setDisciplineCodeId(long disciplineCodeId) {
		_disciplineCode.setDisciplineCodeId(disciplineCodeId);
	}

	/**
	* Returns the group ID of this discipline code.
	*
	* @return the group ID of this discipline code
	*/
	@Override
	public long getGroupId() {
		return _disciplineCode.getGroupId();
	}

	/**
	* Sets the group ID of this discipline code.
	*
	* @param groupId the group ID of this discipline code
	*/
	@Override
	public void setGroupId(long groupId) {
		_disciplineCode.setGroupId(groupId);
	}

	/**
	* Returns the company ID of this discipline code.
	*
	* @return the company ID of this discipline code
	*/
	@Override
	public long getCompanyId() {
		return _disciplineCode.getCompanyId();
	}

	/**
	* Sets the company ID of this discipline code.
	*
	* @param companyId the company ID of this discipline code
	*/
	@Override
	public void setCompanyId(long companyId) {
		_disciplineCode.setCompanyId(companyId);
	}

	/**
	* Returns the user ID of this discipline code.
	*
	* @return the user ID of this discipline code
	*/
	@Override
	public long getUserId() {
		return _disciplineCode.getUserId();
	}

	/**
	* Sets the user ID of this discipline code.
	*
	* @param userId the user ID of this discipline code
	*/
	@Override
	public void setUserId(long userId) {
		_disciplineCode.setUserId(userId);
	}

	/**
	* Returns the user uuid of this discipline code.
	*
	* @return the user uuid of this discipline code
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.lang.String getUserUuid()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _disciplineCode.getUserUuid();
	}

	/**
	* Sets the user uuid of this discipline code.
	*
	* @param userUuid the user uuid of this discipline code
	*/
	@Override
	public void setUserUuid(java.lang.String userUuid) {
		_disciplineCode.setUserUuid(userUuid);
	}

	/**
	* Returns the user name of this discipline code.
	*
	* @return the user name of this discipline code
	*/
	@Override
	public java.lang.String getUserName() {
		return _disciplineCode.getUserName();
	}

	/**
	* Sets the user name of this discipline code.
	*
	* @param userName the user name of this discipline code
	*/
	@Override
	public void setUserName(java.lang.String userName) {
		_disciplineCode.setUserName(userName);
	}

	/**
	* Returns the create date of this discipline code.
	*
	* @return the create date of this discipline code
	*/
	@Override
	public java.util.Date getCreateDate() {
		return _disciplineCode.getCreateDate();
	}

	/**
	* Sets the create date of this discipline code.
	*
	* @param createDate the create date of this discipline code
	*/
	@Override
	public void setCreateDate(java.util.Date createDate) {
		_disciplineCode.setCreateDate(createDate);
	}

	/**
	* Returns the modified date of this discipline code.
	*
	* @return the modified date of this discipline code
	*/
	@Override
	public java.util.Date getModifiedDate() {
		return _disciplineCode.getModifiedDate();
	}

	/**
	* Sets the modified date of this discipline code.
	*
	* @param modifiedDate the modified date of this discipline code
	*/
	@Override
	public void setModifiedDate(java.util.Date modifiedDate) {
		_disciplineCode.setModifiedDate(modifiedDate);
	}

	/**
	* Returns the assigned code of this discipline code.
	*
	* @return the assigned code of this discipline code
	*/
	@Override
	public java.lang.String getAssignedCode() {
		return _disciplineCode.getAssignedCode();
	}

	/**
	* Sets the assigned code of this discipline code.
	*
	* @param assignedCode the assigned code of this discipline code
	*/
	@Override
	public void setAssignedCode(java.lang.String assignedCode) {
		_disciplineCode.setAssignedCode(assignedCode);
	}

	/**
	* Returns the description of this discipline code.
	*
	* @return the description of this discipline code
	*/
	@Override
	public java.lang.String getDescription() {
		return _disciplineCode.getDescription();
	}

	/**
	* Sets the description of this discipline code.
	*
	* @param description the description of this discipline code
	*/
	@Override
	public void setDescription(java.lang.String description) {
		_disciplineCode.setDescription(description);
	}

	/**
	* Returns the severity of this discipline code.
	*
	* @return the severity of this discipline code
	*/
	@Override
	public java.lang.String getSeverity() {
		return _disciplineCode.getSeverity();
	}

	/**
	* Sets the severity of this discipline code.
	*
	* @param severity the severity of this discipline code
	*/
	@Override
	public void setSeverity(java.lang.String severity) {
		_disciplineCode.setSeverity(severity);
	}

	@Override
	public boolean isNew() {
		return _disciplineCode.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_disciplineCode.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _disciplineCode.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_disciplineCode.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _disciplineCode.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _disciplineCode.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_disciplineCode.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _disciplineCode.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_disciplineCode.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_disciplineCode.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_disciplineCode.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new DisciplineCodeWrapper((DisciplineCode)_disciplineCode.clone());
	}

	@Override
	public int compareTo(com.qc.qcsms.model.DisciplineCode disciplineCode) {
		return _disciplineCode.compareTo(disciplineCode);
	}

	@Override
	public int hashCode() {
		return _disciplineCode.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.qc.qcsms.model.DisciplineCode> toCacheModel() {
		return _disciplineCode.toCacheModel();
	}

	@Override
	public com.qc.qcsms.model.DisciplineCode toEscapedModel() {
		return new DisciplineCodeWrapper(_disciplineCode.toEscapedModel());
	}

	@Override
	public com.qc.qcsms.model.DisciplineCode toUnescapedModel() {
		return new DisciplineCodeWrapper(_disciplineCode.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _disciplineCode.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _disciplineCode.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_disciplineCode.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof DisciplineCodeWrapper)) {
			return false;
		}

		DisciplineCodeWrapper disciplineCodeWrapper = (DisciplineCodeWrapper)obj;

		if (Validator.equals(_disciplineCode,
					disciplineCodeWrapper._disciplineCode)) {
			return true;
		}

		return false;
	}

	@Override
	public StagedModelType getStagedModelType() {
		return _disciplineCode.getStagedModelType();
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public DisciplineCode getWrappedDisciplineCode() {
		return _disciplineCode;
	}

	@Override
	public DisciplineCode getWrappedModel() {
		return _disciplineCode;
	}

	@Override
	public void resetOriginalValues() {
		_disciplineCode.resetOriginalValues();
	}

	private DisciplineCode _disciplineCode;
}