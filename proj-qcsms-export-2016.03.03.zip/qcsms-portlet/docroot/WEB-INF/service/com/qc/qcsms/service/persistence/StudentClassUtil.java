/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.qc.qcsms.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.qc.qcsms.model.StudentClass;

import java.util.List;

/**
 * The persistence utility for the student class service. This utility wraps {@link StudentClassPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author teddyku
 * @see StudentClassPersistence
 * @see StudentClassPersistenceImpl
 * @generated
 */
public class StudentClassUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(StudentClass studentClass) {
		getPersistence().clearCache(studentClass);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<StudentClass> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<StudentClass> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<StudentClass> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static StudentClass update(StudentClass studentClass)
		throws SystemException {
		return getPersistence().update(studentClass);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static StudentClass update(StudentClass studentClass,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(studentClass, serviceContext);
	}

	/**
	* Returns all the student classes where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByUuid(
		java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid);
	}

	/**
	* Returns a range of all the student classes where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByUuid(
		java.lang.String uuid, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	* Returns an ordered range of all the student classes where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByUuid(
		java.lang.String uuid, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	* Returns the first student class in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the first student class in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByUuid_First(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the last student class in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the last student class in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByUuid_Last(
		java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the student classes before and after the current student class in the ordered set where uuid = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass[] findByUuid_PrevAndNext(
		long classId, java.lang.String uuid,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence()
				   .findByUuid_PrevAndNext(classId, uuid, orderByComparator);
	}

	/**
	* Removes all the student classes where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid(uuid);
	}

	/**
	* Returns the number of student classes where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid(java.lang.String uuid)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid(uuid);
	}

	/**
	* Returns the student class where uuid = &#63; and groupId = &#63; or throws a {@link com.qc.qcsms.NoSuchStudentClassException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence().findByUUID_G(uuid, groupId);
	}

	/**
	* Returns the student class where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUUID_G(uuid, groupId);
	}

	/**
	* Returns the student class where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByUUID_G(
		java.lang.String uuid, long groupId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUUID_G(uuid, groupId, retrieveFromCache);
	}

	/**
	* Removes the student class where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the student class that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass removeByUUID_G(
		java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence().removeByUUID_G(uuid, groupId);
	}

	/**
	* Returns the number of student classes where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUUID_G(java.lang.String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUUID_G(uuid, groupId);
	}

	/**
	* Returns all the student classes where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByUuid_C(
		java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_C(uuid, companyId);
	}

	/**
	* Returns a range of all the student classes where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUuid_C(uuid, companyId, start, end);
	}

	/**
	* Returns an ordered range of all the student classes where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByUuid_C(
		java.lang.String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUuid_C(uuid, companyId, start, end, orderByComparator);
	}

	/**
	* Returns the first student class in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence()
				   .findByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the first student class in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByUuid_C_First(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last student class in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence()
				   .findByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last student class in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByUuid_C_Last(
		java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the student classes before and after the current student class in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass[] findByUuid_C_PrevAndNext(
		long classId, java.lang.String uuid, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence()
				   .findByUuid_C_PrevAndNext(classId, uuid, companyId,
			orderByComparator);
	}

	/**
	* Removes all the student classes where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUuid_C(uuid, companyId);
	}

	/**
	* Returns the number of student classes where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUuid_C(java.lang.String uuid, long companyId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUuid_C(uuid, companyId);
	}

	/**
	* Returns all the student classes where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByGroupId(groupId);
	}

	/**
	* Returns a range of all the student classes where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByGroupId(groupId, start, end);
	}

	/**
	* Returns an ordered range of all the student classes where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByGroupId(groupId, start, end, orderByComparator);
	}

	/**
	* Returns the first student class in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByGroupId_First(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence().findByGroupId_First(groupId, orderByComparator);
	}

	/**
	* Returns the first student class in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByGroupId_First(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByGroupId_First(groupId, orderByComparator);
	}

	/**
	* Returns the last student class in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByGroupId_Last(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence().findByGroupId_Last(groupId, orderByComparator);
	}

	/**
	* Returns the last student class in the ordered set where groupId = &#63;.
	*
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByGroupId_Last(
		long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByGroupId_Last(groupId, orderByComparator);
	}

	/**
	* Returns the student classes before and after the current student class in the ordered set where groupId = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass[] findByGroupId_PrevAndNext(
		long classId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence()
				   .findByGroupId_PrevAndNext(classId, groupId,
			orderByComparator);
	}

	/**
	* Returns all the student classes that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the matching student classes that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> filterFindByGroupId(
		long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterFindByGroupId(groupId);
	}

	/**
	* Returns a range of all the student classes that the user has permission to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> filterFindByGroupId(
		long groupId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterFindByGroupId(groupId, start, end);
	}

	/**
	* Returns an ordered range of all the student classes that the user has permissions to view where groupId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param groupId the group ID
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> filterFindByGroupId(
		long groupId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .filterFindByGroupId(groupId, start, end, orderByComparator);
	}

	/**
	* Returns the student classes before and after the current student class in the ordered set of student classes that the user has permission to view where groupId = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param groupId the group ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass[] filterFindByGroupId_PrevAndNext(
		long classId, long groupId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence()
				   .filterFindByGroupId_PrevAndNext(classId, groupId,
			orderByComparator);
	}

	/**
	* Removes all the student classes where groupId = &#63; from the database.
	*
	* @param groupId the group ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByGroupId(groupId);
	}

	/**
	* Returns the number of student classes where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static int countByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByGroupId(groupId);
	}

	/**
	* Returns the number of student classes that the user has permission to view where groupId = &#63;.
	*
	* @param groupId the group ID
	* @return the number of matching student classes that the user has permission to view
	* @throws SystemException if a system exception occurred
	*/
	public static int filterCountByGroupId(long groupId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().filterCountByGroupId(groupId);
	}

	/**
	* Returns all the student classes where formNo = &#63;.
	*
	* @param formNo the form no
	* @return the matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByFormNo(
		int formNo) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByFormNo(formNo);
	}

	/**
	* Returns a range of all the student classes where formNo = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param formNo the form no
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByFormNo(
		int formNo, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByFormNo(formNo, start, end);
	}

	/**
	* Returns an ordered range of all the student classes where formNo = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param formNo the form no
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByFormNo(
		int formNo, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByFormNo(formNo, start, end, orderByComparator);
	}

	/**
	* Returns the first student class in the ordered set where formNo = &#63;.
	*
	* @param formNo the form no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByFormNo_First(
		int formNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence().findByFormNo_First(formNo, orderByComparator);
	}

	/**
	* Returns the first student class in the ordered set where formNo = &#63;.
	*
	* @param formNo the form no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByFormNo_First(
		int formNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByFormNo_First(formNo, orderByComparator);
	}

	/**
	* Returns the last student class in the ordered set where formNo = &#63;.
	*
	* @param formNo the form no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByFormNo_Last(
		int formNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence().findByFormNo_Last(formNo, orderByComparator);
	}

	/**
	* Returns the last student class in the ordered set where formNo = &#63;.
	*
	* @param formNo the form no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByFormNo_Last(
		int formNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByFormNo_Last(formNo, orderByComparator);
	}

	/**
	* Returns the student classes before and after the current student class in the ordered set where formNo = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param formNo the form no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass[] findByFormNo_PrevAndNext(
		long classId, int formNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence()
				   .findByFormNo_PrevAndNext(classId, formNo, orderByComparator);
	}

	/**
	* Removes all the student classes where formNo = &#63; from the database.
	*
	* @param formNo the form no
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByFormNo(int formNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByFormNo(formNo);
	}

	/**
	* Returns the number of student classes where formNo = &#63;.
	*
	* @param formNo the form no
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static int countByFormNo(int formNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByFormNo(formNo);
	}

	/**
	* Returns all the student classes where formNo = &#63; and classCode = &#63;.
	*
	* @param formNo the form no
	* @param classCode the class code
	* @return the matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByFormClass(
		int formNo, java.lang.String classCode)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByFormClass(formNo, classCode);
	}

	/**
	* Returns a range of all the student classes where formNo = &#63; and classCode = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param formNo the form no
	* @param classCode the class code
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByFormClass(
		int formNo, java.lang.String classCode, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByFormClass(formNo, classCode, start, end);
	}

	/**
	* Returns an ordered range of all the student classes where formNo = &#63; and classCode = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param formNo the form no
	* @param classCode the class code
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findByFormClass(
		int formNo, java.lang.String classCode, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByFormClass(formNo, classCode, start, end,
			orderByComparator);
	}

	/**
	* Returns the first student class in the ordered set where formNo = &#63; and classCode = &#63;.
	*
	* @param formNo the form no
	* @param classCode the class code
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByFormClass_First(
		int formNo, java.lang.String classCode,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence()
				   .findByFormClass_First(formNo, classCode, orderByComparator);
	}

	/**
	* Returns the first student class in the ordered set where formNo = &#63; and classCode = &#63;.
	*
	* @param formNo the form no
	* @param classCode the class code
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByFormClass_First(
		int formNo, java.lang.String classCode,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByFormClass_First(formNo, classCode, orderByComparator);
	}

	/**
	* Returns the last student class in the ordered set where formNo = &#63; and classCode = &#63;.
	*
	* @param formNo the form no
	* @param classCode the class code
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByFormClass_Last(
		int formNo, java.lang.String classCode,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence()
				   .findByFormClass_Last(formNo, classCode, orderByComparator);
	}

	/**
	* Returns the last student class in the ordered set where formNo = &#63; and classCode = &#63;.
	*
	* @param formNo the form no
	* @param classCode the class code
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching student class, or <code>null</code> if a matching student class could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByFormClass_Last(
		int formNo, java.lang.String classCode,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByFormClass_Last(formNo, classCode, orderByComparator);
	}

	/**
	* Returns the student classes before and after the current student class in the ordered set where formNo = &#63; and classCode = &#63;.
	*
	* @param classId the primary key of the current student class
	* @param formNo the form no
	* @param classCode the class code
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass[] findByFormClass_PrevAndNext(
		long classId, int formNo, java.lang.String classCode,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence()
				   .findByFormClass_PrevAndNext(classId, formNo, classCode,
			orderByComparator);
	}

	/**
	* Removes all the student classes where formNo = &#63; and classCode = &#63; from the database.
	*
	* @param formNo the form no
	* @param classCode the class code
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByFormClass(int formNo, java.lang.String classCode)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByFormClass(formNo, classCode);
	}

	/**
	* Returns the number of student classes where formNo = &#63; and classCode = &#63;.
	*
	* @param formNo the form no
	* @param classCode the class code
	* @return the number of matching student classes
	* @throws SystemException if a system exception occurred
	*/
	public static int countByFormClass(int formNo, java.lang.String classCode)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByFormClass(formNo, classCode);
	}

	/**
	* Caches the student class in the entity cache if it is enabled.
	*
	* @param studentClass the student class
	*/
	public static void cacheResult(com.qc.qcsms.model.StudentClass studentClass) {
		getPersistence().cacheResult(studentClass);
	}

	/**
	* Caches the student classes in the entity cache if it is enabled.
	*
	* @param studentClasses the student classes
	*/
	public static void cacheResult(
		java.util.List<com.qc.qcsms.model.StudentClass> studentClasses) {
		getPersistence().cacheResult(studentClasses);
	}

	/**
	* Creates a new student class with the primary key. Does not add the student class to the database.
	*
	* @param classId the primary key for the new student class
	* @return the new student class
	*/
	public static com.qc.qcsms.model.StudentClass create(long classId) {
		return getPersistence().create(classId);
	}

	/**
	* Removes the student class with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param classId the primary key of the student class
	* @return the student class that was removed
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass remove(long classId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence().remove(classId);
	}

	public static com.qc.qcsms.model.StudentClass updateImpl(
		com.qc.qcsms.model.StudentClass studentClass)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(studentClass);
	}

	/**
	* Returns the student class with the primary key or throws a {@link com.qc.qcsms.NoSuchStudentClassException} if it could not be found.
	*
	* @param classId the primary key of the student class
	* @return the student class
	* @throws com.qc.qcsms.NoSuchStudentClassException if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass findByPrimaryKey(long classId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.qc.qcsms.NoSuchStudentClassException {
		return getPersistence().findByPrimaryKey(classId);
	}

	/**
	* Returns the student class with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param classId the primary key of the student class
	* @return the student class, or <code>null</code> if a student class with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.qc.qcsms.model.StudentClass fetchByPrimaryKey(
		long classId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(classId);
	}

	/**
	* Returns all the student classes.
	*
	* @return the student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the student classes.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @return the range of student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the student classes.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.qc.qcsms.model.impl.StudentClassModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of student classes
	* @param end the upper bound of the range of student classes (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of student classes
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.qc.qcsms.model.StudentClass> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the student classes from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of student classes.
	*
	* @return the number of student classes
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static StudentClassPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (StudentClassPersistence)PortletBeanLocatorUtil.locate(com.qc.qcsms.service.ClpSerializer.getServletContextName(),
					StudentClassPersistence.class.getName());

			ReferenceRegistry.registerReference(StudentClassUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(StudentClassPersistence persistence) {
	}

	private static StudentClassPersistence _persistence;
}